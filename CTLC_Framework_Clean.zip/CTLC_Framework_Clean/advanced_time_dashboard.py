#!/usr/bin/env python3
"""
Advanced CP-DDRL English Experiment Dashboard
With Real-time Simulation Data Integration and Advanced Time Control
"""

import http.server
import socketserver
import threading
import time
import json
import webbrowser
import base64
import io
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os
import sys
import datetime
from datetime import timedelta

# Add src to path for simulation data access
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

# Import real simulation components
try:
    from src.simulation.simulation_manager import SimulationManager
    from src.utils.config import Config
    import pygame
    SIMULATION_AVAILABLE = True
    print("✅ Real simulation data integration available!")
except ImportError as e:
    print(f"⚠️ Simulation integration not available: {e}")
    SIMULATION_AVAILABLE = False

class AdvancedTimeController:
    """Advanced time control system with peak time management"""
    
    def __init__(self):
        self.reset_time_settings()
        
    def reset_time_settings(self):
        """Reset to default time settings"""
        self.simulation_start_time = datetime.datetime.now()
        self.simulation_duration = timedelta(days=1)  # Default: 1 day
        self.time_acceleration = 60  # 1 minute real = 1 hour simulation
        
        # Peak time definitions
        self.peak_times = {
            'morning_peak': {'start': '07:00', 'end': '09:00', 'multiplier': 2.5},
            'evening_peak': {'start': '17:00', 'end': '19:00', 'multiplier': 2.8},
            'lunch_peak': {'start': '12:00', 'end': '13:00', 'multiplier': 1.5},
            'night_low': {'start': '23:00', 'end': '05:00', 'multiplier': 0.3}
        }
        
        # Vehicle density settings
        self.base_vehicle_count = 50
        self.max_vehicle_count = 200
        
        # Progress tracking
        self.progress = 0.0
        self.estimated_completion_time = None
        self.processing_start_time = None
        self.current_step = 0
        self.total_steps = 1440  # Default: 24 hours * 60 minutes
        
    def set_simulation_period(self, period_type, custom_duration=None):
        """Set simulation time period"""
        if period_type == 'day':
            self.simulation_duration = timedelta(days=1)
            self.total_steps = 1440  # 24 hours * 60 minutes
        elif period_type == 'week':
            self.simulation_duration = timedelta(days=7)
            self.total_steps = 10080  # 7 days * 24 hours * 60 minutes
        elif period_type == 'month':
            self.simulation_duration = timedelta(days=30)
            self.total_steps = 43200  # 30 days * 24 hours * 60 minutes
        elif period_type == 'year':
            self.simulation_duration = timedelta(days=365)
            self.total_steps = 525600  # 365 days * 24 hours * 60 minutes
        elif period_type == 'custom' and custom_duration:
            self.simulation_duration = custom_duration
            self.total_steps = int(custom_duration.total_seconds() / 60)
        
        self.reset_progress()
    
    def set_peak_times(self, peak_config):
        """Update peak time configuration"""
        self.peak_times.update(peak_config)
    
    def set_vehicle_density(self, base_count, max_count):
        """Set vehicle density parameters"""
        self.base_vehicle_count = base_count
        self.max_vehicle_count = max_count
    
    def get_current_simulation_time(self):
        """Get current simulation time based on acceleration"""
        if self.processing_start_time is None:
            return self.simulation_start_time
        
        real_elapsed = datetime.datetime.now() - self.processing_start_time
        sim_elapsed = real_elapsed * self.time_acceleration
        return self.simulation_start_time + sim_elapsed
    
    def get_vehicle_count_for_time(self, sim_time):
        """Calculate vehicle count based on current simulation time"""
        current_hour = sim_time.strftime('%H:%M')
        day_of_week = sim_time.weekday()  # 0=Monday, 6=Sunday
        
        base_multiplier = 1.0
        
        # Weekend adjustment
        if day_of_week >= 5:  # Weekend
            base_multiplier *= 0.7
        
        # Peak time adjustments
        for peak_name, peak_info in self.peak_times.items():
            if self._is_time_in_range(current_hour, peak_info['start'], peak_info['end']):
                base_multiplier *= peak_info['multiplier']
                break
        
        # Calculate final vehicle count
        vehicle_count = int(self.base_vehicle_count * base_multiplier)
        return min(vehicle_count, self.max_vehicle_count)
    
    def _is_time_in_range(self, current_time, start_time, end_time):
        """Check if current time is within a time range"""
        current = datetime.datetime.strptime(current_time, '%H:%M').time()
        start = datetime.datetime.strptime(start_time, '%H:%M').time()
        end = datetime.datetime.strptime(end_time, '%H:%M').time()
        
        if start <= end:
            return start <= current <= end
        else:  # Crosses midnight
            return current >= start or current <= end
    
    def update_progress(self, steps_completed):
        """Update simulation progress"""
        self.current_step = steps_completed
        self.progress = min(100.0, (steps_completed / self.total_steps) * 100)
        
        if self.processing_start_time and steps_completed > 0:
            elapsed_time = datetime.datetime.now() - self.processing_start_time
            estimated_total_time = elapsed_time * (self.total_steps / steps_completed)
            self.estimated_completion_time = self.processing_start_time + estimated_total_time
    
    def start_processing(self):
        """Start progress tracking"""
        self.processing_start_time = datetime.datetime.now()
        self.current_step = 0
        self.progress = 0.0
    
    def reset_progress(self):
        """Reset progress tracking"""
        self.processing_start_time = None
        self.current_step = 0
        self.progress = 0.0
        self.estimated_completion_time = None
    
    def get_progress_info(self):
        """Get comprehensive progress information"""
        info = {
            'progress_percentage': round(self.progress, 2),
            'current_step': self.current_step,
            'total_steps': self.total_steps,
            'simulation_time': self.get_current_simulation_time().strftime('%Y-%m-%d %H:%M:%S'),
            'real_time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'time_acceleration': f"{self.time_acceleration}x",
            'processing_status': 'active' if self.processing_start_time else 'idle'
        }
        
        if self.estimated_completion_time:
            remaining_time = self.estimated_completion_time - datetime.datetime.now()
            if remaining_time.total_seconds() > 0:
                info['estimated_completion'] = self.estimated_completion_time.strftime('%Y-%m-%d %H:%M:%S')
                info['time_remaining'] = str(remaining_time).split('.')[0]  # Remove microseconds
            else:
                info['estimated_completion'] = 'Completed'
                info['time_remaining'] = '00:00:00'
        
        # Current traffic density
        current_sim_time = self.get_current_simulation_time()
        info['current_vehicle_count'] = self.get_vehicle_count_for_time(current_sim_time)
        info['traffic_density'] = self._get_traffic_density_description(current_sim_time)
        
        return info
    
    def _get_traffic_density_description(self, sim_time):
        """Get human-readable traffic density description"""
        vehicle_count = self.get_vehicle_count_for_time(sim_time)
        density_ratio = vehicle_count / self.max_vehicle_count
        
        if density_ratio >= 0.8:
            return "Heavy Traffic"
        elif density_ratio >= 0.6:
            return "Moderate Traffic"
        elif density_ratio >= 0.4:
            return "Light Traffic"
        else:
            return "Minimal Traffic"

    def generate_time_series_data(self, days=7):
        """Generate time series data for visualization"""
        data_points = []
        start_time = self.simulation_start_time
        
        # Generate data points for the specified period
        for hour in range(days * 24):
            current_time = start_time + timedelta(hours=hour)
            vehicle_count = self.get_vehicle_count_for_time(current_time)
            
            data_points.append({
                'time': current_time.strftime('%Y-%m-%d %H:%M'),
                'hour': hour,
                'vehicle_count': vehicle_count,
                'day_of_week': current_time.strftime('%A'),
                'density': self._get_traffic_density_description(current_time)
            })
        
        return data_points

class AdvancedExperimentDashboard:
    """Enhanced experiment dashboard with advanced time control"""
    
    def __init__(self):
        self.time_controller = AdvancedTimeController()
        self.real_sim = None
        self.config = {
            'use_real_data': SIMULATION_AVAILABLE,
            'update_interval': 2,
            'chart_width': 1800,
            'chart_height': 1200
        }
        
        if SIMULATION_AVAILABLE:
            self.real_sim = AdvancedSimulationInterface(self.time_controller)
        
        # Initialize experiment state
        self.experiment_running = False
        self.experiment_results = {}
        self.logs = []
        
    def set_time_period(self, period_type, custom_days=None):
        """Set simulation time period"""
        if period_type == 'custom' and custom_days:
            custom_duration = timedelta(days=custom_days)
            self.time_controller.set_simulation_period('custom', custom_duration)
        else:
            self.time_controller.set_simulation_period(period_type)
    
    def configure_peak_times(self, peak_config):
        """Configure peak time settings"""
        self.time_controller.set_peak_times(peak_config)
    
    def configure_vehicle_density(self, base_count, max_count):
        """Configure vehicle density parameters"""
        self.time_controller.set_vehicle_density(base_count, max_count)
    
    def start_experiment(self):
        """Start the experiment with progress tracking"""
        self.experiment_running = True
        self.time_controller.start_processing()
        self.logs.append(f"Experiment started at {datetime.datetime.now()}")
        
        # Start background simulation
        if self.real_sim:
            self.real_sim.start_continuous_simulation()
    
    def stop_experiment(self):
        """Stop the experiment"""
        self.experiment_running = False
        self.time_controller.reset_progress()
        self.logs.append(f"Experiment stopped at {datetime.datetime.now()}")
        
        if self.real_sim:
            self.real_sim.stop_continuous_simulation()
    
    def get_dashboard_data(self):
        """Get comprehensive dashboard data"""
        data = {
            'experiment_status': 'running' if self.experiment_running else 'stopped',
            'time_info': self.time_controller.get_progress_info(),
            'peak_times': self.time_controller.peak_times,
            'vehicle_settings': {
                'base_count': self.time_controller.base_vehicle_count,
                'max_count': self.time_controller.max_vehicle_count
            },
            'time_series_data': self.time_controller.generate_time_series_data(),
            'recent_logs': self.logs[-10:] if self.logs else []
        }
        
        # Add real simulation data if available
        if self.real_sim and self.real_sim.simulation_active:
            real_data = self.real_sim.get_current_metrics()
            if real_data:
                data['simulation_metrics'] = real_data
        
        return data
    
    def generate_traffic_pattern_chart(self):
        """Generate traffic pattern visualization"""
        try:
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 12))
            
            # Get time series data
            time_data = self.time_controller.generate_time_series_data(days=7)
            hours = [d['hour'] for d in time_data]
            vehicle_counts = [d['vehicle_count'] for d in time_data]
            
            # Plot 1: Weekly traffic pattern
            ax1.plot(hours, vehicle_counts, linewidth=2, color='#2E86AB', alpha=0.8)
            ax1.fill_between(hours, vehicle_counts, alpha=0.3, color='#2E86AB')
            ax1.set_title('Weekly Traffic Pattern (CP-DDRL Simulation)', fontsize=16, fontweight='bold')
            ax1.set_xlabel('Hours from Start', fontsize=12)
            ax1.set_ylabel('Vehicle Count', fontsize=12)
            ax1.grid(True, alpha=0.3)
            
            # Add peak time markers
            for day in range(7):
                day_start = day * 24
                # Morning peak
                ax1.axvspan(day_start + 7, day_start + 9, alpha=0.2, color='red', label='Morning Peak' if day == 0 else "")
                # Evening peak
                ax1.axvspan(day_start + 17, day_start + 19, alpha=0.2, color='orange', label='Evening Peak' if day == 0 else "")
            
            if any(label.get_text() for label in ax1.get_legend_handles_labels()[1]):
                ax1.legend()
            
            # Plot 2: Daily average pattern
            daily_pattern = []
            for hour in range(24):
                avg_vehicles = np.mean([time_data[day*24 + hour]['vehicle_count'] for day in range(7)])
                daily_pattern.append(avg_vehicles)
            
            ax2.bar(range(24), daily_pattern, color='#A23B72', alpha=0.7)
            ax2.set_title('Average Daily Traffic Pattern', fontsize=16, fontweight='bold')
            ax2.set_xlabel('Hour of Day', fontsize=12)
            ax2.set_ylabel('Average Vehicle Count', fontsize=12)
            ax2.set_xticks(range(0, 24, 2))
            ax2.grid(True, alpha=0.3)
            
            # Highlight peak times
            peak_hours = [7, 8, 12, 17, 18]
            for hour in peak_hours:
                ax2.axvspan(hour-0.4, hour+0.4, alpha=0.3, color='red')
            
            plt.tight_layout()
            
            # Save to buffer
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png', dpi=300, bbox_inches='tight')
            buffer.seek(0)
            plot_data = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return plot_data
            
        except Exception as e:
            print(f"❌ Traffic pattern chart generation failed: {e}")
            return None

class AdvancedSimulationInterface:
    """Advanced simulation interface with time control integration"""
    
    def __init__(self, time_controller):
        self.time_controller = time_controller
        self.simulation_active = False
        self.sim_manager = None
        self.continuous_thread = None
        self.stop_simulation = False
        
        if SIMULATION_AVAILABLE:
            self.initialize_simulation()
    
    def initialize_simulation(self):
        """Initialize simulation"""
        try:
            pygame.init()
            dummy_screen = pygame.display.set_mode((1, 1), pygame.NOFRAME)
            self.sim_manager = SimulationManager(dummy_screen)
            self.simulation_active = True
            print("✅ Advanced simulation interface initialized")
        except Exception as e:
            print(f"❌ Simulation initialization failed: {e}")
            self.simulation_active = False
    
    def start_continuous_simulation(self):
        """Start continuous simulation in background"""
        if not self.simulation_active:
            return
        
        self.stop_simulation = False
        self.continuous_thread = threading.Thread(target=self._run_continuous_simulation)
        self.continuous_thread.daemon = True
        self.continuous_thread.start()
    
    def stop_continuous_simulation(self):
        """Stop continuous simulation"""
        self.stop_simulation = True
        if self.continuous_thread:
            self.continuous_thread.join(timeout=2)
    
    def _run_continuous_simulation(self):
        """Run simulation continuously with time-based vehicle management"""
        while not self.stop_simulation and self.simulation_active:
            try:
                # Get current simulation time and vehicle count
                current_sim_time = self.time_controller.get_current_simulation_time()
                target_vehicle_count = self.time_controller.get_vehicle_count_for_time(current_sim_time)
                
                # Run simulation step
                self.sim_manager.step()
                
                # Update progress
                self.time_controller.update_progress(self.time_controller.current_step + 1)
                
                # Sleep to control simulation speed
                time.sleep(0.1)  # 10 FPS simulation
                
            except Exception as e:
                print(f"❌ Continuous simulation error: {e}")
                break
    
    def get_current_metrics(self):
        """Get current simulation metrics"""
        if not self.simulation_active or not self.sim_manager:
            return None
        
        try:
            metrics = self.sim_manager.get_performance_metrics()
            metrics['time_info'] = self.time_controller.get_progress_info()
            return metrics
        except Exception as e:
            print(f"❌ Metrics collection failed: {e}")
            return None

class AdvancedRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Enhanced request handler with advanced time control APIs"""
    
    def do_GET(self):
        """Handle GET requests"""
        try:
            if self.path == '/':
                self.serve_dashboard()
            elif self.path == '/api/data':
                self.serve_dashboard_data()
            elif self.path == '/api/time/settings':
                self.serve_time_settings()
            elif self.path == '/api/charts/traffic_pattern':
                self.serve_traffic_pattern_chart()
            elif self.path.startswith('/api/time/set_period'):
                self.handle_set_time_period()
            elif self.path.startswith('/api/time/set_peaks'):
                self.handle_set_peak_times()
            elif self.path.startswith('/api/time/set_vehicles'):
                self.handle_set_vehicle_density()
            elif self.path.startswith('/api/experiment/start'):
                self.handle_start_experiment()
            elif self.path.startswith('/api/experiment/stop'):
                self.handle_stop_experiment()
            else:
                self.send_error(404)
        except Exception as e:
            print(f"❌ Request handling error: {e}")
            self.send_error(500)
    
    def serve_dashboard(self):
        """Serve the main dashboard HTML"""
        html_content = self.generate_advanced_html()
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(html_content.encode('utf-8'))
    
    def serve_dashboard_data(self):
        """Serve dashboard data"""
        dashboard = getattr(self.server, 'dashboard', None)
        if dashboard:
            data = dashboard.get_dashboard_data()
        else:
            data = {'error': 'Dashboard not available'}
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))
    
    def serve_traffic_pattern_chart(self):
        """Serve traffic pattern chart"""
        dashboard = getattr(self.server, 'dashboard', None)
        if dashboard:
            chart_data = dashboard.generate_traffic_pattern_chart()
            if chart_data:
                response = {'chart': chart_data, 'status': 'success'}
            else:
                response = {'error': 'Chart generation failed', 'status': 'error'}
        else:
            response = {'error': 'Dashboard not available', 'status': 'error'}
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(response).encode('utf-8'))
    
    def generate_advanced_html(self):
        """Generate advanced dashboard HTML with time controls"""
        return '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced CP-DDRL Time Control Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
        }
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .header {
            background: rgba(255,255,255,0.95);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }
        .control-panel {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .control-section {
            background: rgba(255,255,255,0.95);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }
        .progress-section {
            background: rgba(255,255,255,0.95);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }
        .progress-bar {
            width: 100%;
            height: 30px;
            background: #e0e0e0;
            border-radius: 15px;
            overflow: hidden;
            margin: 10px 0;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4CAF50, #45a049);
            transition: width 0.3s ease;
            border-radius: 15px;
        }
        .charts-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .chart-container {
            background: rgba(255,255,255,0.95);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            text-align: center;
        }
        .chart-container img {
            max-width: 100%;
            border-radius: 10px;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
            margin: 5px;
        }
        .btn-primary { background: #2196F3; color: white; }
        .btn-success { background: #4CAF50; color: white; }
        .btn-danger { background: #f44336; color: white; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.2); }
        select, input {
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 8px;
            margin: 5px;
            font-size: 14px;
        }
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .status-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #2196F3;
        }
        .logs-section {
            background: rgba(255,255,255,0.95);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            margin-top: 20px;
        }
        .log-item {
            padding: 8px;
            border-bottom: 1px solid #eee;
            font-family: monospace;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>🚀 Advanced CP-DDRL Time Control Dashboard</h1>
            <p>Real-time Simulation with Custom Time Periods & Peak Traffic Management</p>
        </div>

        <!-- Control Panel -->
        <div class="control-panel">
            <!-- Time Period Control -->
            <div class="control-section">
                <h3>⏱️ Time Period Settings</h3>
                <select id="timePeriod">
                    <option value="day">1 Day</option>
                    <option value="week">1 Week</option>
                    <option value="month">1 Month</option>
                    <option value="year">1 Year</option>
                    <option value="custom">Custom</option>
                </select>
                <input type="number" id="customDays" placeholder="Custom days" style="display:none;">
                <button class="btn btn-primary" onclick="setTimePeriod()">Apply Period</button>
            </div>

            <!-- Peak Time Control -->
            <div class="control-section">
                <h3>🚦 Peak Time Settings</h3>
                <div>
                    <label>Morning Peak:</label>
                    <input type="time" id="morningStart" value="07:00">
                    <input type="time" id="morningEnd" value="09:00">
                </div>
                <div>
                    <label>Evening Peak:</label>
                    <input type="time" id="eveningStart" value="17:00">
                    <input type="time" id="eveningEnd" value="19:00">
                </div>
                <button class="btn btn-primary" onclick="setPeakTimes()">Update Peaks</button>
            </div>

            <!-- Vehicle Density Control -->
            <div class="control-section">
                <h3>🚗 Vehicle Density</h3>
                <div>
                    <label>Base Count:</label>
                    <input type="number" id="baseVehicles" value="50" min="10" max="500">
                </div>
                <div>
                    <label>Max Count:</label>
                    <input type="number" id="maxVehicles" value="200" min="50" max="1000">
                </div>
                <button class="btn btn-primary" onclick="setVehicleDensity()">Apply Settings</button>
            </div>
        </div>

        <!-- Progress Section -->
        <div class="progress-section">
            <h3>📊 Simulation Progress</h3>
            <div class="progress-bar">
                <div class="progress-fill" id="progressBar" style="width: 0%;"></div>
            </div>
            <div class="status-grid">
                <div class="status-item">
                    <strong>Progress:</strong> <span id="progressPercent">0%</span>
                </div>
                <div class="status-item">
                    <strong>Current Step:</strong> <span id="currentStep">0</span> / <span id="totalSteps">0</span>
                </div>
                <div class="status-item">
                    <strong>Simulation Time:</strong> <span id="simTime">-</span>
                </div>
                <div class="status-item">
                    <strong>Time Remaining:</strong> <span id="timeRemaining">-</span>
                </div>
                <div class="status-item">
                    <strong>Vehicle Count:</strong> <span id="vehicleCount">0</span>
                </div>
                <div class="status-item">
                    <strong>Traffic Density:</strong> <span id="trafficDensity">-</span>
                </div>
            </div>
            <div style="text-align: center; margin-top: 20px;">
                <button class="btn btn-success" onclick="startExperiment()">▶️ Start Experiment</button>
                <button class="btn btn-danger" onclick="stopExperiment()">⏹️ Stop Experiment</button>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="charts-section">
            <div class="chart-container">
                <h3>📈 Traffic Pattern Analysis</h3>
                <img id="trafficChart" src="data:image/png;base64," alt="Traffic Pattern Chart Loading...">
            </div>
            <div class="chart-container">
                <h3>🎯 Performance Metrics</h3>
                <div id="metricsDisplay">Real-time metrics will appear here...</div>
            </div>
        </div>

        <!-- Logs Section -->
        <div class="logs-section">
            <h3>📋 System Logs</h3>
            <div id="logsContainer">
                <div class="log-item">System initialized and ready for advanced time control simulation...</div>
            </div>
        </div>
    </div>

    <script>
        // Global variables
        let updateInterval;
        let experimentRunning = false;

        // Initialize dashboard
        document.addEventListener('DOMContentLoaded', function() {
            updateDashboard();
            startAutoUpdate();
            
            // Show/hide custom days input
            document.getElementById('timePeriod').addEventListener('change', function() {
                const customInput = document.getElementById('customDays');
                if (this.value === 'custom') {
                    customInput.style.display = 'inline-block';
                } else {
                    customInput.style.display = 'none';
                }
            });
        });

        // Auto-update dashboard
        function startAutoUpdate() {
            updateInterval = setInterval(updateDashboard, 2000);
        }

        // Update dashboard data
        async function updateDashboard() {
            try {
                const response = await fetch('/api/data');
                const data = await response.json();
                
                if (data.time_info) {
                    updateProgressDisplay(data.time_info);
                }
                
                if (data.recent_logs) {
                    updateLogs(data.recent_logs);
                }
                
                // Update traffic chart periodically
                if (Math.random() < 0.1) { // 10% chance each update
                    updateTrafficChart();
                }
                
            } catch (error) {
                console.error('Dashboard update failed:', error);
            }
        }

        // Update progress display
        function updateProgressDisplay(timeInfo) {
            document.getElementById('progressBar').style.width = timeInfo.progress_percentage + '%';
            document.getElementById('progressPercent').textContent = timeInfo.progress_percentage + '%';
            document.getElementById('currentStep').textContent = timeInfo.current_step;
            document.getElementById('totalSteps').textContent = timeInfo.total_steps;
            document.getElementById('simTime').textContent = timeInfo.simulation_time;
            document.getElementById('timeRemaining').textContent = timeInfo.time_remaining || 'Calculating...';
            document.getElementById('vehicleCount').textContent = timeInfo.current_vehicle_count || 0;
            document.getElementById('trafficDensity').textContent = timeInfo.traffic_density || 'Unknown';
        }

        // Update logs
        function updateLogs(logs) {
            const container = document.getElementById('logsContainer');
            container.innerHTML = '';
            logs.forEach(log => {
                const logItem = document.createElement('div');
                logItem.className = 'log-item';
                logItem.textContent = log;
                container.appendChild(logItem);
            });
        }

        // Update traffic chart
        async function updateTrafficChart() {
            try {
                const response = await fetch('/api/charts/traffic_pattern');
                const data = await response.json();
                
                if (data.chart) {
                    document.getElementById('trafficChart').src = 'data:image/png;base64,' + data.chart;
                }
            } catch (error) {
                console.error('Traffic chart update failed:', error);
            }
        }

        // Control functions
        function setTimePeriod() {
            const period = document.getElementById('timePeriod').value;
            const customDays = document.getElementById('customDays').value;
            
            let url = '/api/time/set_period?type=' + period;
            if (period === 'custom' && customDays) {
                url += '&days=' + customDays;
            }
            
            fetch(url).then(() => addLog('Time period updated to: ' + period));
        }

        function setPeakTimes() {
            const morningStart = document.getElementById('morningStart').value;
            const morningEnd = document.getElementById('morningEnd').value;
            const eveningStart = document.getElementById('eveningStart').value;
            const eveningEnd = document.getElementById('eveningEnd').value;
            
            const url = '/api/time/set_peaks?morning_start=' + morningStart + 
                       '&morning_end=' + morningEnd +
                       '&evening_start=' + eveningStart +
                       '&evening_end=' + eveningEnd;
            
            fetch(url).then(() => addLog('Peak times updated'));
        }

        function setVehicleDensity() {
            const baseCount = document.getElementById('baseVehicles').value;
            const maxCount = document.getElementById('maxVehicles').value;
            
            const url = '/api/time/set_vehicles?base=' + baseCount + '&max=' + maxCount;
            
            fetch(url).then(() => addLog('Vehicle density updated: ' + baseCount + '-' + maxCount));
        }

        function startExperiment() {
            fetch('/api/experiment/start').then(() => {
                experimentRunning = true;
                addLog('🚀 Advanced time control experiment started!');
            });
        }

        function stopExperiment() {
            fetch('/api/experiment/stop').then(() => {
                experimentRunning = false;
                addLog('⏹️ Experiment stopped');
            });
        }

        function addLog(message) {
            const container = document.getElementById('logsContainer');
            const logItem = document.createElement('div');
            logItem.className = 'log-item';
            logItem.textContent = new Date().toLocaleTimeString() + ' - ' + message;
            container.insertBefore(logItem, container.firstChild);
            
            // Keep only last 10 logs
            while (container.children.length > 10) {
                container.removeChild(container.lastChild);
            }
        }
    </script>
</body>
</html>
        '''

# Global dashboard instance
dashboard = AdvancedExperimentDashboard()

class AdvancedServer(socketserver.TCPServer):
    """Advanced server with dashboard integration"""
    
    def __init__(self, server_address, RequestHandlerClass):
        super().__init__(server_address, RequestHandlerClass)
        self.dashboard = dashboard

def main():
    """Start the advanced time control dashboard"""
    PORT = 8086
    
    try:
        # Start server
        with AdvancedServer(("", PORT), AdvancedRequestHandler) as httpd:
            print(f"🚀 Advanced CP-DDRL Time Control Dashboard started!")
            print(f"📊 **Access URL:** http://localhost:{PORT}")
            print(f"⏱️ **Features:** Custom time periods, peak traffic control, real progress tracking")
            print(f"🎯 **Time Periods:** Day, Week, Month, Year, Custom")
            print(f"🚦 **Traffic Control:** Morning/Evening peaks, vehicle density management")
            print(f"📈 **Progress Tracking:** Real-time completion estimates")
            
            # Open browser
            webbrowser.open(f'http://localhost:{PORT}')
            
            # Start server
            httpd.serve_forever()
            
    except KeyboardInterrupt:
        print("\n🛑 Dashboard stopped by user")
    except Exception as e:
        print(f"❌ Server error: {e}")

if __name__ == "__main__":
    main() 