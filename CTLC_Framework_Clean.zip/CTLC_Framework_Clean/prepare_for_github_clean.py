#!/usr/bin/env python3
"""
Clean GitHub Upload Preparation Script for CTLC Framework
清理版CTLC框架GitHub上传准备脚本

This script creates a clean copy of the CTLC Framework suitable for GitHub upload.
该脚本创建一个适合上传到GitHub的CTLC框架清理版本。
"""

import os
import shutil
import json
from pathlib import Path

def should_exclude_file_or_dir(path):
    """
    Determine if a file or directory should be excluded from GitHub upload
    判断文件或目录是否应该从GitHub上传中排除
    """
    path_str = str(path)
    name = path.name
    
    exclude_patterns = [
        # Virtual environments
        'venv',
        'env',
        '.venv',
        
        # macOS metadata files
        '._',
        '.DS_Store',
        
        # Python cache
        '__pycache__',
        '*.pyc',
        '*.pyo',
        
        # Log files
        '*.log',
        
        # Large data files (keep small ones)
        '*.xlsx',
        
        # Temporary experiment results
        'quick_experiment_',
        'comprehensive_experiment_results_',
        'seven_day_analysis_',
        'seven_day_detailed_analysis_',
        'vehicle_count_clarification_',
        
        # Binary files that are too large
        'verify_terminology.py',  # This file is 1GB+ corrupted
        
        # IDE files
        '.vscode',
        '.idea',
    ]
    
    # Check exact name matches
    for pattern in exclude_patterns:
        if name == pattern or name.startswith(pattern):
            return True
        if pattern in path_str:
            return True
    
    return False

def copy_directory_clean(src_dir, dest_dir):
    """
    Copy directory structure while filtering files and directories
    复制目录结构并过滤文件和目录
    """
    if dest_dir.exists():
        shutil.rmtree(dest_dir)
    
    dest_dir.mkdir(parents=True, exist_ok=True)
    
    files_copied = 0
    files_skipped = 0
    
    for root, dirs, files in os.walk(src_dir):
        # Remove excluded directories from dirs list to prevent traversal
        dirs[:] = [d for d in dirs if not should_exclude_file_or_dir(Path(root) / d)]
        
        # Create relative path
        rel_path = Path(root).relative_to(src_dir)
        dest_root = dest_dir / rel_path
        
        # Skip if current directory should be excluded
        if should_exclude_file_or_dir(Path(root)):
            continue
            
        dest_root.mkdir(parents=True, exist_ok=True)
        
        for file in files:
            src_file = Path(root) / file
            dest_file = dest_root / file
            
            if should_exclude_file_or_dir(src_file):
                files_skipped += 1
                continue
            
            try:
                # Check file size (skip files > 10MB for GitHub)
                if src_file.stat().st_size > 10 * 1024 * 1024:
                    files_skipped += 1
                    print(f"Skipped (too large): {src_file}")
                    continue
                
                shutil.copy2(src_file, dest_file)
                files_copied += 1
                print(f"✓ {rel_path / file}")
                
            except Exception as e:
                files_skipped += 1
                print(f"✗ Error copying {src_file}: {e}")
    
    return files_copied, files_skipped

def create_enhanced_readme():
    """
    Create an enhanced README for GitHub
    为GitHub创建增强版README
    """
    readme_content = '''# CTLC Framework - Hardware Simulation Control Panel Dashboard
# CTLC框架 - 硬件仿真控制面板仪表盘

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyTorch](https://img.shields.io/badge/PyTorch-Geometric-red.svg)](https://pytorch-geometric.readthedocs.io/)

**Consensus-Driven Trustworthy Learning and Control Framework for 6G-IoT Vehicular Systems**
**基于共识的可信学习与控制框架，适用于6G-IoT车联网系统**

## 🚀 Overview / 概述

The CTLC (Consensus-Driven Trustworthy Learning and Control) Framework is a comprehensive implementation for Connected and Automated Vehicle (CAV) coordination in 6G-IoT environments. This repository contains the complete source code, simulation tools, and real-time dashboard systems.

CTLC（基于共识的可信学习与控制）框架是针对6G-IoT环境中联网自动驾驶车辆(CAV)协调的综合实现。本仓库包含完整的源代码、仿真工具和实时仪表盘系统。

## 🌟 Key Features / 主要特性

### 🧠 Core Technologies / 核心技术
- **Consensus-Driven Learning**: Byzantine fault-tolerant distributed reinforcement learning / 基于共识的学习：拜占庭容错分布式强化学习
- **6G-Aware Adaptation**: Dynamic policy selection based on uRLLC/eMBB modes / 6G感知适应：基于uRLLC/eMBB模式的动态策略选择
- **ST-GNN Architecture**: Spatio-temporal graph neural networks for multi-modal fusion / ST-GNN架构：用于多模态融合的时空图神经网络
- **HOCBF Safety Layer**: Real-time safety filtering with formal guarantees / HOCBF安全层：具有形式化保证的实时安全过滤
- **Multi-Agent Coordination**: Scalable vehicle coordination with heterogeneous sensors / 多智能体协调：具有异构传感器的可扩展车辆协调

### 📊 Dashboard & Visualization / 仪表盘与可视化
- **Real-time Monitoring**: Live simulation data visualization / 实时监控：实时仿真数据可视化
- **Interactive Controls**: Dynamic parameter adjustment / 交互控制：动态参数调整
- **Performance Analytics**: Comprehensive experiment analysis / 性能分析：综合实验分析
- **Multi-language Support**: English and Chinese interfaces / 多语言支持：英中文界面

## 🏗️ Architecture / 架构

```
CTLC Framework Architecture
├── 🧠 Adaptive Policy Selector (6G Network Aware)
├── 🤝 Consensus Manager (Byzantine Fault Tolerant)
├── 🔗 ST-GNN Backbone (Multi-modal Fusion)
├── 🛡️ Safety Layer (HOCBF Controllers)
├── 📡 6G Network Simulator (uRLLC/eMBB)
└── 🎮 Interactive Dashboard (Real-time Monitoring)
```

## 🚀 Quick Start / 快速开始

### Prerequisites / 先决条件
```bash
Python 3.8+
PyTorch with geometric extensions
Pygame for visualization
NumPy, Matplotlib
```

### Installation / 安装
```bash
# Clone the repository / 克隆仓库
git clone https://github.com/PolyUDavid/CTLC_Framework_Hardware_Simulation_ControlPannelDashboard.git
cd CTLC_Framework_Hardware_Simulation_ControlPannelDashboard

# Create virtual environment / 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\\Scripts\\activate

# Install dependencies / 安装依赖
pip install -r requirements.txt
```

### Running Simulations / 运行仿真

#### 1. Enhanced Interactive Simulation / 增强型交互仿真
```bash
# Full CTLC framework with 6G network simulation
# 完整CTLC框架与6G网络仿真
python3 run_enhanced.py

# Distributed multi-agent simulation
# 分布式多智能体仿真  
python3 run_distributed.py
```

**Interactive Controls / 交互控制:**
- `SPACE`: Add new vehicle / 添加新车辆
- `R`: Reset simulation / 重置仿真
- `ESC`: Exit / 退出
- `N`: Network analysis / 网络分析
- `C`: Consensus metrics / 共识指标

#### 2. No-GUI Demonstration / 无GUI演示
```bash
# Comprehensive validation demo
# 综合验证演示
python3 simple_demo.py

# Research validation suite
# 研究验证套件
python3 validation_demo.py
```

#### 3. Dashboard Applications / 仪表盘应用
```bash
# English web dashboard / 英文网页仪表盘
python3 english_dashboard.py

# Advanced experiment dashboard / 高级实验仪表盘
python3 advanced_experiment_dashboard.py

# Time-mapping demonstration / 时间映射演示
python3 时间映射演示仪表盘.py
```

## 📁 Project Structure / 项目结构

```
CTLC_Framework/
├── 📂 src/                          # Core source code / 核心源代码
│   ├── simulation/                  # Simulation engine / 仿真引擎
│   │   ├── simulation_manager.py    # Main orchestrator / 主要编排器
│   │   ├── entities.py              # Vehicle, RSU entities / 车辆、RSU实体
│   │   └── graph_builder.py         # Multi-modal fusion / 多模态融合
│   ├── models/                      # Neural network models / 神经网络模型
│   │   ├── stgnn.py                 # Spatio-temporal GNN / 时空GNN
│   │   ├── sac_networks.py          # Actor-critic networks / 演员-评论家网络
│   │   └── adaptive_policy_selector.py # 6G-aware adaptation / 6G感知适应
│   ├── agents/                      # Agent controllers / 智能体控制器
│   │   ├── agent_controller.py      # SAC-based DDRL / 基于SAC的DDRL
│   │   └── safety_layer.py          # HOCBF safety / HOCBF安全层
│   └── utils/                       # Utilities / 工具函数
│       ├── config.py                # System parameters / 系统参数
│       └── network_6g.py            # 6G simulation / 6G仿真
│
├── 📂 DDRL_Framework/               # Distributed DRL / 分布式深度强化学习
│   ├── algorithms/                  # Consensus algorithms / 共识算法
│   ├── models/                      # Distributed models / 分布式模型
│   └── utils/                       # Distributed utilities / 分布式工具
│
├── 📂 ST_GNN_Framework/             # Spatio-Temporal GNN / 时空图神经网络
│   ├── models/                      # GNN architectures / GNN架构
│   ├── utils/                       # Graph utilities / 图工具
│   └── api/                         # ST-GNN API / ST-GNN接口
│
├── 📂 Dashboards & Demos /          # User interfaces / 用户界面
│   ├── english_dashboard.py         # English dashboard / 英文仪表盘
│   ├── advanced_experiment_dashboard.py # Advanced analytics / 高级分析
│   ├── simple_demo.py               # Quick demonstration / 快速演示
│   └── validation_demo.py           # Research validation / 研究验证
│
└── 📂 Documentation /               # Documentation / 文档
    ├── README.md                    # This file / 本文件
    ├── TECHNICAL_SPECIFICATIONS.md  # Technical details / 技术细节
    └── English_Dashboard_User_Guide.md # User guide / 用户指南
```

## 🔧 Configuration / 配置

Key parameters in `src/utils/config.py`:
主要参数位于 `src/utils/config.py`：

```python
# Simulation Parameters / 仿真参数
NUM_VEHICLES = 5              # Number of CAVs / CAV数量
CONSENSUS_ROUNDS = 50         # Consensus frequency / 共识频率
TRIMMED_MEAN_BETA = 0.1      # Fault tolerance / 容错参数

# 6G Network Parameters / 6G网络参数
COMM_RANGE = 200             # V2X communication range / V2X通信范围
URLLC_LATENCY_THRESHOLD = 1  # uRLLC latency (ms) / uRLLC延迟
EMBB_BANDWIDTH_THRESHOLD = 100 # eMBB bandwidth (Mbps) / eMBB带宽

# Neural Network Architecture / 神经网络架构
GNN_FEATURE_SIZE = 16        # ST-GNN input features / ST-GNN输入特征
STATE_DIM = 16               # Agent state space / 智能体状态空间
ACTION_DIM = 2               # [acceleration, steering] / [加速度, 转向]
```

## 🧪 Experiment Tools / 实验工具

### Automated Experiment Suite / 自动化实验套件
```bash
# Run comprehensive experiments / 运行综合实验
python3 automated_experiment_suite.py

# Generate multi-day analysis / 生成多日分析
python3 seven_day_data_analyzer.py

# Create performance visualizations / 创建性能可视化
python3 generate_plots.py
```

### Performance Metrics / 性能指标
- **Learning Efficiency**: +27.9% improvement with consensus / 学习效率：共识机制提升27.9%
- **Safety Guarantee**: Zero collisions with HOCBF / 安全保证：HOCBF零碰撞
- **Byzantine Resilience**: Stable with 30% malicious nodes / 拜占庭韧性：30%恶意节点下稳定
- **Real-time Performance**: <10ms consensus updates / 实时性能：<10ms共识更新

## 🌐 6G Network Features / 6G网络特性

### Dynamic Mode Adaptation / 动态模式适应
- **uRLLC Mode**: Ultra-low latency (≤1ms) for safety-critical operations / uRLLC模式：安全关键操作的超低延迟（≤1ms）
- **eMBB Mode**: High bandwidth (≥100Mbps) for data-intensive tasks / eMBB模式：数据密集任务的高带宽（≥100Mbps）
- **Hybrid Mode**: Adaptive switching based on network conditions / 混合模式：基于网络条件的自适应切换

### V2X Communication / V2X通信
- **V2V (Vehicle-to-Vehicle)**: Direct inter-vehicle coordination / 车对车：直接车间协调
- **V2I (Vehicle-to-Infrastructure)**: RSU-mediated communication / 车对基础设施：RSU中介通信
- **V2N (Vehicle-to-Network)**: Cloud-based coordination / 车对网络：基于云的协调

## 🔬 Research Validation / 研究验证

### Validated Research Contributions / 已验证的研究贡献
1. **Unified Framework**: Vertical integration of consensus, DDRL, and HOCBFs / 统一框架：共识、DDRL和HOCBF的垂直整合
2. **Byzantine Fault Tolerance**: Immune to up to 30% malicious agents / 拜占庭容错：免疫高达30%的恶意智能体
3. **6G-Aware Adaptation**: Real-time policy adjustment for network conditions / 6G感知适应：网络条件的实时策略调整
4. **Multi-modal Fusion**: Heterogeneous sensor integration via ST-GNN / 多模态融合：通过ST-GNN的异构传感器集成
5. **Formal Safety Guarantees**: HOCBF-based collision avoidance / 形式化安全保证：基于HOCBF的避碰

### Experimental Results / 实验结果
- **6G Mode Distribution**: uRLLC (33%), eMBB (27%), Mixed (40%) / 6G模式分布
- **Consensus Convergence**: Stable convergence under Byzantine attacks / 共识收敛：拜占庭攻击下的稳定收敛
- **Learning Performance**: Consistent improvement across scenarios / 学习性能：各场景下的一致改进

## 📚 Documentation / 文档

### Technical Documentation / 技术文档
- **[Technical Specifications](TECHNICAL_SPECIFICATIONS.md)**: Detailed system architecture / 详细系统架构
- **[ST-GNN Technical Details](ST-GNN技术规格详细说明.md)**: GNN implementation details / GNN实现细节
- **[Dashboard User Guide](English_Dashboard_User_Guide.md)**: Dashboard usage instructions / 仪表盘使用说明

### Research Papers / 研究论文
- **[6G IoV Discussion](6G_IoV_Discussion_Section.md)**: 6G vehicle networking analysis / 6G车联网分析
- **[Paper Recommendations](PAPER_RECOMMENDATIONS.md)**: Related research papers / 相关研究论文

## 🛠️ Development / 开发

### Code Style / 代码风格
- Follow PEP 8 for Python code / Python代码遵循PEP 8
- Use type hints where applicable / 在适用的地方使用类型提示
- Document all public functions / 记录所有公共函数

### Testing / 测试
```bash
# Run validation suite / 运行验证套件
python3 validation_demo.py

# Test specific components / 测试特定组件
python3 test_enhanced_features.py
```

## 🤝 Contributing / 贡献

We welcome contributions to improve the CTLC Framework!
我们欢迎为改进CTLC框架做出贡献！

### How to Contribute / 如何贡献
1. **Fork the repository** / 分叉仓库
2. **Create a feature branch** / 创建功能分支
3. **Make your changes** / 进行更改
4. **Add tests if applicable** / 如适用，添加测试
5. **Submit a pull request** / 提交拉取请求

### Contribution Areas / 贡献领域
- 🐛 Bug fixes / 错误修复
- ✨ New features / 新功能
- 📚 Documentation improvements / 文档改进
- 🎨 UI/UX enhancements / UI/UX增强
- 🔬 Research validation / 研究验证

## 📄 License / 许可证

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
本项目采用MIT许可证 - 详情请参阅[LICENSE](LICENSE)文件。

## 📞 Contact / 联系方式

- **GitHub Repository**: https://github.com/PolyUDavid/CTLC_Framework_Hardware_Simulation_ControlPannelDashboard
- **Issues & Support**: Use GitHub Issues for bug reports and feature requests / 使用GitHub Issues报告错误和功能请求
- **Research Collaboration**: Welcome academic and industry collaborations / 欢迎学术和行业合作

## 🙏 Acknowledgments / 致谢

This work builds upon research in:
本工作建立在以下研究基础上：

- **Connected and Automated Vehicles (CAV)** research community / 联网自动驾驶车辆(CAV)研究社区
- **6G-IoT systems** and vehicular networking / 6G-IoT系统和车联网
- **Distributed reinforcement learning** methodologies / 分布式强化学习方法
- **Graph neural networks** for spatio-temporal modeling / 用于时空建模的图神经网络

Special thanks to the open-source community for foundational tools and libraries.
特别感谢开源社区提供的基础工具和库。

---

**🚀 Ready to explore the future of autonomous vehicle coordination? Get started with our quick demo!**
**🚀 准备探索自动驾驶车辆协调的未来？从我们的快速演示开始！**

```bash
python3 simple_demo.py
```
'''
    
    return readme_content

def create_gitignore():
    """
    Create a comprehensive .gitignore file
    创建综合的.gitignore文件
    """
    gitignore_content = '''# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# Virtual Environment
venv/
env/
ENV/
.venv/

# PyTorch
*.pth
*.pt

# Jupyter Notebook
.ipynb_checkpoints

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Logs and temporary files
*.log
logs/
*.tmp
*.temp

# Experiment Results (large files)
quick_experiment_*/
comprehensive_experiment_results_*.json
seven_day_analysis_*.txt
seven_day_detailed_analysis_*.json
vehicle_count_clarification_*.json
vehicle_count_clarification_*.txt

# Large Data Files
*.xlsx
*.xls
*.csv
data/
results/

# Corrupted or problematic files
verify_terminology.py
'''
    return gitignore_content

def main():
    """
    Main function to prepare CTLC Framework for GitHub upload
    准备CTLC框架上传到GitHub的主函数
    """
    print("🚀 Preparing Clean CTLC Framework for GitHub Upload")
    print("🚀 准备清理版CTLC框架上传到GitHub")
    print("=" * 60)
    
    # Define paths
    current_dir = Path.cwd()
    src_dir = current_dir
    dest_dir = current_dir.parent / "CTLC_Framework_Clean"
    
    print(f"📁 Source Directory: {src_dir}")
    print(f"📁 Destination Directory: {dest_dir}")
    print()
    
    # Copy directory structure
    print("📋 Copying files (excluding virtual environments and cache)...")
    files_copied, files_skipped = copy_directory_clean(src_dir, dest_dir)
    
    # Create enhanced README
    print("📝 Creating enhanced README.md...")
    readme_path = dest_dir / "README.md"
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(create_enhanced_readme())
    
    # Create .gitignore
    print("🚫 Creating .gitignore...")
    gitignore_path = dest_dir / ".gitignore"
    with open(gitignore_path, 'w', encoding='utf-8') as f:
        f.write(create_gitignore())
    
    # Create a simple LICENSE file
    print("📄 Creating LICENSE file...")
    license_path = dest_dir / "LICENSE"
    license_content = '''MIT License

Copyright (c) 2024 CTLC Framework Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
'''
    with open(license_path, 'w', encoding='utf-8') as f:
        f.write(license_content)
    
    # Create upload instructions
    print("📋 Creating upload instructions...")
    instructions_path = dest_dir / "GITHUB_UPLOAD_GUIDE.md"
    instructions_content = '''# GitHub Upload Guide
# GitHub上传指南

## Quick Upload Steps / 快速上传步骤

### Method 1: Command Line / 方法1：命令行

1. **Navigate to the clean directory / 导航到清理目录:**
   ```bash
   cd ../CTLC_Framework_Clean
   ```

2. **Initialize Git repository / 初始化Git仓库:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Complete CTLC Framework implementation"
   ```

3. **Add your GitHub repository / 添加GitHub仓库:**
   ```bash
   git remote add origin https://github.com/PolyUDavid/CTLC_Framework_Hardware_Simulation_ControlPannelDashboard.git
   ```

4. **Push to GitHub / 推送到GitHub:**
   ```bash
   git branch -M main
   git push -u origin main
   ```

### Method 2: GitHub Desktop / 方法2：GitHub桌面版

1. **Open GitHub Desktop / 打开GitHub桌面版**
2. **File → Add Local Repository / 文件 → 添加本地仓库**
3. **Choose the `CTLC_Framework_Clean` folder / 选择`CTLC_Framework_Clean`文件夹**
4. **Publish repository to GitHub / 发布仓库到GitHub**
5. **Repository name / 仓库名称:** `CTLC_Framework_Hardware_Simulation_ControlPannelDashboard`

### Method 3: Direct Upload via Web / 方法3：通过网页直接上传

1. **Go to your GitHub repository / 访问你的GitHub仓库**
2. **Click "uploading an existing file" / 点击"上传现有文件"**
3. **Drag and drop all files from `CTLC_Framework_Clean` / 拖拽`CTLC_Framework_Clean`中的所有文件**
4. **Commit changes / 提交更改**

## What's Included / 包含内容

✅ **Complete source code / 完整源代码**
- Core CTLC framework
- ST-GNN implementation  
- DDRL algorithms
- Safety layer (HOCBF)
- 6G network simulation

✅ **Dashboard applications / 仪表盘应用**
- English and Chinese interfaces
- Real-time monitoring
- Interactive controls
- Performance analytics

✅ **Documentation / 文档**
- Comprehensive README
- Technical specifications
- User guides
- API documentation

✅ **Example scripts / 示例脚本**
- Quick demonstrations
- Validation suites
- Experiment runners

## What's Excluded / 排除内容

❌ **Virtual environments** (venv/, env/)
❌ **Python cache** (__pycache__/, *.pyc)
❌ **Log files** (*.log)
❌ **Large data files** (*.xlsx, experimental results)
❌ **macOS metadata** (._*, .DS_Store)
❌ **IDE configuration** (.vscode/, .idea/)
❌ **Corrupted files** (verify_terminology.py)

## Repository Size / 仓库大小

The cleaned repository should be **< 50MB**, making it suitable for GitHub's free tier.
清理后的仓库应该**< 50MB**，适合GitHub免费版本。

## Post-Upload Steps / 上传后步骤

1. **Set repository visibility to Public / 设置仓库为公开**
2. **Add repository description / 添加仓库描述:**
   ```
   CTLC Framework: Consensus-Driven Trustworthy Learning and Control for 6G-IoT Vehicular Systems. Complete implementation with real-time dashboards, distributed reinforcement learning, and Byzantine fault tolerance.
   ```

3. **Add topics/tags / 添加主题/标签:**
   - `autonomous-vehicles`
   - `reinforcement-learning`
   - `6g-networks`
   - `consensus-algorithms`
   - `pytorch`
   - `graph-neural-networks`
   - `vehicular-networks`
   - `byzantine-fault-tolerance`

4. **Enable GitHub Pages (optional) / 启用GitHub Pages（可选）**
5. **Create release tags / 创建发布标签**

## Troubleshooting / 故障排除

### Large File Issues / 大文件问题
If you encounter "file too large" errors:
如果遇到"文件过大"错误：

```bash
# Check file sizes / 检查文件大小
find . -size +10M -ls

# Use Git LFS for large files / 对大文件使用Git LFS
git lfs track "*.png"
git add .gitattributes
```

### Authentication Issues / 认证问题
If you get authentication errors:
如果遇到认证错误：

1. **Use Personal Access Token / 使用个人访问令牌**
2. **Configure Git credentials / 配置Git凭据:**
   ```bash
   git config --global user.name "Your Name"
   git config --global user.email "your.email@example.com"
   ```

## Support / 支持

If you encounter any issues during upload:
如果在上传过程中遇到任何问题：

1. **Check GitHub status** at https://githubstatus.com
2. **Review file sizes** and remove any large files
3. **Ensure all sensitive information is removed**
4. **Contact repository maintainer** via GitHub issues

---

**Ready to share your CTLC Framework with the world! 🚀**
**准备与世界分享你的CTLC框架！🚀**
'''
    
    with open(instructions_path, 'w', encoding='utf-8') as f:
        f.write(instructions_content)
    
    # Summary
    print()
    print("✅ Clean Preparation Complete!")
    print("✅ 清理准备完成！")
    print("=" * 60)
    print(f"📊 Files copied: {files_copied}")
    print(f"📊 Files skipped: {files_skipped}")
    print(f"📁 Clean repository ready: {dest_dir}")
    print()
    print("🔍 Next steps / 下一步:")
    print("1. Navigate to the CTLC_Framework_Clean directory")
    print("   导航到 CTLC_Framework_Clean 目录")
    print("2. Review the GITHUB_UPLOAD_GUIDE.md file")
    print("   查看 GITHUB_UPLOAD_GUIDE.md 文件")  
    print("3. Follow the upload instructions")
    print("   按照上传说明进行操作")
    print()
    print(f"📂 Ready to upload from: {dest_dir}")

if __name__ == "__main__":
    main() 