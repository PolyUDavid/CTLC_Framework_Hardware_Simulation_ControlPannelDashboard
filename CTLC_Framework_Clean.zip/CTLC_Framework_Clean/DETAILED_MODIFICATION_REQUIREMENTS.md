# CTLC框架详细修改需求

基于你的论文**"Consensus-Driven Distributed Reinforcement Learning: A Unified Framework for Trustworthy Coordination in 6G-IoT Vehicular Systems"**，以下是需要完善的详细修改内容。

## 📐 **数学公式完善需求**

### **1. 共识机制数学公式 (Section III.A)**

#### **当前问题**：
- 缺乏严格的数学推导
- 没有收敛性证明
- 拜占庭容错边界不明确

#### **需要添加的数学公式**：

```mathematical
// 坐标级修剪均值共识算法
对于参数坐标 j：
ΔW*_j = (1/(m-2β)) * Σ(i=β+1 to m-β) Δw_{i,j}^{sorted}

其中：
- β = f_byzantine (拜占庭节点数)
- m = n_agents (总节点数)
- 约束条件：f < n/3 (拜占庭容错定理)

// 收敛性定理
定理1：在f < n/3的条件下，修剪均值算法以指数速率收敛：
||x_i^{(k)} - x*|| ≤ ρ^k * ||x_i^{(0)} - x*||
其中 ρ < 1 是收敛率，x* 是真实共识值
```

#### **代码实现位置**：
- `src/algorithms/consensus_manager.py` ✅ 已完善
- 添加收敛性分析函数
- 添加拜占庭容错性验证

### **2. HOCBF安全公式 (Section III.B)**

#### **当前问题**：
- 缺乏相对度2系统的完整推导
- 没有共识验证状态的安全函数
- 李导数计算不完整

#### **需要添加的数学公式**：

```mathematical
// 安全函数定义
h(x_i, x_j) = ||p_i - p_j||² - d_safe²
其中 p_i, p_j 是车辆i和j的位置

// 李导数计算
L_f h(x) = ∇h(x) · f(x) = 2(p_i - p_j) · (v_i - v_j)
L_f² h(x) = 2||v_i - v_j||² + 2(p_i - p_j) · (a_i - a_j)
L_g L_f h(x) = 2(p_i - p_j)

// HOCBF约束（相对度2）
L_f² h(x) + L_g L_f h(x) · u + α₂(L_f h(x) + α₁ h(x)) ≥ 0

// 共识验证安全
使用 x_j^{trusted} 而不是原始 x_j：
h(x_i, x_j^{trusted}) ≥ 0 保证真实安全性
```

#### **代码实现位置**：
- `src/agents/safety_layer.py` ✅ 已添加HOCBFSafetyLayer类
- 需要集成到现有SafetyLayer中
- 添加QP求解器（推荐使用cvxpy）

### **3. SAC算法公式 (Section III.A)**

#### **当前问题**：
- 缺乏共识驱动训练的SAC目标函数
- 没有拜占庭鲁棒性的梯度聚合
- 温度参数自动调节未实现

#### **需要添加的数学公式**：

```mathematical
// 共识驱动SAC目标函数
J(θ) = E_{(s,a)~ρ_π}[r(s,a) + α H(π_θ(·|s))]

// 演员网络损失（带共识）
L_actor = E_s[α log π_θ(a|s) - Q_φ(s,a)]
其中 a ~ π_θ(·|s)

// 评论家网络损失
L_critic = E_{(s,a,r,s')}[(Q_φ(s,a) - (r + γV_ψ(s')))²]

// 温度参数自动调节
L_α = -α E_a[log π_θ(a|s) + H_target]
其中 H_target 是目标熵值

// 拜占庭鲁棒梯度聚合
∇W* = TrimmedMean({∇W_i : i ∈ [n_agents]})
```

#### **代码实现位置**：
- `src/models/sac_networks.py` ✅ 已添加数学注释
- `DDRL_Framework/algorithms/sac_distributed.py` 需要完善
- 添加自动温度调节
- 集成共识梯度聚合

### **4. ST-GNN融合公式 (Section IV.A)**

#### **当前问题**：
- 缺乏异构数据融合的数学描述
- 注意力机制未实现
- 时空图更新规则不明确

#### **需要添加的数学公式**：

```mathematical
// ST-GNN空间聚合
h_i^{(l+1)} = UPDATE^{(l)}(h_i^{(l)}, AGGREGATE^{(l)}({m_{ji} : j ∈ N(i)}))

// 异构消息传递
m_{ji} = ATTENTION(h_j^{(l)}, h_i^{(l)}) · TRANSFORM(h_j^{(l)})

// 注意力权重计算
α_{ji} = softmax(e_{ji})
e_{ji} = LeakyReLU(W_att · [h_i || h_j])

// 时间演化（GRU）
h_i^{(t+1)} = GRU(h_i^{spatial}, h_i^{(t)})

// 多模态编码器
h_vision = ViT(I_FPV)         // 视觉编码
h_lidar = PointNet(P_3D)      // 点云编码  
h_state = MLP(s_vehicle)      // 状态编码
h_fused = CONCAT([h_vision, h_lidar, h_state])
```

#### **代码实现位置**：
- `src/models/stgnn.py` ✅ 已添加数学注释
- 需要添加注意力机制
- 需要实现多模态编码器
- 添加缺失模态处理

### **5. 自适应策略选择器公式 (Section IV.B)**

#### **当前问题**：
- 网络条件到权重的映射不清晰
- 缺乏稳定性分析
- 奖励函数调制机制不完整

#### **需要添加的数学公式**：

```mathematical
// 网络条件输入
x_net = [L_m/L_max, B_m/B_max]  // 归一化延迟和带宽

// 自适应权重输出
[λ_uRLLC, λ_eMBB] = Softmax(MLP(x_net))
约束: λ_uRLLC + λ_eMBB = 1, λ_i ∈ [0,1]

// uRLLC主导奖励
R_uRLLC = R_base + λ_uRLLC · R_sync - (1-λ_uRLLC) · C_buffer
其中:
R_sync = 1 - Var({v_i : i ∈ neighbors})/v_max²
C_buffer = |a_ego| · penalty_factor

// eMBB主导奖励  
R_eMBB = R_base + λ_eMBB · R_explore - (1-λ_eMBB) · C_solo
其中:
R_explore = sensor_diversity_bonus + cooperation_bonus
C_solo = isolation_penalty

// 稳定性条件
||∇_L λ|| ≤ threshold  // 延迟梯度有界
||∇_B λ|| ≤ threshold  // 带宽梯度有界
```

#### **代码实现位置**：
- `src/models/adaptive_policy_selector.py` ✅ 已添加数学注释
- 需要完善奖励计算函数
- 添加稳定性监控

## 🏗️ **模型架构修改需求**

### **1. 完整的异构主干网络**

#### **当前架构**：
```
Input → SAC Networks → Output
```

#### **需要的架构**：
```
Multi-Modal Encoders:
├── Vision Branch (ViT): FPV Image → h_vision
├── Geometry Branch (PointNet): LiDAR → h_lidar  
└── State Branch (MLP): Vehicle State → h_state

↓

ST-GNN Fusion:
├── Spatial Aggregation (GCN with Attention)
├── Temporal Processing (GRU)
└── Context Embedding → h_context

↓

Adaptive Policy Selection:
├── Network Condition Monitor → [λ_uRLLC, λ_eMBB]
└── Reward Modulation

↓

SAC Policy Networks:
├── Actor Head → π_θ(a|s)
└── Critic Head → Q_φ(s,a)
```

#### **实现文件**：
- `src/models/heterogeneous_backbone.py` (新建)
- `src/models/multi_modal_encoders.py` (新建)
- 整合到现有SAC网络

### **2. 共识驱动训练循环**

#### **当前训练**：
```python
for episode in range(max_episodes):
    collect_experience()
    update_networks()
```

#### **需要的训练**：
```python
for episode in range(max_episodes):
    # 1. 分布式经验收集
    local_experiences = collect_experience()
    
    # 2. 本地梯度计算
    local_gradients = compute_gradients(local_experiences)
    
    # 3. 共识梯度聚合
    consensus_gradients = consensus_aggregate(local_gradients)
    
    # 4. 拜占庭鲁棒更新
    update_networks(consensus_gradients)
    
    # 5. 状态共识验证
    trusted_states = validate_states_consensus()
    
    # 6. HOCBF安全控制
    safe_actions = hocbf_filter(desired_actions, trusted_states)
```

#### **实现文件**：
- `src/algorithms/consensus_driven_sac.py` (新建)
- 修改现有训练循环

### **3. 安全层集成**

#### **当前安全**：
- 简单距离检查

#### **需要的安全层**：
```python
class IntegratedSafetyLayer:
    def __init__(self):
        self.consensus_validator = ConsensusStateValidator()
        self.hocbf_controller = HOCBFSafetyLayer()
        self.dmpc_optimizer = DMPCController()
    
    def ensure_safety(self, ego_state, neighbor_states, desired_action):
        # 1. 状态共识验证
        trusted_states = self.consensus_validator.validate(neighbor_states)
        
        # 2. HOCBF约束检查
        safe_action, is_safe = self.hocbf_controller.safe_control_synthesis(
            ego_state, trusted_states, desired_action)
        
        # 3. DMPC轨迹优化（如果需要）
        if not is_safe:
            optimal_action = self.dmpc_optimizer.optimize_trajectory(
                ego_state, trusted_states, safe_action)
            return optimal_action
        
        return safe_action
```

## 🛠️ **具体实现步骤**

### **第一阶段：数学基础**
1. ✅ 完善共识算法数学公式
2. ✅ 实现HOCBF严格推导
3. ✅ 添加SAC数学注释
4. ⏳ 实现收敛性分析工具
5. ⏳ 添加稳定性验证

### **第二阶段：模型架构**
1. ⏳ 创建多模态编码器
2. ⏳ 实现注意力机制ST-GNN
3. ⏳ 集成自适应策略选择器
4. ⏳ 构建异构主干网络
5. ⏳ 实现端到端训练

### **第三阶段：安全集成**
1. ⏳ 整合HOCBF到安全层
2. ⏳ 实现状态共识验证
3. ⏳ 添加QP求解器
4. ⏳ 集成DMPC控制器
5. ⏳ 端到端安全测试

### **第四阶段：验证优化**
1. ⏳ 数学收敛性验证
2. ⏳ 安全性形式化证明
3. ⏳ 性能基准测试
4. ⏳ 鲁棒性评估
5. ⏳ 可扩展性分析

## 📋 **优先级修改列表**

### **高优先级（论文核心）**：
1. **共识算法数学完善** ✅ 已完成
2. **HOCBF安全层实现** ✅ 已完成基础版
3. **自适应策略数学公式** ✅ 已完成
4. **ST-GNN注意力机制** ⏳ 需要实现
5. **多模态编码器** ⏳ 需要实现

### **中优先级（实现完整性）**：
1. **QP求解器集成** ⏳ 推荐cvxpy
2. **DMPC控制器** ⏳ 可选但重要
3. **温度参数自动调节** ⏳ SAC改进
4. **收敛性分析工具** ⏳ 理论验证
5. **拜占庭检测机制** ⏳ 实用性提升

### **低优先级（锦上添花）**：
1. **可视化界面优化** ✅ 已有基础版
2. **性能监控仪表板** ⏳ 可选
3. **超参数自动调优** ⏳ 可选
4. **分布式部署脚本** ⏳ 可选
5. **实验数据分析工具** ⏳ 可选

## 🎯 **建议的修改顺序**

1. **先完善数学基础**：确保所有公式和理论推导正确
2. **再实现核心算法**：ST-GNN注意力、多模态编码器
3. **然后集成安全层**：HOCBF + 共识验证
4. **最后优化性能**：QP求解器、DMPC控制器
5. **验证和测试**：全面的数学和实验验证

这样的修改顺序可以确保：
- ✅ 论文的理论贡献得到严格实现
- ✅ 核心创新点得到重点体现  
- ✅ 安全性和鲁棒性得到保证
- ✅ 实际部署的可行性得到验证

---

**总结**：你的论文理论基础很扎实，主要需要将数学公式转化为严格的代码实现，并确保各个组件能够无缝集成。重点是ST-GNN的注意力机制和多模态处理能力。 