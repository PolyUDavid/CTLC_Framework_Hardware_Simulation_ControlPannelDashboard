#!/usr/bin/env python3
"""
CTLC Framework - Consensus Decision Visualization Demo

This script demonstrates the enhanced consensus decision-making capabilities
with real-time visualization of distributed agent coordination.
"""

import sys
import time
import numpy as np
from src.simulation.simulation_manager import SimulationManager
from src.utils.config import Config
import pygame

def main():
    """Run enhanced consensus demo with detailed decision tracking."""
    
    print("=" * 80)
    print("🤝 CTLC FRAMEWORK: Enhanced Consensus Decision Demo")
    print("Real-time Distributed Agent Coordination Visualization")
    print("=" * 80)
    
    # Initialize pygame and simulation
    pygame.init()
    screen = pygame.display.set_mode((Config.WIDTH, Config.HEIGHT))
    pygame.display.set_caption("CTLC Framework - Consensus Decisions")
    
    # Create simulation manager
    sim = SimulationManager(screen)
    clock = pygame.time.Clock()
    
    print(f"✅ Simulation initialized with {Config.NUM_VEHICLES} vehicles")
    print(f"🔄 Consensus updates every {Config.CONSENSUS_ROUNDS} steps")
    print(f"🎯 Enhanced UI shows real-time decision tracking")
    print()
    
    # Run simulation with enhanced consensus tracking
    running = True
    step_count = 0
    consensus_count = 0
    
    print("🚀 Starting enhanced consensus visualization...")
    print("📊 Watch the left panel for real-time consensus decisions!")
    print("👥 Green dots = honest agents, Yellow = potential byzantine")
    print("📈 Convergence metric shows agreement quality")
    print("🕒 Recent decisions timeline shows coordination history")
    print()
    
    start_time = time.time()
    
    try:
        while running and step_count < 500:  # Run for 500 steps
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
            
            # Execute simulation step
            sim.step()
            step_count += 1
            
            # Check for consensus updates
            metrics = sim.get_performance_metrics()
            if step_count > 0 and step_count % Config.CONSENSUS_ROUNDS == 0:
                consensus_count += 1
                net_metrics = metrics['network_metrics']
                
                print(f"🤝 Consensus #{consensus_count} at Step {step_count}:")
                print(f"   👥 Participants: {net_metrics.get('consensus_participants', 0)}")
                print(f"   📈 Convergence: {net_metrics.get('consensus_convergence', 0):.3f}")
                print(f"   📊 Algorithm: {net_metrics.get('consensus_algorithm', 'Unknown')}")
                print(f"   🎯 Mode: {net_metrics.get('current_mode', 'mixed')}")
                print(f"   ⚡ Latency: {net_metrics.get('latency', 0):.2f}ms")
                print(f"   📶 Bandwidth: {net_metrics.get('bandwidth', 0):.0f}Mbps")
                print()
            
            # Print periodic status
            if step_count % 100 == 0:
                elapsed = time.time() - start_time
                fps = step_count / elapsed if elapsed > 0 else 0
                
                print(f"📊 Status Update - Step {step_count}:")
                print(f"   ⏱️  Runtime: {elapsed:.1f}s")
                print(f"   🎯 FPS: {fps:.1f}")
                print(f"   🤝 Consensus Updates: {consensus_count}")
                print(f"   📡 6G Mode: {metrics['network_metrics'].get('current_mode', 'unknown')}")
                print()
            
            # Control frame rate
            clock.tick(60)
            
    except KeyboardInterrupt:
        print("\n⏹️  Simulation interrupted by user")
    except Exception as e:
        print(f"\n❌ Simulation error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Final statistics
        end_time = time.time()
        total_time = end_time - start_time
        
        print("\n" + "=" * 80)
        print("📊 ENHANCED CONSENSUS DEMO RESULTS")
        print("=" * 80)
        
        print(f"⏱️  Total Runtime: {total_time:.2f} seconds")
        print(f"🔢 Total Steps: {step_count}")
        print(f"🎯 Average FPS: {step_count/total_time:.1f}")
        print(f"🤝 Consensus Updates: {consensus_count}")
        
        if consensus_count > 0:
            print(f"📈 Consensus Frequency: Every {step_count/consensus_count:.1f} steps")
        
        # Final metrics
        final_metrics = sim.get_performance_metrics()['network_metrics']
        print(f"\n📡 Final Network Status:")
        print(f"   🎯 Mode: {final_metrics.get('current_mode', 'unknown')}")
        print(f"   ⚡ Latency: {final_metrics.get('latency', 0):.2f}ms")
        print(f"   📶 Bandwidth: {final_metrics.get('bandwidth', 0):.0f}Mbps")
        print(f"   📈 Last Convergence: {final_metrics.get('consensus_convergence', 0):.3f}")
        
        # Decision history summary
        decisions = final_metrics.get('recent_decisions', [])
        if decisions:
            print(f"\n🕒 Recent Consensus Decisions: {len(decisions)}")
            for i, decision in enumerate(decisions[-3:]):  # Show last 3
                status_icon = "✅" if decision.get('status') == 'agreed' else "⚠️"
                print(f"   {status_icon} Decision {i+1}: {decision.get('type', 'unknown')} - " +
                      f"Convergence: {decision.get('convergence', 0):.3f}")
        
        print(f"\n🎯 Enhanced consensus visualization demonstrated!")
        print(f"📊 Check the left panel during simulation for real-time decision tracking")
        
        pygame.quit()

if __name__ == "__main__":
    main() 