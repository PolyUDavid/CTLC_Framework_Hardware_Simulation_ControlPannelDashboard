"""
Generate Comprehensive Data Tables
生成完整对比数据表格

基于七天API数据生成详细的对比表格，用于论文中的数据展示
"""

import json
import pandas as pd
from datetime import datetime

def load_analysis_data():
    """加载分析数据"""
    with open('seven_day_detailed_analysis_20250627_222340.json', 'r', encoding='utf-8') as f:
        return json.load(f)

def generate_time_period_comparison_table(data):
    """生成时间段对比表格"""
    time_analysis = data['time_period_analysis']
    
    table_data = []
    for period, metrics in time_analysis.items():
        row = {
            '时间段': period,
            '中文名称': {
                'morning_peak': '早高峰',
                'evening_peak': '晚高峰', 
                'normal': '平峰',
                'valley': '波谷'
            }.get(period, period),
            '场景数': metrics['scenario_count'],
            '平均车辆数': f"{metrics['avg_vehicle_count']:.1f}",
            '碰撞率基线(%)': f"{metrics['collision_rate']['baseline_avg']:.1f}",
            '碰撞率分布式(%)': f"{metrics['collision_rate']['distributed_avg']:.1f}",
            '碰撞率改善(%)': f"{metrics['collision_rate']['improvement_avg']:.1f}",
            '速度基线(km/h)': f"{metrics['speed']['baseline_avg']:.1f}",
            '速度分布式(km/h)': f"{metrics['speed']['distributed_avg']:.1f}",
            '速度改善(%)': f"{metrics['speed']['improvement_avg']:.1f}",
            '延迟基线(ms)': f"{metrics['delay']['baseline_avg']:.1f}",
            '延迟分布式(ms)': f"{metrics['delay']['distributed_avg']:.1f}",
            '延迟改善(%)': f"{metrics['delay']['improvement_avg']:.1f}",
            '吞吐量改善(%)': f"{metrics['throughput']['improvement_avg']:.1f}",
            '安全违规(次)': f"{metrics['safety_events']['avg_violations']:.1f}",
            '紧急制动(次)': f"{metrics['safety_events']['avg_emergency_brakes']:.0f}"
        }
        table_data.append(row)
    
    df = pd.DataFrame(table_data)
    return df

def generate_daily_comparison_table(data):
    """生成每日对比表格"""
    daily_analysis = data['weekly_patterns']['daily_analysis']
    
    table_data = []
    for day, metrics in daily_analysis.items():
        row = {
            '日期': day,
            '中文': {
                'Monday': '周一', 'Tuesday': '周二', 'Wednesday': '周三',
                'Thursday': '周四', 'Friday': '周五', 'Saturday': '周六', 'Sunday': '周日'
            }.get(day, day),
            '场景数': metrics['scenario_count'],
            '总车辆数': metrics['total_vehicles'],
            '碰撞改善(%)': f"{metrics['avg_collision_improvement']:.1f}",
            '速度改善(%)': f"{metrics['avg_speed_improvement']:.1f}",
            '延迟改善(%)': f"{metrics['avg_delay_improvement']:.1f}",
            '共识改善(%)': f"{metrics['avg_consensus_improvement']:.1f}",
            '安全违规总数': metrics['total_safety_violations'],
            '紧急制动总数': metrics['total_emergency_brakes'],
            '吞吐量改善(%)': f"{metrics['avg_throughput_improvement']:.1f}"
        }
        table_data.append(row)
    
    df = pd.DataFrame(table_data)
    return df

def generate_weekday_weekend_comparison(data):
    """生成工作日vs周末对比表格"""
    comparison = data['weekly_patterns']['weekday_vs_weekend']
    
    table_data = []
    for period_type, metrics in comparison.items():
        row = {
            '类型': '工作日' if period_type == 'weekday' else '周末',
            '场景数': metrics['scenario_count'],
            '平均车辆密度': f"{metrics['avg_vehicle_density']:.1f}",
            '碰撞改善(%)': f"{metrics['avg_collision_improvement']:.1f}",
            '速度改善(%)': f"{metrics['avg_speed_improvement']:.1f}",
            '延迟改善(%)': f"{metrics['avg_delay_improvement']:.1f}",
            '共识改善(%)': f"{metrics['avg_consensus_improvement']:.1f}",
            '安全违规总数': metrics['total_safety_violations'],
            '基线吞吐量': f"{metrics['avg_throughput_baseline']:.0f}",
            '分布式吞吐量': f"{metrics['avg_throughput_distributed']:.0f}",
            '吞吐量改善(%)': f"{((metrics['avg_throughput_distributed'] - metrics['avg_throughput_baseline']) / metrics['avg_throughput_baseline'] * 100):.1f}"
        }
        table_data.append(row)
    
    df = pd.DataFrame(table_data)
    return df

def generate_case_study_results_table():
    """生成案例研究结果表格"""
    # 从原始数据文件获取案例研究结果
    with open('comprehensive_experiment_results_20250627_221253.json', 'r', encoding='utf-8') as f:
        raw_data = json.load(f)
    
    case_studies = raw_data['case_studies']
    
    table_data = []
    
    # Case 1: uRLLC
    case1 = case_studies['case1_urllc_sync']
    case1_row = {
        '案例': 'Case 1: uRLLC同步',
        '场景': '复杂十字路口',
        '车辆数': case1['scenario_info']['vehicle_count'],
        '碰撞率改善(%)': f"{case1['performance_metrics']['safety']['collision_rate']['improvement']:.1f}",
        '速度改善(%)': f"{case1['performance_metrics']['efficiency']['avg_speed']['improvement']:.1f}",
        '延迟改善(%)': f"{case1['performance_metrics']['communication']['end_to_end_delay']['improvement']:.1f}",
        '目标延迟(ms)': case1['case1_specific']['ultra_low_latency']['target_latency_ms'],
        '实际延迟(ms)': f"{case1['case1_specific']['ultra_low_latency']['actual_latency_ms']:.2f}",
        '可靠性': '99.99%',
        '车队成功率(%)': case1['case1_specific']['synchronization_performance']['convoy_formation_success'],
        '交叉口协调率(%)': case1['case1_specific']['synchronization_performance']['intersection_coordination']
    }
    table_data.append(case1_row)
    
    # Case 2: eMBB
    case2 = case_studies['case2_embb_perception']
    case2_row = {
        '案例': 'Case 2: eMBB感知',
        '场景': '高速公路合流',
        '车辆数': case2['scenario_info']['vehicle_count'],
        '碰撞率改善(%)': f"{case2['performance_metrics']['safety']['collision_rate']['improvement']:.1f}",
        '速度改善(%)': f"{case2['performance_metrics']['efficiency']['avg_speed']['improvement']:.1f}",
        '延迟改善(%)': f"{case2['performance_metrics']['communication']['end_to_end_delay']['improvement']:.1f}",
        '带宽利用(Gbps)': f"{case2['case2_specific']['high_bandwidth_perception']['bandwidth_utilized_gbps']:.1f}",
        '融合准确率(%)': case2['case2_specific']['high_bandwidth_perception']['multimodal_fusion_accuracy'],
        '遮挡穿透率(%)': case2['case2_specific']['high_bandwidth_perception']['occlusion_penetration'],
        '检测范围提升': f"{case2['case2_specific']['perception_enhancement']['detection_range_improvement']}%",
        '盲区消除率(%)': case2['case2_specific']['perception_enhancement']['blind_spot_elimination']
    }
    table_data.append(case2_row)
    
    df = pd.DataFrame(table_data)
    return df

def generate_performance_statistics_table(data):
    """生成性能统计表格"""
    # 从原始数据获取统计摘要
    with open('comprehensive_experiment_results_20250627_221253.json', 'r', encoding='utf-8') as f:
        raw_data = json.load(f)
    
    stats = raw_data['statistical_summary']['overall_performance']
    significance = raw_data['statistical_summary']['statistical_significance']
    
    table_data = [
        {
            '指标类别': '安全性能',
            '具体指标': '碰撞率降低',
            '平均改善(%)': f"{stats['collision_rate_improvement']['mean']:.1f}",
            '标准差(%)': f"{stats['collision_rate_improvement']['std']:.1f}",
            '95%置信区间下限(%)': f"{stats['collision_rate_improvement']['confidence_interval_95'][0]:.1f}",
            '95%置信区间上限(%)': f"{stats['collision_rate_improvement']['confidence_interval_95'][1]:.1f}",
            '效应量': f"{significance['effect_sizes']['collision_reduction']:.2f}"
        },
        {
            '指标类别': '效率性能', 
            '具体指标': '平均速度提升',
            '平均改善(%)': f"{stats['speed_improvement']['mean']:.1f}",
            '标准差(%)': f"{stats['speed_improvement']['std']:.2f}",
            '95%置信区间下限(%)': f"{stats['speed_improvement']['confidence_interval_95'][0]:.1f}",
            '95%置信区间上限(%)': f"{stats['speed_improvement']['confidence_interval_95'][1]:.1f}",
            '效应量': f"{significance['effect_sizes']['speed_improvement']:.2f}"
        },
        {
            '指标类别': '通信性能',
            '具体指标': '端到端延迟降低', 
            '平均改善(%)': f"{stats['delay_reduction']['mean']:.1f}",
            '标准差(%)': f"{stats['delay_reduction']['std']:.1f}",
            '95%置信区间下限(%)': f"{stats['delay_reduction']['confidence_interval_95'][0]:.1f}",
            '95%置信区间上限(%)': f"{stats['delay_reduction']['confidence_interval_95'][1]:.1f}",
            '效应量': 'N/A'
        }
    ]
    
    df = pd.DataFrame(table_data)
    return df

def save_all_tables_to_excel():
    """保存所有表格到Excel文件"""
    data = load_analysis_data()
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    excel_filename = f"CDTVDLF_完整实验数据表格_{timestamp}.xlsx"
    
    with pd.ExcelWriter(excel_filename, engine='openpyxl') as writer:
        # 时间段对比表格
        time_period_table = generate_time_period_comparison_table(data)
        time_period_table.to_excel(writer, sheet_name='时间段对比', index=False)
        
        # 每日对比表格
        daily_table = generate_daily_comparison_table(data)
        daily_table.to_excel(writer, sheet_name='每日对比', index=False)
        
        # 工作日vs周末
        weekday_weekend_table = generate_weekday_weekend_comparison(data)
        weekday_weekend_table.to_excel(writer, sheet_name='工作日vs周末', index=False)
        
        # 案例研究结果
        case_study_table = generate_case_study_results_table()
        case_study_table.to_excel(writer, sheet_name='案例研究', index=False)
        
        # 统计性能表格
        stats_table = generate_performance_statistics_table(data)
        stats_table.to_excel(writer, sheet_name='统计摘要', index=False)
    
    print(f"📊 所有数据表格已保存至: {excel_filename}")
    return excel_filename

def print_formatted_tables():
    """打印格式化的表格"""
    data = load_analysis_data()
    
    print("\n" + "="*80)
    print("🕐 时间段对比分析表格")
    print("="*80)
    time_period_table = generate_time_period_comparison_table(data)
    print(time_period_table.to_string(index=False))
    
    print("\n" + "="*80)
    print("📅 每日性能对比表格")
    print("="*80)
    daily_table = generate_daily_comparison_table(data)
    print(daily_table.to_string(index=False))
    
    print("\n" + "="*80)
    print("🏢 工作日 vs 周末对比表格")
    print("="*80)
    weekday_weekend_table = generate_weekday_weekend_comparison(data)
    print(weekday_weekend_table.to_string(index=False))
    
    print("\n" + "="*80)
    print("🎯 案例研究结果表格")
    print("="*80)
    case_study_table = generate_case_study_results_table()
    print(case_study_table.to_string(index=False))
    
    print("\n" + "="*80)
    print("📈 统计性能摘要表格")
    print("="*80)
    stats_table = generate_performance_statistics_table(data)
    print(stats_table.to_string(index=False))

def main():
    """主函数"""
    print("📊 生成CDTVDLF框架完整实验数据表格...")
    
    # 打印所有表格
    print_formatted_tables()
    
    # 保存到Excel
    excel_file = save_all_tables_to_excel()
    
    print(f"\n✅ 数据表格生成完成！")
    print(f"📁 Excel文件: {excel_file}")
    
    return excel_file

if __name__ == "__main__":
    main() 
Generate Comprehensive Data Tables
生成完整对比数据表格

基于七天API数据生成详细的对比表格，用于论文中的数据展示
"""

import json
import pandas as pd
from datetime import datetime

def load_analysis_data():
    """加载分析数据"""
    with open('seven_day_detailed_analysis_20250627_222340.json', 'r', encoding='utf-8') as f:
        return json.load(f)

def generate_time_period_comparison_table(data):
    """生成时间段对比表格"""
    time_analysis = data['time_period_analysis']
    
    table_data = []
    for period, metrics in time_analysis.items():
        row = {
            '时间段': period,
            '中文名称': {
                'morning_peak': '早高峰',
                'evening_peak': '晚高峰', 
                'normal': '平峰',
                'valley': '波谷'
            }.get(period, period),
            '场景数': metrics['scenario_count'],
            '平均车辆数': f"{metrics['avg_vehicle_count']:.1f}",
            '碰撞率基线(%)': f"{metrics['collision_rate']['baseline_avg']:.1f}",
            '碰撞率分布式(%)': f"{metrics['collision_rate']['distributed_avg']:.1f}",
            '碰撞率改善(%)': f"{metrics['collision_rate']['improvement_avg']:.1f}",
            '速度基线(km/h)': f"{metrics['speed']['baseline_avg']:.1f}",
            '速度分布式(km/h)': f"{metrics['speed']['distributed_avg']:.1f}",
            '速度改善(%)': f"{metrics['speed']['improvement_avg']:.1f}",
            '延迟基线(ms)': f"{metrics['delay']['baseline_avg']:.1f}",
            '延迟分布式(ms)': f"{metrics['delay']['distributed_avg']:.1f}",
            '延迟改善(%)': f"{metrics['delay']['improvement_avg']:.1f}",
            '吞吐量改善(%)': f"{metrics['throughput']['improvement_avg']:.1f}",
            '安全违规(次)': f"{metrics['safety_events']['avg_violations']:.1f}",
            '紧急制动(次)': f"{metrics['safety_events']['avg_emergency_brakes']:.0f}"
        }
        table_data.append(row)
    
    df = pd.DataFrame(table_data)
    return df

def generate_daily_comparison_table(data):
    """生成每日对比表格"""
    daily_analysis = data['weekly_patterns']['daily_analysis']
    
    table_data = []
    for day, metrics in daily_analysis.items():
        row = {
            '日期': day,
            '中文': {
                'Monday': '周一', 'Tuesday': '周二', 'Wednesday': '周三',
                'Thursday': '周四', 'Friday': '周五', 'Saturday': '周六', 'Sunday': '周日'
            }.get(day, day),
            '场景数': metrics['scenario_count'],
            '总车辆数': metrics['total_vehicles'],
            '碰撞改善(%)': f"{metrics['avg_collision_improvement']:.1f}",
            '速度改善(%)': f"{metrics['avg_speed_improvement']:.1f}",
            '延迟改善(%)': f"{metrics['avg_delay_improvement']:.1f}",
            '共识改善(%)': f"{metrics['avg_consensus_improvement']:.1f}",
            '安全违规总数': metrics['total_safety_violations'],
            '紧急制动总数': metrics['total_emergency_brakes'],
            '吞吐量改善(%)': f"{metrics['avg_throughput_improvement']:.1f}"
        }
        table_data.append(row)
    
    df = pd.DataFrame(table_data)
    return df

def generate_weekday_weekend_comparison(data):
    """生成工作日vs周末对比表格"""
    comparison = data['weekly_patterns']['weekday_vs_weekend']
    
    table_data = []
    for period_type, metrics in comparison.items():
        row = {
            '类型': '工作日' if period_type == 'weekday' else '周末',
            '场景数': metrics['scenario_count'],
            '平均车辆密度': f"{metrics['avg_vehicle_density']:.1f}",
            '碰撞改善(%)': f"{metrics['avg_collision_improvement']:.1f}",
            '速度改善(%)': f"{metrics['avg_speed_improvement']:.1f}",
            '延迟改善(%)': f"{metrics['avg_delay_improvement']:.1f}",
            '共识改善(%)': f"{metrics['avg_consensus_improvement']:.1f}",
            '安全违规总数': metrics['total_safety_violations'],
            '基线吞吐量': f"{metrics['avg_throughput_baseline']:.0f}",
            '分布式吞吐量': f"{metrics['avg_throughput_distributed']:.0f}",
            '吞吐量改善(%)': f"{((metrics['avg_throughput_distributed'] - metrics['avg_throughput_baseline']) / metrics['avg_throughput_baseline'] * 100):.1f}"
        }
        table_data.append(row)
    
    df = pd.DataFrame(table_data)
    return df

def generate_case_study_results_table():
    """生成案例研究结果表格"""
    # 从原始数据文件获取案例研究结果
    with open('comprehensive_experiment_results_20250627_221253.json', 'r', encoding='utf-8') as f:
        raw_data = json.load(f)
    
    case_studies = raw_data['case_studies']
    
    table_data = []
    
    # Case 1: uRLLC
    case1 = case_studies['case1_urllc_sync']
    case1_row = {
        '案例': 'Case 1: uRLLC同步',
        '场景': '复杂十字路口',
        '车辆数': case1['scenario_info']['vehicle_count'],
        '碰撞率改善(%)': f"{case1['performance_metrics']['safety']['collision_rate']['improvement']:.1f}",
        '速度改善(%)': f"{case1['performance_metrics']['efficiency']['avg_speed']['improvement']:.1f}",
        '延迟改善(%)': f"{case1['performance_metrics']['communication']['end_to_end_delay']['improvement']:.1f}",
        '目标延迟(ms)': case1['case1_specific']['ultra_low_latency']['target_latency_ms'],
        '实际延迟(ms)': f"{case1['case1_specific']['ultra_low_latency']['actual_latency_ms']:.2f}",
        '可靠性': '99.99%',
        '车队成功率(%)': case1['case1_specific']['synchronization_performance']['convoy_formation_success'],
        '交叉口协调率(%)': case1['case1_specific']['synchronization_performance']['intersection_coordination']
    }
    table_data.append(case1_row)
    
    # Case 2: eMBB
    case2 = case_studies['case2_embb_perception']
    case2_row = {
        '案例': 'Case 2: eMBB感知',
        '场景': '高速公路合流',
        '车辆数': case2['scenario_info']['vehicle_count'],
        '碰撞率改善(%)': f"{case2['performance_metrics']['safety']['collision_rate']['improvement']:.1f}",
        '速度改善(%)': f"{case2['performance_metrics']['efficiency']['avg_speed']['improvement']:.1f}",
        '延迟改善(%)': f"{case2['performance_metrics']['communication']['end_to_end_delay']['improvement']:.1f}",
        '带宽利用(Gbps)': f"{case2['case2_specific']['high_bandwidth_perception']['bandwidth_utilized_gbps']:.1f}",
        '融合准确率(%)': case2['case2_specific']['high_bandwidth_perception']['multimodal_fusion_accuracy'],
        '遮挡穿透率(%)': case2['case2_specific']['high_bandwidth_perception']['occlusion_penetration'],
        '检测范围提升': f"{case2['case2_specific']['perception_enhancement']['detection_range_improvement']}%",
        '盲区消除率(%)': case2['case2_specific']['perception_enhancement']['blind_spot_elimination']
    }
    table_data.append(case2_row)
    
    df = pd.DataFrame(table_data)
    return df

def generate_performance_statistics_table(data):
    """生成性能统计表格"""
    # 从原始数据获取统计摘要
    with open('comprehensive_experiment_results_20250627_221253.json', 'r', encoding='utf-8') as f:
        raw_data = json.load(f)
    
    stats = raw_data['statistical_summary']['overall_performance']
    significance = raw_data['statistical_summary']['statistical_significance']
    
    table_data = [
        {
            '指标类别': '安全性能',
            '具体指标': '碰撞率降低',
            '平均改善(%)': f"{stats['collision_rate_improvement']['mean']:.1f}",
            '标准差(%)': f"{stats['collision_rate_improvement']['std']:.1f}",
            '95%置信区间下限(%)': f"{stats['collision_rate_improvement']['confidence_interval_95'][0]:.1f}",
            '95%置信区间上限(%)': f"{stats['collision_rate_improvement']['confidence_interval_95'][1]:.1f}",
            '效应量': f"{significance['effect_sizes']['collision_reduction']:.2f}"
        },
        {
            '指标类别': '效率性能', 
            '具体指标': '平均速度提升',
            '平均改善(%)': f"{stats['speed_improvement']['mean']:.1f}",
            '标准差(%)': f"{stats['speed_improvement']['std']:.2f}",
            '95%置信区间下限(%)': f"{stats['speed_improvement']['confidence_interval_95'][0]:.1f}",
            '95%置信区间上限(%)': f"{stats['speed_improvement']['confidence_interval_95'][1]:.1f}",
            '效应量': f"{significance['effect_sizes']['speed_improvement']:.2f}"
        },
        {
            '指标类别': '通信性能',
            '具体指标': '端到端延迟降低', 
            '平均改善(%)': f"{stats['delay_reduction']['mean']:.1f}",
            '标准差(%)': f"{stats['delay_reduction']['std']:.1f}",
            '95%置信区间下限(%)': f"{stats['delay_reduction']['confidence_interval_95'][0]:.1f}",
            '95%置信区间上限(%)': f"{stats['delay_reduction']['confidence_interval_95'][1]:.1f}",
            '效应量': 'N/A'
        }
    ]
    
    df = pd.DataFrame(table_data)
    return df

def save_all_tables_to_excel():
    """保存所有表格到Excel文件"""
    data = load_analysis_data()
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    excel_filename = f"CDTVDLF_完整实验数据表格_{timestamp}.xlsx"
    
    with pd.ExcelWriter(excel_filename, engine='openpyxl') as writer:
        # 时间段对比表格
        time_period_table = generate_time_period_comparison_table(data)
        time_period_table.to_excel(writer, sheet_name='时间段对比', index=False)
        
        # 每日对比表格
        daily_table = generate_daily_comparison_table(data)
        daily_table.to_excel(writer, sheet_name='每日对比', index=False)
        
        # 工作日vs周末
        weekday_weekend_table = generate_weekday_weekend_comparison(data)
        weekday_weekend_table.to_excel(writer, sheet_name='工作日vs周末', index=False)
        
        # 案例研究结果
        case_study_table = generate_case_study_results_table()
        case_study_table.to_excel(writer, sheet_name='案例研究', index=False)
        
        # 统计性能表格
        stats_table = generate_performance_statistics_table(data)
        stats_table.to_excel(writer, sheet_name='统计摘要', index=False)
    
    print(f"📊 所有数据表格已保存至: {excel_filename}")
    return excel_filename

def print_formatted_tables():
    """打印格式化的表格"""
    data = load_analysis_data()
    
    print("\n" + "="*80)
    print("🕐 时间段对比分析表格")
    print("="*80)
    time_period_table = generate_time_period_comparison_table(data)
    print(time_period_table.to_string(index=False))
    
    print("\n" + "="*80)
    print("📅 每日性能对比表格")
    print("="*80)
    daily_table = generate_daily_comparison_table(data)
    print(daily_table.to_string(index=False))
    
    print("\n" + "="*80)
    print("🏢 工作日 vs 周末对比表格")
    print("="*80)
    weekday_weekend_table = generate_weekday_weekend_comparison(data)
    print(weekday_weekend_table.to_string(index=False))
    
    print("\n" + "="*80)
    print("🎯 案例研究结果表格")
    print("="*80)
    case_study_table = generate_case_study_results_table()
    print(case_study_table.to_string(index=False))
    
    print("\n" + "="*80)
    print("📈 统计性能摘要表格")
    print("="*80)
    stats_table = generate_performance_statistics_table(data)
    print(stats_table.to_string(index=False))

def main():
    """主函数"""
    print("📊 生成CDTVDLF框架完整实验数据表格...")
    
    # 打印所有表格
    print_formatted_tables()
    
    # 保存到Excel
    excel_file = save_all_tables_to_excel()
    
    print(f"\n✅ 数据表格生成完成！")
    print(f"📁 Excel文件: {excel_file}")
    
    return excel_file

if __name__ == "__main__":
    main() 