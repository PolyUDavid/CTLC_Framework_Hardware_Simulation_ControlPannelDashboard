#!/usr/bin/env python3
"""
CTLC框架状态检查
快速查看系统运行状态和核心指标
"""

import os
import sys
import time
import psutil
import subprocess

def check_process_running(name):
    """检查进程是否在运行"""
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            cmdline = proc.info['cmdline']
            if cmdline and name in ' '.join(cmdline):
                return True, proc.info['pid']
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess, TypeError):
            pass
    return False, None

def print_header():
    print("="*60)
    print("           CTLC框架实时状态监控")
    print("="*60)

def print_section(title):
    print(f"\n🔍 {title}")
    print("-" * 30)

def check_system_status():
    """检查系统状态"""
    print_section("系统状态")
    
    # 检查Python环境
    python_version = sys.version.split()[0]
    print(f"🐍 Python版本: {python_version}")
    
    # 检查依赖包
    try:
        import numpy, torch, pygame
        print(f"📦 核心依赖: ✅ 已安装")
        print(f"   • NumPy: {numpy.__version__}")
        print(f"   • PyTorch: {torch.__version__}")
        print(f"   • Pygame: {pygame.__version__}")
    except ImportError as e:
        print(f"❌ 依赖缺失: {e}")
    
    # 检查GPU
    if torch.cuda.is_available():
        print(f"🎮 GPU加速: ✅ {torch.cuda.get_device_name(0)}")
    else:
        print("🎮 GPU加速: ❌ 使用CPU模式")

def check_running_processes():
    """检查运行中的进程"""
    print_section("运行状态")
    
    processes = [
        ("run.py", "主仿真"),
        ("validation_demo.py", "验证演示"),
        ("no_training_demo.py", "无训练演示"),
        ("paper_validation_suite.py", "论文验证"),
        ("theoretical_analysis.py", "理论分析")
    ]
    
    running_count = 0
    for script, desc in processes:
        is_running, pid = check_process_running(script)
        if is_running:
            print(f"🟢 {desc}: 运行中 (PID: {pid})")
            running_count += 1
        else:
            print(f"⚪ {desc}: 未运行")
    
    if running_count == 0:
        print("\n💡 建议运行: python3 run.py 或 python3 no_training_demo.py")

def check_files_status():
    """检查文件状态"""
    print_section("文件完整性")
    
    critical_files = [
        "run.py",
        "no_training_demo.py",
        "paper_validation_suite.py",
        "theoretical_analysis.py",
        "src/simulation/simulation_manager.py",
        "src/models/sac_networks.py",
        "src/models/stgnn.py"
    ]
    
    missing_files = []
    for file_path in critical_files:
        if os.path.exists(file_path):
            size = os.path.getsize(file_path)
            print(f"✅ {file_path} ({size:,} bytes)")
        else:
            print(f"❌ {file_path} (缺失)")
            missing_files.append(file_path)
    
    if missing_files:
        print(f"\n⚠️ 发现 {len(missing_files)} 个文件缺失")
    else:
        print("\n🎉 所有核心文件完整")

def show_quick_commands():
    """显示快速命令"""
    print_section("快速命令")
    
    commands = [
        ("python3 run.py", "启动完整仿真(图形界面)"),
        ("python3 no_training_demo.py", "启动理论验证(图形界面)"),
        ("python3 paper_validation_suite.py", "运行论文验证套件"),
        ("python3 theoretical_analysis.py", "运行理论分析"),
        ("python3 simple_demo.py", "文本模式演示"),
        ("python3 training_monitor.py", "查看训练架构详情")
    ]
    
    for cmd, desc in commands:
        print(f"📝 {cmd}")
        print(f"   → {desc}")

def check_performance():
    """检查系统性能"""
    print_section("性能指标")
    
    # CPU使用率
    cpu_percent = psutil.cpu_percent(interval=1)
    print(f"🖥️ CPU使用率: {cpu_percent}%")
    
    # 内存使用
    memory = psutil.virtual_memory()
    memory_gb = memory.total / (1024**3)
    memory_used_gb = memory.used / (1024**3)
    print(f"💾 内存使用: {memory_used_gb:.1f}GB / {memory_gb:.1f}GB ({memory.percent}%)")
    
    # 磁盘空间
    disk = psutil.disk_usage('/')
    disk_free_gb = disk.free / (1024**3)
    print(f"💿 可用磁盘: {disk_free_gb:.1f}GB")
    
    # 性能建议
    if cpu_percent > 80:
        print("⚠️ CPU使用率较高，建议关闭其他应用")
    if memory.percent > 80:
        print("⚠️ 内存使用率较高，建议重启应用")
    if disk_free_gb < 1:
        print("⚠️ 磁盘空间不足，建议清理文件")

def main():
    """主函数"""
    print_header()
    print("🚀 实时监控你的CTLC框架运行状态")
    print(f"📅 检查时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    check_system_status()
    check_running_processes()
    check_files_status()
    check_performance()
    show_quick_commands()
    
    print("\n" + "="*60)
    print("✅ 状态检查完成！你的CTLC框架运行正常")
    print("💡 如需帮助，请运行上述任一命令")
    print("="*60)

if __name__ == "__main__":
    main() 