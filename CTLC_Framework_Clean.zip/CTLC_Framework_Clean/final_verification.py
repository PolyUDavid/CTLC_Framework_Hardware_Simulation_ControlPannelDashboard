#!/usr/bin/env python3
"""
最终术语验证脚本
Final Terminology Verification Script
"""

import os
import re

def check_terminology_updates():
    """检查术语更新完成情况"""
    
    print("🔍 最终术语更新验证")
    print("=" * 50)
    
    files_to_check = [
        "english_dashboard.py",
        "run_enhanced.py", 
        "run_distributed.py",
        "src/simulation/renderer.py"
    ]
    
    results = {}
    
    for file_path in files_to_check:
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # 检查ST-GNN出现次数（应该为0或很少）
            st_gnn_count = len(re.findall(r'ST-GNN', content))
            
            # 检查FDL-GNN出现次数（应该有一些）
            fdl_gnn_count = len(re.findall(r'FDL-GNN', content))
            
            # 检查CoRo-DDRL出现次数（应该有一些）
            coro_ddrl_count = len(re.findall(r'CoRo-DDRL', content))
            
            results[file_path] = {
                'ST-GNN': st_gnn_count,
                'FDL-GNN': fdl_gnn_count,
                'CoRo-DDRL': coro_ddrl_count
            }
            
            print(f"\n📁 {file_path}:")
            print(f"   ST-GNN: {st_gnn_count} (应该为0)")
            print(f"   FDL-GNN: {fdl_gnn_count}")
            print(f"   CoRo-DDRL: {coro_ddrl_count}")
            
            if st_gnn_count == 0:
                print("   ✅ ST-GNN已完全更新")
            else:
                print("   ⚠️  仍有ST-GNN需要更新")
                
    print("\n" + "=" * 50)
    print("✅ 术语更新验证完成！")
    
    return results

if __name__ == "__main__":
    check_terminology_updates() 
 