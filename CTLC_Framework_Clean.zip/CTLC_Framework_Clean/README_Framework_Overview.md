# CTLC Framework: 6G-Enhanced Vehicular Coordination System

## 🚀 Framework Overview

The **CTLC (Consensus-Driven Trustworthy Learning and Control) Framework** is a comprehensive simulation and deployment platform for 6G-enabled autonomous vehicular systems. It implements cutting-edge distributed deep reinforcement learning with Byzantine fault-tolerant consensus and real-time spatio-temporal graph neural networks.

### 🏗️ Architecture Highlights

- **Modular API Design**: Independent ST-GNN, DDRL, and Adaptive Policy Selector frameworks
- **Hardware Integration Ready**: APIs designed for third-party hardware deployment
- **6G Network Awareness**: Real-time adaptation to uRLLC/eMBB network conditions
- **Byzantine Fault Tolerance**: Robust consensus algorithms for distributed learning
- **Real-time Visualization**: Enhanced simulation interface with live metrics

---

## 📁 Project Structure

```
CTLC_Framework/
├── 🧠 ST_GNN_Framework/          # Independent ST-GNN module
│   ├── api/
│   │   └── stgnn_api.py          # Main API for third-party integration
│   ├── models/
│   │   └── stgnn_core.py         # Enhanced ST-GNN implementation
│   ├── utils/
│   │   └── graph_utils.py        # Graph processing utilities
│   └── examples/
│       └── third_party_integration.py
│
├── 🤖 DDRL_Framework/            # Independent DDRL module
│   ├── api/
│   │   └── ddrl_api.py           # Main API for distributed training
│   ├── algorithms/
│   │   ├── sac_distributed.py    # Distributed SAC implementation
│   │   └── consensus_manager.py  # Byzantine fault-tolerant consensus
│   ├── utils/
│   │   └── distributed_buffer.py # Distributed replay buffer
│   └── examples/
│       └── distributed_training.py
│
├── 🎯 src/simulation/            # Main simulation system
│   ├── simulation_manager.py     # Enhanced with 6G adaptation
│   ├── renderer.py              # Beautiful real-time interface
│   ├── entities.py              # Vehicle, RSU, sensor entities
│   └── graph_builder.py         # PyTorch Geometric integration
│
├── 📊 src/models/               # Core AI models
│   ├── adaptive_policy_selector.py  # 6G-aware policy adaptation
│   ├── stgnn.py                     # Spatio-temporal GNN
│   └── sac_networks.py             # Actor-Critic networks
│
└── 🛡️ src/agents/              # Agent controllers
    ├── agent_controller.py      # SAC with consensus APIs
    └── safety_layer.py          # HOCBF safety constraints
```

---

## 🌟 Key Features

### 1. **ST-GNN Framework** (`ST_GNN_Framework/`)

**Independent spatio-temporal graph neural network module for 6G-IoT systems**

#### Features:
- ✅ **Hardware-Agnostic API**: Standardized interface for third-party integration
- ✅ **Real-time Processing**: Optimized for low-latency inference (<50ms)
- ✅ **Model Export**: ONNX/TensorRT export for edge deployment
- ✅ **Device Registration**: Dynamic node registration and management

#### API Usage:
```python
from ST_GNN_Framework import STGNN_API, NetworkNode, NetworkEdge

# Initialize API
stgnn_api = STGNN_API(config={'feature_size': 8, 'hidden_size': 64})

# Register devices
vehicle_node = NetworkNode(id="vehicle_001", position=(100, 200), 
                          velocity=(10, 0), features={...}, 
                          device_type="vehicle")
stgnn_api.register_device(vehicle_node)

# Real-time processing
results = stgnn_api.process_realtime_data(nodes, edges)
embeddings = results['embeddings']  # Use for decision making
```

### 2. **DDRL Framework** (`DDRL_Framework/`)

**Distributed deep reinforcement learning with Byzantine fault tolerance**

#### Features:
- ✅ **Multi-Agent Support**: Manage hundreds of learning agents
- ✅ **Consensus Algorithms**: Trimmed mean, Krum, FedAvg implementations
- ✅ **Hardware Callbacks**: Integration hooks for real hardware
- ✅ **Model Deployment**: Export trained models for production

#### API Usage:
```python
from DDRL_Framework import DDRL_API, AgentConfig, Experience

# Initialize distributed API
ddrl_api = DDRL_API(network_config={'byzantine_tolerance': 0.3})

# Register agents
config = AgentConfig(agent_id="vehicle_001", state_dim=8, action_dim=2)
ddrl_api.register_agent(config)

# Training loop
action = ddrl_api.select_action(agent_id, state)
ddrl_api.store_experience(Experience(...))
ddrl_api.update_agent(agent_id)

# Consensus update
consensus_results = ddrl_api.perform_consensus_update()
```

### 3. **Adaptive Policy Selector**

**6G network-aware policy adaptation system**

#### Features:
- ✅ **Real-time 6G Monitoring**: uRLLC/eMBB mode detection
- ✅ **Adaptive Weights**: Dynamic λ_uRLLC and λ_eMBB adjustment
- ✅ **Network Simulation**: Realistic 6G condition modeling
- ✅ **Visual Feedback**: Live display in simulation interface

#### Network Parameters (6G Enhanced):
- **uRLLC**: 0.1-1ms latency, 100-500 Mbps bandwidth
- **eMBB**: 1-5ms latency, 1-10 Gbps bandwidth
- **Mixed Mode**: Adaptive blending based on conditions

### 4. **Enhanced Simulation Interface**

**Beautiful, real-time visualization with comprehensive metrics**

#### Features:
- ✅ **Animated Status Indicators**: Live component health monitoring
- ✅ **6G Network Dashboard**: Real-time latency/bandwidth display
- ✅ **Adaptive Weight Visualization**: Progress bars for λ parameters
- ✅ **Consensus Tracking**: Model update and synchronization metrics
- ✅ **Performance Analytics**: Training progress and system health

---

## 🛠️ Installation & Setup

### Prerequisites
```bash
# Required packages
pip install torch torchvision
pip install torch-geometric
pip install pygame numpy
pip install matplotlib scipy
```

### Quick Start
```bash
# Clone and setup
cd CTLC_Framework
python3 -m venv venv
source venv/bin/activate  # On macOS/Linux
pip install -r requirements.txt

# Run main simulation
python3 run.py

# Run framework examples
python3 ST_GNN_Framework/examples/third_party_integration.py
python3 DDRL_Framework/examples/distributed_training.py
```

---

## 📋 API Reference

### ST-GNN Framework API

```python
class STGNN_API:
    def __init__(self, config: Dict[str, Any])
    def register_device(self, node: NetworkNode) -> bool
    def update_network_topology(self, edges: List[NetworkEdge]) -> bool
    def process_realtime_data(self, nodes, edges) -> Dict[str, torch.Tensor]
    def export_model_for_hardware(self, output_path: str, format: str) -> bool
    def get_processing_stats(self) -> Dict[str, Any]
```

### DDRL Framework API

```python
class DDRL_API:
    def __init__(self, network_config: Dict[str, Any])
    def register_agent(self, config: AgentConfig) -> bool
    def select_action(self, agent_id: str, state: np.ndarray) -> np.ndarray
    def store_experience(self, experience: Experience) -> bool
    def update_agent(self, agent_id: str) -> Dict[str, float]
    def perform_consensus_update(self) -> Dict[str, Any]
    def export_agent_model(self, agent_id: str, output_path: str) -> bool
    def register_hardware_callback(self, event_type: str, callback: Callable)
```

---

## 🎯 Use Cases & Applications

### 1. **Autonomous Vehicle Fleets**
- Real-time coordination between vehicles
- Distributed learning for traffic optimization
- Safety-critical decision making with HOCBF

### 2. **6G Edge Computing**
- Dynamic resource allocation based on network conditions
- Ultra-low latency applications (uRLLC)
- High-throughput data processing (eMBB)

### 3. **Smart City Infrastructure**
- Vehicle-to-infrastructure communication
- Traffic light optimization
- Emergency response coordination

### 4. **Research & Development**
- Algorithm validation and comparison
- Performance benchmarking
- Hardware-in-the-loop testing

---

## 📊 Performance Metrics

### ST-GNN Processing:
- **Latency**: <50ms for real-time inference
- **Throughput**: 100+ nodes per second
- **Memory**: <500MB for 50-node networks

### DDRL Training:
- **Convergence**: 500-1000 episodes typical
- **Consensus Time**: <100ms for 20 agents
- **Byzantine Tolerance**: Up to 30% malicious agents

### 6G Network Simulation:
- **uRLLC Latency**: 0.1-1ms realistic simulation
- **eMBB Bandwidth**: 1-10 Gbps throughput modeling
- **Mode Switching**: <10ms adaptation time

---

## 🔧 Hardware Integration

### Third-Party Device Support:
- **Vehicle ECUs**: CAN bus integration ready
- **Edge Servers**: REST API and gRPC support
- **5G/6G Modems**: Real network condition monitoring
- **FPGA/GPU**: Model deployment with ONNX export

### Example Integration:
```python
# Register hardware callback for real vehicle
def vehicle_control_callback(agent_id, state, action):
    # Send action to actual vehicle ECU
    vehicle_ecu.send_control_command(action)

ddrl_api.register_hardware_callback('post_action', vehicle_control_callback)
```

---

## 🏆 Research Contributions

This framework implements and validates several research contributions:

1. **Consensus-Driven DDRL**: Byzantine fault-tolerant distributed learning
2. **6G-Aware Adaptation**: Real-time network condition response
3. **ST-GNN for Vehicular Networks**: Spatio-temporal graph processing
4. **HOCBF Safety Integration**: Formal safety guarantees
5. **Multi-Modal Sensor Fusion**: Heterogeneous data processing

---

## 📚 Examples & Tutorials

### Getting Started:
1. **Basic Simulation**: `python3 run.py`
2. **ST-GNN Integration**: `ST_GNN_Framework/examples/third_party_integration.py`
3. **Distributed Training**: `DDRL_Framework/examples/distributed_training.py`
4. **Validation Demo**: `python3 validation_demo.py`

### Advanced Usage:
- Custom consensus algorithms implementation
- Hardware-specific model optimization
- Real-time performance tuning
- Multi-environment deployment

---

## 🤝 Contributing

We welcome contributions to the CTLC Framework! Please see our contribution guidelines and submit pull requests for:

- New consensus algorithms
- Hardware integration modules  
- Performance optimizations
- Documentation improvements

---

## 📞 Support & Contact

For technical support, research collaboration, or commercial licensing:

- **Research Team**: CTLC Framework Development Team
- **Documentation**: See `/docs` for detailed technical specifications
- **Issues**: Use GitHub issues for bug reports and feature requests

---

## 📜 License

This framework is released under the MIT License. See `LICENSE` file for details.

**🎉 The CTLC Framework - Enabling the future of 6G-aware autonomous vehicular coordination!** 