#!/usr/bin/env python3
"""
AI Architecture Diagrams Generator
For DDRL and ST-GNN Working Principles
Enhanced Layout with No Overlapping
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle, ConnectionPatch, Arrow
import numpy as np
import base64
import io

# Set font for better display
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

def generate_ddrl_architecture():
    """Generate DDRL Architecture Diagram - Enhanced Layout"""
    fig, ax = plt.subplots(1, 1, figsize=(16, 12))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 12)
    ax.axis('off')
    
    # Title
    ax.text(8, 11.2, 'Distributed Deep Reinforcement Learning (DDRL) Architecture', 
            fontsize=18, fontweight='bold', ha='center', color='#2c3e50')
    
    # Agent 1 (Top Left)
    agent1 = FancyBboxPatch((1, 8.5), 4, 1.8, boxstyle="round,pad=0.15", 
                           facecolor='#3498db', edgecolor='#2980b9', linewidth=2)
    ax.add_patch(agent1)
    ax.text(3, 9.4, 'Agent 1', ha='center', va='center', fontsize=12, fontweight='bold', color='white')
    ax.text(3, 9.0, 'Policy Network Pi_1', ha='center', va='center', fontsize=10, color='white')
    ax.text(3, 8.7, 'Actor-Critic', ha='center', va='center', fontsize=9, color='white')
    
    # Agent 2 (Top Center)
    agent2 = FancyBboxPatch((6, 8.5), 4, 1.8, boxstyle="round,pad=0.15", 
                           facecolor='#27ae60', edgecolor='#229954', linewidth=2)
    ax.add_patch(agent2)
    ax.text(8, 9.4, 'Agent 2', ha='center', va='center', fontsize=12, fontweight='bold', color='white')
    ax.text(8, 9.0, 'Policy Network Pi_2', ha='center', va='center', fontsize=10, color='white')
    ax.text(8, 8.7, 'Actor-Critic', ha='center', va='center', fontsize=9, color='white')
    
    # Agent N (Top Right)
    agent_n = FancyBboxPatch((11, 8.5), 4, 1.8, boxstyle="round,pad=0.15", 
                            facecolor='#e74c3c', edgecolor='#c0392b', linewidth=2)
    ax.add_patch(agent_n)
    ax.text(13, 9.4, 'Agent N', ha='center', va='center', fontsize=12, fontweight='bold', color='white')
    ax.text(13, 9.0, 'Policy Network Pi_N', ha='center', va='center', fontsize=10, color='white')
    ax.text(13, 8.7, 'Actor-Critic', ha='center', va='center', fontsize=9, color='white')
    
    # Shared Experience Buffer (Middle)
    buffer = FancyBboxPatch((4, 6), 8, 1.5, boxstyle="round,pad=0.15", 
                           facecolor='#f39c12', edgecolor='#e67e22', linewidth=2)
    ax.add_patch(buffer)
    ax.text(8, 6.9, 'Shared Experience Buffer', ha='center', va='center', fontsize=12, fontweight='bold', color='white')
    ax.text(8, 6.5, '(state, action, reward, next_state)', ha='center', va='center', fontsize=10, color='white')
    ax.text(8, 6.2, 'Distributed Memory Pool', ha='center', va='center', fontsize=9, color='white')
    
    # Byzantine Consensus Manager (Middle-Lower)
    consensus = FancyBboxPatch((3, 4), 10, 1.5, boxstyle="round,pad=0.15", 
                              facecolor='#9b59b6', edgecolor='#8e44ad', linewidth=2)
    ax.add_patch(consensus)
    ax.text(8, 4.9, 'Byzantine Fault-Tolerant Consensus Manager', ha='center', va='center', fontsize=12, fontweight='bold', color='white')
    ax.text(8, 4.5, 'Gradient Aggregation & Malicious Node Detection', ha='center', va='center', fontsize=10, color='white')
    ax.text(8, 4.2, 'Trust-based Model Fusion', ha='center', va='center', fontsize=9, color='white')
    
    # Global Model Update (Bottom)
    global_model = FancyBboxPatch((4, 2), 8, 1.5, boxstyle="round,pad=0.15", 
                                 facecolor='#34495e', edgecolor='#2c3e50', linewidth=2)
    ax.add_patch(global_model)
    ax.text(8, 2.9, 'Global Model Update', ha='center', va='center', fontsize=12, fontweight='bold', color='white')
    ax.text(8, 2.5, 'Theta[t+1] = Theta[t] - alpha * gradient', ha='center', va='center', fontsize=10, color='white')
    ax.text(8, 2.2, 'Synchronized Parameter Broadcasting', ha='center', va='center', fontsize=9, color='white')
    
    # Communication arrows (Enhanced with colors)
    # Agents to Buffer
    ax.annotate('', xy=(6, 6.8), xytext=(3, 8.5), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#3498db'))
    ax.annotate('', xy=(8, 6.8), xytext=(8, 8.5), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#27ae60'))
    ax.annotate('', xy=(10, 6.8), xytext=(13, 8.5), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#e74c3c'))
    
    # Buffer to Consensus
    ax.annotate('', xy=(8, 5.5), xytext=(8, 6), 
                arrowprops=dict(arrowstyle='->', lw=3, color='#f39c12'))
    
    # Consensus to Global Model
    ax.annotate('', xy=(8, 3.5), xytext=(8, 4), 
                arrowprops=dict(arrowstyle='->', lw=3, color='#9b59b6'))
    
    # Global Model back to Agents (Curved arrows)
    ax.annotate('', xy=(3, 8.5), xytext=(5, 2.8), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#34495e', 
                               connectionstyle="arc3,rad=0.3"))
    ax.annotate('', xy=(8, 8.5), xytext=(8, 3.5), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#34495e'))
    ax.annotate('', xy=(13, 8.5), xytext=(11, 2.8), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#34495e', 
                               connectionstyle="arc3,rad=-0.3"))
    
    # Add data flow labels
    ax.text(4.5, 7.8, 'Experience\nSharing', ha='center', va='center', fontsize=8, 
            bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
    ax.text(8.5, 5.2, 'Consensus\nProtocol', ha='center', va='center', fontsize=8,
            bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
    ax.text(1.5, 5.5, 'Model\nSync', ha='center', va='center', fontsize=8,
            bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
    
    # Mathematical formulation box
    math_box = FancyBboxPatch((0.5, 0.2), 7, 1.5, boxstyle="round,pad=0.1", 
                             facecolor='#ecf0f1', edgecolor='#bdc3c7', linewidth=1)
    ax.add_patch(math_box)
    ax.text(4, 1.4, 'Mathematical Foundation', fontsize=11, fontweight='bold', ha='center', color='#2c3e50')
    ax.text(0.8, 1.0, '• Policy Networks: Pi_1, Pi_2, ..., Pi_N', fontsize=9, color='#2c3e50')
    ax.text(0.8, 0.7, '• Experience: (s, a, r, s_next)', fontsize=9, color='#2c3e50')
    ax.text(0.8, 0.4, '• Update Rule: Theta_new = Theta - alpha * nabla_J(Theta)', fontsize=9, color='#2c3e50')
    
    # Performance metrics box
    perf_box = FancyBboxPatch((8.5, 0.2), 7, 1.5, boxstyle="round,pad=0.1", 
                             facecolor='#e8f5e8', edgecolor='#27ae60', linewidth=1)
    ax.add_patch(perf_box)
    ax.text(12, 1.4, 'Key Advantages', fontsize=11, fontweight='bold', ha='center', color='#27ae60')
    ax.text(8.8, 1.0, '• Scalable Multi-Agent Learning', fontsize=9, color='#27ae60')
    ax.text(8.8, 0.7, '• Byzantine Fault Tolerance > 95%', fontsize=9, color='#27ae60')
    ax.text(8.8, 0.4, '• Distributed Decision Making', fontsize=9, color='#27ae60')
    
    plt.tight_layout()
    
    # Convert to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight', facecolor='white')
    buffer.seek(0)
    chart_data = base64.b64encode(buffer.getvalue()).decode()
    plt.close()
    
    return chart_data

def generate_stgnn_architecture():
    """Generate ST-GNN Architecture Diagram - Enhanced Layout"""
    fig, ax = plt.subplots(1, 1, figsize=(16, 12))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 12)
    ax.axis('off')
    
    # Title
    ax.text(8, 11.2, 'Spatio-Temporal Graph Neural Network (ST-GNN) Architecture', 
            fontsize=18, fontweight='bold', ha='center', color='#2c3e50')
    
    # Input Layer - Multi-sensor (Top Row)
    input_lidar = FancyBboxPatch((0.5, 9), 3, 1.5, boxstyle="round,pad=0.1", 
                               facecolor='#1abc9c', edgecolor='#16a085', linewidth=2)
    ax.add_patch(input_lidar)
    ax.text(2, 9.75, 'LiDAR Input', ha='center', va='center', fontsize=10, fontweight='bold', color='white')
    ax.text(2, 9.4, 'Point Cloud Data', ha='center', va='center', fontsize=9, color='white')
    
    input_camera = FancyBboxPatch((4, 9), 3, 1.5, boxstyle="round,pad=0.1", 
                                facecolor='#3498db', edgecolor='#2980b9', linewidth=2)
    ax.add_patch(input_camera)
    ax.text(5.5, 9.75, 'Camera Input', ha='center', va='center', fontsize=10, fontweight='bold', color='white')
    ax.text(5.5, 9.4, 'Visual Features', ha='center', va='center', fontsize=9, color='white')
    
    input_v2x = FancyBboxPatch((7.5, 9), 3, 1.5, boxstyle="round,pad=0.1", 
                             facecolor='#9b59b6', edgecolor='#8e44ad', linewidth=2)
    ax.add_patch(input_v2x)
    ax.text(9, 9.75, 'V2V/V2I Input', ha='center', va='center', fontsize=10, fontweight='bold', color='white')
    ax.text(9, 9.4, 'Communication Data', ha='center', va='center', fontsize=9, color='white')
    
    input_dynamics = FancyBboxPatch((11, 9), 3, 1.5, boxstyle="round,pad=0.1", 
                                  facecolor='#e67e22', edgecolor='#d35400', linewidth=2)
    ax.add_patch(input_dynamics)
    ax.text(12.5, 9.75, 'Vehicle Dynamics', ha='center', va='center', fontsize=10, fontweight='bold', color='white')
    ax.text(12.5, 9.4, 'Speed, Position', ha='center', va='center', fontsize=9, color='white')
    
    # Graph Construction Layer (Second Row)
    graph_construct = FancyBboxPatch((2, 7), 5, 1.5, boxstyle="round,pad=0.1", 
                                   facecolor='#27ae60', edgecolor='#229954', linewidth=2)
    ax.add_patch(graph_construct)
    ax.text(4.5, 7.9, 'Dynamic Graph Construction', ha='center', va='center', fontsize=11, fontweight='bold', color='white')
    ax.text(4.5, 7.5, 'Adjacency Matrix: A_t = f(positions, connectivity)', ha='center', va='center', fontsize=9, color='white')
    ax.text(4.5, 7.2, 'Temporal Graph Generation', ha='center', va='center', fontsize=8, color='white')
    
    # Feature Embedding (Second Row Right)
    feature_embed = FancyBboxPatch((9, 7), 5, 1.5, boxstyle="round,pad=0.1", 
                                 facecolor='#f39c12', edgecolor='#e67e22', linewidth=2)
    ax.add_patch(feature_embed)
    ax.text(11.5, 7.9, 'Feature Embedding Layer', ha='center', va='center', fontsize=11, fontweight='bold', color='white')
    ax.text(11.5, 7.5, 'Node Features: X in R^(N x d)', ha='center', va='center', fontsize=9, color='white')
    ax.text(11.5, 7.2, 'Multi-dimensional Encoding', ha='center', va='center', fontsize=8, color='white')
    
    # Spatial Processing (Third Row Left)
    spatial_gcn = FancyBboxPatch((1, 5), 6, 1.5, boxstyle="round,pad=0.1", 
                               facecolor='#e74c3c', edgecolor='#c0392b', linewidth=2)
    ax.add_patch(spatial_gcn)
    ax.text(4, 5.9, 'Spatial Graph Convolution (GCN)', ha='center', va='center', fontsize=11, fontweight='bold', color='white')
    ax.text(4, 5.5, 'H^(l+1) = sigma(A_hat * H^(l) * W^(l))', ha='center', va='center', fontsize=9, color='white')
    ax.text(4, 5.2, 'Neighborhood Information Aggregation', ha='center', va='center', fontsize=8, color='white')
    
    # Temporal Processing (Third Row Right)
    temporal_attn = FancyBboxPatch((9, 5), 6, 1.5, boxstyle="round,pad=0.1", 
                                 facecolor='#3498db', edgecolor='#2980b9', linewidth=2)
    ax.add_patch(temporal_attn)
    ax.text(12, 5.9, 'Temporal Attention Mechanism', ha='center', va='center', fontsize=11, fontweight='bold', color='white')
    ax.text(12, 5.5, 'Attention = softmax(Q*K^T / sqrt(d))', ha='center', va='center', fontsize=9, color='white')
    ax.text(12, 5.2, 'Sequential Pattern Learning', ha='center', va='center', fontsize=8, color='white')
    
    # Fusion Layer (Fourth Row)
    fusion_layer = FancyBboxPatch((4, 3), 8, 1.5, boxstyle="round,pad=0.1", 
                                facecolor='#9b59b6', edgecolor='#8e44ad', linewidth=2)
    ax.add_patch(fusion_layer)
    ax.text(8, 3.9, 'Spatio-Temporal Fusion Layer', ha='center', va='center', fontsize=12, fontweight='bold', color='white')
    ax.text(8, 3.5, 'Z = Attention(H_spatial, H_temporal)', ha='center', va='center', fontsize=10, color='white')
    ax.text(8, 3.2, 'Multi-head Cross-attention Mechanism', ha='center', va='center', fontsize=9, color='white')
    
    # Output Layer (Bottom)
    output_layer = FancyBboxPatch((2, 1), 12, 1.5, boxstyle="round,pad=0.1", 
                                facecolor='#34495e', edgecolor='#2c3e50', linewidth=2)
    ax.add_patch(output_layer)
    ax.text(8, 1.9, 'Multi-task Output Predictions', ha='center', va='center', fontsize=12, fontweight='bold', color='white')
    ax.text(5, 1.5, 'Motion Planning', ha='center', va='center', fontsize=10, color='white')
    ax.text(8, 1.5, 'Safety Control', ha='center', va='center', fontsize=10, color='white')
    ax.text(11, 1.5, 'Consensus Decision', ha='center', va='center', fontsize=10, color='white')
    ax.text(8, 1.2, 'Real-time Trajectory & Speed & Communication Planning', ha='center', va='center', fontsize=9, color='white')
    
    # Data flow arrows (Enhanced)
    # Input to Graph Construction
    ax.annotate('', xy=(3, 7.8), xytext=(2, 9), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#1abc9c'))
    ax.annotate('', xy=(4, 7.8), xytext=(5.5, 9), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#3498db'))
    ax.annotate('', xy=(5, 7.8), xytext=(9, 9), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#9b59b6'))
    
    # Input to Feature Embedding
    ax.annotate('', xy=(10, 7.8), xytext=(12.5, 9), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#e67e22'))
    
    # Graph Construction to Spatial GCN
    ax.annotate('', xy=(4, 6.5), xytext=(4.5, 7), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#27ae60'))
    
    # Feature Embedding to Temporal Attention
    ax.annotate('', xy=(12, 6.5), xytext=(11.5, 7), 
                arrowprops=dict(arrowstyle='->', lw=2, color='#f39c12'))
    
    # Spatial and Temporal to Fusion
    ax.annotate('', xy=(6, 4.5), xytext=(4, 5), 
                arrowprops=dict(arrowstyle='->', lw=3, color='#e74c3c'))
    ax.annotate('', xy=(10, 4.5), xytext=(12, 5), 
                arrowprops=dict(arrowstyle='->', lw=3, color='#3498db'))
    
    # Fusion to Output
    ax.annotate('', xy=(8, 2.5), xytext=(8, 3), 
                arrowprops=dict(arrowstyle='->', lw=3, color='#9b59b6'))
    
    # Add process labels
    ax.text(1.5, 8, 'Sensor\nFusion', ha='center', va='center', fontsize=8, 
            bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
    ax.text(14.5, 6, 'Feature\nExtraction', ha='center', va='center', fontsize=8,
            bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
    ax.text(8, 0.5, 'Decision\nMaking', ha='center', va='center', fontsize=8,
            bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
    
    plt.tight_layout()
    
    # Convert to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', dpi=200, bbox_inches='tight', facecolor='white')
    buffer.seek(0)
    chart_data = base64.b64encode(buffer.getvalue()).decode()
    plt.close()
    
    return chart_data

if __name__ == "__main__":
    # Test the functions
    print("Generating Enhanced DDRL Architecture...")
    ddrl_chart = generate_ddrl_architecture()
    print(f"DDRL Chart generated: {len(ddrl_chart)} characters")
    
    print("Generating Enhanced ST-GNN Architecture...")
    stgnn_chart = generate_stgnn_architecture()
    print(f"ST-GNN Chart generated: {len(stgnn_chart)} characters") 