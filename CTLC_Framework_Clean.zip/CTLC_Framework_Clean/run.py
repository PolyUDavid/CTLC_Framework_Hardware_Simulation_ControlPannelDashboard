import pygame
import sys
import traceback

from src.utils.config import Config
from src.simulation.simulation_manager import SimulationManager

def main():
    """
    The main entry point for the simulation.
    Initializes Pygame and starts the SimulationManager.
    """
    pygame.init()
    pygame.display.set_caption("CTLC Framework: Consensus-Driven DDRL Simulation")
    screen = pygame.display.set_mode((Config.WIDTH, Config.HEIGHT))
    
    sim_manager = None
    try:
        sim_manager = SimulationManager(screen)
        
        print("Starting CTLC Framework Simulation...")
        
        running = True
        while running:
            # Event handling
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
            
            # Handle keyboard input for dynamic vehicle spawning
            keys = pygame.key.get_pressed()
            sim_manager.handle_keyboard_input(keys)
            
            # Drive the simulation one step forward (includes rendering)
            sim_manager.step()

    except Exception as e:
        print("\n" + "="*60)
        print("AN ERROR OCCURRED: The simulation has been terminated.")
        print("="*60)
        print(f"Error Type: {type(e).__name__}")
        print(f"Error Details: {e}")
        print("-"*60)
        print("Traceback:")
        traceback.print_exc()
        print("="*60)
        
    finally:
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    main()
