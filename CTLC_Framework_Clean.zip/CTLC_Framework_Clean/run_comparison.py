#!/usr/bin/env python3
"""
CTLC框架对比工具 - 集中式 vs 分布式
CTLC Framework Comparison Tool - Centralized vs Distributed

提供简单的界面来对比集中式和分布式决策的性能差异
Provides a simple interface to compare performance differences between centralized and distributed decision-making
"""

import os
import sys
import subprocess
import time

def print_banner():
    """显示程序横幅"""
    print("="*80)
    print("         CTLC框架对比工具 - 集中式 vs 分布式决策")
    print("         CTLC Framework Comparison Tool")
    print("="*80)
    print()

def print_menu():
    """显示主菜单"""
    print("📊 选择仿真模式 / Choose Simulation Mode:")
    print()
    print("1. 🏢 集中式决策仿真 (Centralized Decision-Making)")
    print("   - 中央控制器统一决策")
    print("   - 车辆-中心通信模式") 
    print("   - 适合展示传统协调方式")
    print()
    print("2. 🤖 分布式决策仿真 (Distributed Decision-Making)")
    print("   - 每个车辆独立决策")
    print("   - 车辆-车辆点对点通信")
    print("   - 拜占庭容错，无单点故障")
    print()
    print("3. 📈 性能对比分析 (Performance Comparison)")
    print("   - 并行运行两个版本")
    print("   - 实时对比性能指标")
    print()
    print("4. 📖 查看技术文档 (View Documentation)")
    print("5. 🔄 系统状态检查 (System Status Check)")
    print("6. ❌ 退出 (Exit)")
    print()

def run_centralized():
    """运行集中式仿真"""
    print("🏢 启动集中式决策仿真...")
    print("Features: 6G网络 + 共识DDRL + HOCBF安全控制 + 多模态融合")
    print("Controls: SPACE=添加车辆, R=重置, ESC=退出, N=网络分析, C=共识指标")
    print("-" * 60)
    
    try:
        subprocess.run([sys.executable, "run_enhanced.py"], check=True)
    except KeyboardInterrupt:
        print("\n⚠️ 用户中断仿真")
    except subprocess.CalledProcessError as e:
        print(f"❌ 仿真运行错误: {e}")
    except FileNotFoundError:
        print("❌ 未找到 run_enhanced.py 文件")

def run_distributed():
    """运行分布式仿真"""
    print("🤖 启动分布式决策仿真...")
    print("Features: 分布式6G + 分布式共识 + 分布式安全控制 + 分布式多模态融合")
    print("Controls: SPACE=添加车辆, R=重置, ESC=退出, N=网络分析, C=共识指标")
    print("-" * 60)
    
    try:
        subprocess.run([sys.executable, "run_distributed.py"], check=True)
    except KeyboardInterrupt:
        print("\n⚠️ 用户中断仿真")
    except subprocess.CalledProcessError as e:
        print(f"❌ 仿真运行错误: {e}")
    except FileNotFoundError:
        print("❌ 未找到 run_distributed.py 文件")

def run_comparison():
    """并行运行两个版本进行对比"""
    print("📈 启动性能对比分析...")
    print("⚠️ 注意: 这将同时打开两个仿真窗口")
    print("左窗口: 集中式决策  |  右窗口: 分布式决策")
    print("-" * 60)
    
    try:
        # 启动集中式仿真
        print("🏢 启动集中式仿真...")
        proc1 = subprocess.Popen([sys.executable, "run_enhanced.py"])
        time.sleep(2)  # 等待第一个窗口启动
        
        # 启动分布式仿真
        print("🤖 启动分布式仿真...")
        proc2 = subprocess.Popen([sys.executable, "run_distributed.py"])
        
        print("✅ 两个仿真已启动，可以开始对比分析")
        print("💡 提示: 在两个窗口中执行相同操作，观察性能差异")
        
        # 等待进程结束
        proc1.wait()
        proc2.wait()
        
    except KeyboardInterrupt:
        print("\n⚠️ 用户中断对比")
        try:
            proc1.terminate()
            proc2.terminate()
        except:
            pass
    except Exception as e:
        print(f"❌ 对比运行错误: {e}")

def show_documentation():
    """显示技术文档"""
    print("📖 CTLC框架技术文档")
    print("="*50)
    
    docs = [
        ("README.md", "主要文档 - 系统概述"),
        ("README_Enhanced_CTLC_Framework.md", "增强功能文档"),
        ("README_Distributed_Simulation.md", "分布式仿真指南"),
        ("TECHNICAL_SPECIFICATIONS.md", "技术规范"),
        ("ENHANCED_FEATURES_SUMMARY.md", "功能特性总结")
    ]
    
    print("可用文档:")
    for i, (filename, description) in enumerate(docs, 1):
        exists = "✅" if os.path.exists(filename) else "❌"
        print(f"{i}. {exists} {filename} - {description}")
    
    print("\n💡 使用文本编辑器或IDE查看这些文档获取详细信息")

def check_system_status():
    """检查系统状态"""
    print("🔄 系统状态检查")
    print("="*30)
    
    # 检查Python版本
    print(f"🐍 Python版本: {sys.version}")
    
    # 检查关键文件
    files_to_check = [
        "run_enhanced.py",
        "run_distributed.py", 
        "src/",
        "requirements.txt",
        "venv/"
    ]
    
    print("\n📁 关键文件检查:")
    for file_path in files_to_check:
        exists = os.path.exists(file_path)
        status = "✅ 存在" if exists else "❌ 缺失"
        file_type = "目录" if os.path.isdir(file_path) else "文件"
        print(f"   {status} {file_path} ({file_type})")
    
    # 检查虚拟环境
    print(f"\n🌍 虚拟环境: {'✅ 激活' if hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix) else '⚠️ 未激活'}")
    
    # 检查依赖包
    print("\n📦 关键依赖包检查:")
    packages = ["pygame", "torch", "numpy", "cvxpy"]
    for package in packages:
        try:
            __import__(package)
            print(f"   ✅ {package}")
        except ImportError:
            print(f"   ❌ {package} (缺失)")

def main():
    """主函数"""
    print_banner()
    
    while True:
        print_menu()
        
        try:
            choice = input("请选择 (1-6): ").strip()
            print()
            
            if choice == "1":
                run_centralized()
            elif choice == "2":
                run_distributed()
            elif choice == "3":
                run_comparison()
            elif choice == "4":
                show_documentation()
            elif choice == "5":
                check_system_status()
            elif choice == "6":
                print("👋 感谢使用CTLC框架对比工具!")
                break
            else:
                print("❌ 无效选择，请输入 1-6")
            
            print("\n" + "="*60 + "\n")
            
        except KeyboardInterrupt:
            print("\n\n👋 感谢使用CTLC框架对比工具!")
            break
        except Exception as e:
            print(f"❌ 发生错误: {e}")

if __name__ == "__main__":
    main() 