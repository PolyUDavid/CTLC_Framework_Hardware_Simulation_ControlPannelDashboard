#!/usr/bin/env python3
"""
自动化实验可视化仪表盘
Automated Experiment Visualization Dashboard
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
import pandas as pd
import time
import threading
import queue
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any
import warnings
warnings.filterwarnings('ignore')

# 导入实验运行器
from quick_experiment_runner import QuickExperimentRunner
from automated_experiment_suite import AutomatedExperimentSuite, ExperimentConfig

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

class ExperimentDashboard:
    """实验仪表盘主界面"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("CP-DDRL 自动化实验仪表盘")
        self.root.geometry("1400x900")
        self.root.configure(bg='#f0f0f0')
        
        # 实验状态
        self.experiment_running = False
        self.current_experiment = None
        self.progress_queue = queue.Queue()
        
        # 实验结果存储
        self.experiment_results = {}
        self.real_time_data = {
            'time_points': [],
            'collision_rates': [],
            'avg_speeds': [],
            'communication_delays': [],
            'consensus_convergence': []
        }
        
        self.setup_ui()
        self.setup_plots()
        
    def setup_ui(self):
        """设置用户界面"""
        
        # 主标题
        title_frame = tk.Frame(self.root, bg='#2c3e50', height=60)
        title_frame.pack(fill='x', padx=5, pady=5)
        title_frame.pack_propagate(False)
        
        title_label = tk.Label(title_frame, 
                              text="🚗 CP-DDRL 分布式仿真实验平台", 
                              font=('Arial', 18, 'bold'),
                              fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # 主要内容区域
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        # 左侧控制面板
        self.setup_control_panel(main_frame)
        
        # 右侧可视化区域
        self.setup_visualization_area(main_frame)
        
    def setup_control_panel(self, parent):
        """设置左侧控制面板"""
        control_frame = tk.Frame(parent, bg='white', relief='raised', bd=2)
        control_frame.pack(side='left', fill='y', padx=(0, 5))
        control_frame.configure(width=350)
        control_frame.pack_propagate(False)
        
        # 控制面板标题
        control_title = tk.Label(control_frame, text="🎛️ 实验控制面板", 
                               font=('Arial', 14, 'bold'), bg='white')
        control_title.pack(pady=10)
        
        # 实验类型选择
        exp_type_frame = tk.LabelFrame(control_frame, text="实验类型", 
                                      font=('Arial', 10, 'bold'), bg='white')
        exp_type_frame.pack(fill='x', padx=10, pady=5)
        
        self.experiment_type = tk.StringVar(value="quick")
        tk.Radiobutton(exp_type_frame, text="快速对比实验 (5-10分钟)", 
                      variable=self.experiment_type, value="quick", bg='white').pack(anchor='w')
        tk.Radiobutton(exp_type_frame, text="完整实验套件 (1小时)", 
                      variable=self.experiment_type, value="full", bg='white').pack(anchor='w')
        
        # 实验参数设置
        params_frame = tk.LabelFrame(control_frame, text="实验参数", 
                                   font=('Arial', 10, 'bold'), bg='white')
        params_frame.pack(fill='x', padx=10, pady=5)
        
        # 仿真步数
        tk.Label(params_frame, text="仿真步数:", bg='white').pack(anchor='w')
        self.simulation_steps = tk.Scale(params_frame, from_=100, to=1000, 
                                       orient='horizontal', bg='white')
        self.simulation_steps.set(300)
        self.simulation_steps.pack(fill='x')
        
        # 重复次数
        tk.Label(params_frame, text="重复次数:", bg='white').pack(anchor='w')
        self.repeat_count = tk.Scale(params_frame, from_=1, to=10, 
                                   orient='horizontal', bg='white')
        self.repeat_count.set(3)
        self.repeat_count.pack(fill='x')
        
        # 控制按钮
        button_frame = tk.Frame(control_frame, bg='white')
        button_frame.pack(fill='x', padx=10, pady=10)
        
        self.start_button = tk.Button(button_frame, text="🚀 开始实验", 
                                    command=self.start_experiment,
                                    bg='#27ae60', fg='white', 
                                    font=('Arial', 12, 'bold'),
                                    height=2)
        self.start_button.pack(fill='x', pady=2)
        
        self.stop_button = tk.Button(button_frame, text="⏹️ 停止实验", 
                                   command=self.stop_experiment,
                                   bg='#e74c3c', fg='white', 
                                   font=('Arial', 12, 'bold'),
                                   height=2, state='disabled')
        self.stop_button.pack(fill='x', pady=2)
        
        self.save_button = tk.Button(button_frame, text="💾 保存结果", 
                                   command=self.save_results,
                                   bg='#3498db', fg='white', 
                                   font=('Arial', 12, 'bold'),
                                   height=2)
        self.save_button.pack(fill='x', pady=2)
        
        # 实验状态显示
        status_frame = tk.LabelFrame(control_frame, text="实验状态", 
                                   font=('Arial', 10, 'bold'), bg='white')
        status_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        self.status_text = scrolledtext.ScrolledText(status_frame, height=15, 
                                                   wrap=tk.WORD, bg='#f8f9fa')
        self.status_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        # 添加初始状态信息
        self.log_message("🔥 实验仪表盘已就绪")
        self.log_message("📋 请选择实验类型并点击开始实验")
        
    def setup_visualization_area(self, parent):
        """设置右侧可视化区域"""
        viz_frame = tk.Frame(parent, bg='white', relief='raised', bd=2)
        viz_frame.pack(side='right', fill='both', expand=True)
        
        # 可视化标题
        viz_title = tk.Label(viz_frame, text="📊 实时实验监控", 
                           font=('Arial', 14, 'bold'), bg='white')
        viz_title.pack(pady=10)
        
        # 创建选项卡
        self.notebook = ttk.Notebook(viz_frame)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=5)
        
        # 创建各个选项卡
        self.create_overview_tab()
        self.create_performance_tab()
        self.create_network_tab()
        self.create_safety_tab()
        
    def create_overview_tab(self):
        """创建概览选项卡"""
        overview_frame = ttk.Frame(self.notebook)
        self.notebook.add(overview_frame, text="🎯 实验概览")
        
        # 创建进度显示
        progress_frame = tk.Frame(overview_frame, bg='white')
        progress_frame.pack(fill='x', padx=10, pady=10)
        
        tk.Label(progress_frame, text="实验进度:", font=('Arial', 12, 'bold'), bg='white').pack(anchor='w')
        self.progress_bar = ttk.Progressbar(progress_frame, length=400, mode='determinate')
        self.progress_bar.pack(fill='x', pady=5)
        
        self.progress_label = tk.Label(progress_frame, text="准备就绪", bg='white')
        self.progress_label.pack(anchor='w')
        
        # 创建实时指标显示
        metrics_frame = tk.Frame(overview_frame, bg='white')
        metrics_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # 创建指标卡片
        self.create_metric_cards(metrics_frame)
        
    def create_metric_cards(self, parent):
        """创建指标卡片"""
        # 第一行指标
        row1 = tk.Frame(parent, bg='white')
        row1.pack(fill='x', pady=5)
        
        # 碰撞率卡片
        self.collision_card = self.create_single_metric_card(row1, "🚨 碰撞率", "0.00%", "#e74c3c")
        
        # 平均速度卡片
        self.speed_card = self.create_single_metric_card(row1, "🏃 平均速度", "0.00 m/s", "#3498db")
        
        # 第二行指标
        row2 = tk.Frame(parent, bg='white')
        row2.pack(fill='x', pady=5)
        
        # 通信延迟卡片
        self.delay_card = self.create_single_metric_card(row2, "📡 通信延迟", "0.00 ms", "#f39c12")
        
        # 共识收敛卡片
        self.consensus_card = self.create_single_metric_card(row2, "🤝 共识收敛", "0.00%", "#27ae60")
        
    def create_single_metric_card(self, parent, title, value, color):
        """创建单个指标卡片"""
        card_frame = tk.Frame(parent, bg=color, relief='raised', bd=2)
        card_frame.pack(side='left', fill='both', expand=True, padx=5)
        
        title_label = tk.Label(card_frame, text=title, font=('Arial', 10, 'bold'), 
                             fg='white', bg=color)
        title_label.pack(pady=(10, 5))
        
        value_label = tk.Label(card_frame, text=value, font=('Arial', 16, 'bold'), 
                             fg='white', bg=color)
        value_label.pack(pady=(0, 10))
        
        return {'frame': card_frame, 'title': title_label, 'value': value_label}
        
    def create_performance_tab(self):
        """创建性能对比选项卡"""
        performance_frame = ttk.Frame(self.notebook)
        self.notebook.add(performance_frame, text="📈 性能对比")
        
    def create_network_tab(self):
        """创建网络状态选项卡"""
        network_frame = ttk.Frame(self.notebook)
        self.notebook.add(network_frame, text="🌐 网络状态")
        
    def create_safety_tab(self):
        """创建安全性选项卡"""
        safety_frame = ttk.Frame(self.notebook)
        self.notebook.add(safety_frame, text="🛡️ 安全性分析")
        
    def setup_plots(self):
        """设置图表"""
        # 这里可以添加matplotlib图表
        pass
        
    def log_message(self, message):
        """记录日志消息"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] {message}\n"
        
        self.status_text.insert(tk.END, formatted_message)
        self.status_text.see(tk.END)
        self.root.update_idletasks()
        
    def start_experiment(self):
        """开始实验"""
        if self.experiment_running:
            return
            
        self.experiment_running = True
        self.start_button.config(state='disabled')
        self.stop_button.config(state='normal')
        
        exp_type = self.experiment_type.get()
        steps = self.simulation_steps.get()
        repeats = self.repeat_count.get()
        
        self.log_message(f"🚀 开始{exp_type}实验")
        self.log_message(f"📋 参数: {steps}步 × {repeats}次重复")
        
        # 重置进度条
        self.progress_bar['value'] = 0
        self.progress_label.config(text="初始化实验...")
        
        # 在后台线程中运行实验
        experiment_thread = threading.Thread(
            target=self.run_experiment_background,
            args=(exp_type, steps, repeats)
        )
        experiment_thread.daemon = True
        experiment_thread.start()
        
        # 启动进度更新
        self.update_progress()
        
    def run_experiment_background(self, exp_type, steps, repeats):
        """在后台运行实验"""
        try:
            if exp_type == "quick":
                self.run_quick_experiment(steps, repeats)
            else:
                self.run_full_experiment()
                
        except Exception as e:
            self.progress_queue.put(('error', f"实验错误: {str(e)}"))
        finally:
            self.progress_queue.put(('complete', None))
            
    def run_quick_experiment(self, steps, repeats):
        """运行快速实验"""
        runner = QuickExperimentRunner()
        
        # 阶段1: 基线实验
        self.progress_queue.put(('progress', 20, "运行基线实验..."))
        baseline_results = runner.run_baseline_experiment(steps, repeats)
        
        # 阶段2: 分布式实验
        self.progress_queue.put(('progress', 60, "运行分布式实验..."))
        distributed_results = runner.run_distributed_experiment(steps, repeats)
        
        # 阶段3: 分析结果
        self.progress_queue.put(('progress', 80, "分析实验结果..."))
        analysis = runner.analyze_results()
        
        # 阶段4: 生成可视化
        self.progress_queue.put(('progress', 95, "生成可视化图表..."))
        runner.generate_visualizations()
        
        # 保存结果
        self.experiment_results = {
            'baseline': baseline_results,
            'distributed': distributed_results,
            'analysis': analysis,
            'output_dir': runner.output_dir
        }
        
        self.progress_queue.put(('progress', 100, "实验完成!"))
        
    def run_full_experiment(self):
        """运行完整实验套件"""
        config = ExperimentConfig()
        suite = AutomatedExperimentSuite(config)
        
        # 8周实验流程
        phases = [
            ("第1-2周: 基线测试", suite.run_week_1_2_baseline_testing, 25),
            ("第3周: 系统开发", suite.run_week_3_system_development, 40),
            ("第4-5周: 分布式训练", suite.run_week_4_5_training, 65),
            ("第6-7周: 对比实验", suite.run_week_6_7_comparison, 85),
            ("第8周: 分析报告", suite.run_week_8_analysis, 100)
        ]
        
        results = {}
        for phase_name, phase_func, progress in phases:
            self.progress_queue.put(('progress', progress, phase_name))
            results[phase_name] = phase_func()
            
        self.experiment_results = results
        
    def update_progress(self):
        """更新进度显示"""
        try:
            while True:
                msg_type, data, *extra = self.progress_queue.get_nowait()
                
                if msg_type == 'progress':
                    progress, message = data, extra[0]
                    self.progress_bar['value'] = progress
                    self.progress_label.config(text=message)
                    self.log_message(f"📊 {message} ({progress}%)")
                    
                elif msg_type == 'error':
                    self.log_message(f"❌ {data}")
                    self.experiment_running = False
                    self.start_button.config(state='normal')
                    self.stop_button.config(state='disabled')
                    return
                    
                elif msg_type == 'complete':
                    self.log_message("✅ 实验成功完成!")
                    self.experiment_running = False
                    self.start_button.config(state='normal')
                    self.stop_button.config(state='disabled')
                    self.update_metric_cards()
                    return
                    
        except queue.Empty:
            pass
            
        if self.experiment_running:
            self.root.after(100, self.update_progress)
            
    def update_metric_cards(self):
        """更新指标卡片"""
        if not self.experiment_results:
            return
            
        try:
            # 从实验结果提取关键指标
            if 'analysis' in self.experiment_results:
                analysis = self.experiment_results['analysis']
                
                # 更新碰撞率
                if 'collision_rate_improvement' in analysis:
                    improvement = analysis['collision_rate_improvement']
                    self.collision_card['value'].config(text=f"{improvement:.2f}% ↓")
                    
                # 更新平均速度
                if 'avg_speed_improvement' in analysis:
                    improvement = analysis['avg_speed_improvement']
                    self.speed_card['value'].config(text=f"{improvement:.2f}% ↑")
                    
        except Exception as e:
            self.log_message(f"⚠️ 更新指标时出错: {str(e)}")
            
    def stop_experiment(self):
        """停止实验"""
        self.experiment_running = False
        self.start_button.config(state='normal')
        self.stop_button.config(state='disabled')
        self.log_message("⏹️ 实验已停止")
        
    def save_results(self):
        """保存实验结果"""
        if not self.experiment_results:
            self.log_message("⚠️ 没有可保存的实验结果")
            return
            
        try:
            output_dir = self.experiment_results.get('output_dir', 
                                                   f"dashboard_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
            
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
                
            # 保存JSON格式结果
            results_file = os.path.join(output_dir, "experiment_results.json")
            with open(results_file, 'w', encoding='utf-8') as f:
                json.dump(self.experiment_results, f, ensure_ascii=False, indent=2, default=str)
                
            self.log_message(f"💾 结果已保存到: {output_dir}")
            
        except Exception as e:
            self.log_message(f"❌ 保存失败: {str(e)}")
            
    def run(self):
        """运行仪表盘"""
        self.log_message("🌟 欢迎使用CP-DDRL实验仪表盘!")
        self.log_message("💡 选择实验类型，设置参数，然后点击开始实验")
        self.root.mainloop()

def main():
    """主函数"""
    print("🚀 启动CP-DDRL自动化实验仪表盘")
    
    try:
        dashboard = ExperimentDashboard()
        dashboard.run()
    except Exception as e:
        print(f"❌ 启动失败: {e}")
        input("按Enter键退出...")

if __name__ == "__main__":
    main() 