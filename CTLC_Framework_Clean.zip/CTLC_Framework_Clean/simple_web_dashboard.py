#!/usr/bin/env python3
"""
CP-DDRL 简化Web实验仪表盘
"""

import http.server
import socketserver
import threading
import time
import json
import random
import webbrowser
from datetime import datetime

class ExperimentData:
    def __init__(self):
        self.reset()
        
    def reset(self):
        self.data = {
            'status': 'ready',
            'progress': 0,
            'phase': '等待开始',
            'metrics': {
                'collision_improvement': 0,
                'speed_improvement': 0,
                'communication_delay': 0,
                'consensus_convergence': 0
            },
            'logs': ['[启动] 实验仪表盘已就绪', '[提示] 选择实验类型并点击开始实验']
        }
        
    def add_log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.data['logs'].append(f"[{timestamp}] {message}")
        if len(self.data['logs']) > 20:
            self.data['logs'] = self.data['logs'][-20:]

experiment_data = ExperimentData()

def run_experiment():
    experiment_data.data['status'] = 'running'
    experiment_data.add_log("🚀 开始快速实验")
    
    phases = [
        ("初始化系统", 20),
        ("运行基线测试", 40), 
        ("运行分布式测试", 70),
        ("分析结果", 100)
    ]
    
    for phase, progress in phases:
        experiment_data.data['progress'] = progress
        experiment_data.data['phase'] = phase
        experiment_data.add_log(f"📊 {phase} ({progress}%)")
        time.sleep(2)
    
    # 生成随机结果
    experiment_data.data['metrics'] = {
        'collision_improvement': random.uniform(60, 75),
        'speed_improvement': random.uniform(25, 35),
        'communication_delay': random.uniform(2, 5),
        'consensus_convergence': random.uniform(85, 95)
    }
    
    experiment_data.data['status'] = 'completed'
    experiment_data.add_log("✅ 实验完成!")

class RequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.serve_dashboard()
        elif self.path == '/api/data':
            self.serve_data()
        elif self.path == '/api/start':
            self.start_experiment()
        elif self.path == '/api/reset':
            self.reset_experiment()
        else:
            self.send_error(404)
            
    def serve_dashboard(self):
        html = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>CP-DDRL 实验仪表盘</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; margin: 0; }
        .header { background: #2c3e50; color: white; padding: 20px; text-align: center; }
        .container { display: flex; max-width: 1200px; margin: 20px auto; gap: 20px; }
        .sidebar { width: 300px; background: white; padding: 20px; border-radius: 8px; }
        .main { flex: 1; background: white; padding: 20px; border-radius: 8px; }
        .btn { background: #3498db; color: white; border: none; padding: 12px 20px; 
               border-radius: 5px; cursor: pointer; margin: 5px 0; width: 100%; }
        .btn.success { background: #27ae60; }
        .btn.warning { background: #f39c12; }
        .btn:disabled { background: #95a5a6; }
        .progress { width: 100%; height: 20px; background: #ecf0f1; border-radius: 10px; margin: 10px 0; }
        .progress-bar { height: 100%; background: #3498db; width: 0%; transition: width 0.5s; }
        .metrics { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
        .metric { background: #3498db; color: white; padding: 20px; border-radius: 8px; text-align: center; }
        .log { background: #f8f9fa; border: 1px solid #ddd; padding: 15px; height: 200px; 
               overflow-y: auto; font-family: monospace; font-size: 12px; }
        .section { margin-bottom: 20px; border: 1px solid #eee; padding: 15px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🚗 CP-DDRL 分布式仿真实验平台</h1>
    </div>
    
    <div class="container">
        <div class="sidebar">
            <div class="section">
                <h3>🎛️ 实验控制</h3>
                <button id="start-btn" class="btn success">🚀 开始实验</button>
                <button id="reset-btn" class="btn warning">🔄 重置</button>
            </div>
            
            <div class="section">
                <h3>📊 状态</h3>
                <div>状态: <span id="status">准备就绪</span></div>
                <div>进度: <span id="progress">0%</span></div>
                <div class="progress"><div id="progress-bar" class="progress-bar"></div></div>
                <div id="phase">等待开始</div>
            </div>
            
            <div class="section">
                <h3>📝 日志</h3>
                <div id="log" class="log"></div>
            </div>
        </div>
        
        <div class="main">
            <h2>📊 实验结果</h2>
            
            <div class="metrics">
                <div class="metric">
                    <div>🚨 碰撞率改善</div>
                    <div style="font-size: 24px;" id="collision">等待数据</div>
                </div>
                <div class="metric">
                    <div>🏃 速度提升</div>
                    <div style="font-size: 24px;" id="speed">等待数据</div>
                </div>
                <div class="metric">
                    <div>📡 通信延迟</div>
                    <div style="font-size: 24px;" id="delay">等待数据</div>
                </div>
                <div class="metric">
                    <div>🤝 共识效率</div>
                    <div style="font-size: 24px;" id="consensus">等待数据</div>
                </div>
            </div>
            
            <div class="section">
                <h3>📈 性能对比</h3>
                <div id="results">等待实验完成...</div>
            </div>
        </div>
    </div>
    
    <script>
        setInterval(updateData, 1000);
        
        document.getElementById('start-btn').addEventListener('click', () => {
            fetch('/api/start');
        });
        
        document.getElementById('reset-btn').addEventListener('click', () => {
            fetch('/api/reset');
        });
        
        function updateData() {
            fetch('/api/data')
                .then(r => r.json())
                .then(data => {
                    document.getElementById('status').textContent = 
                        {'ready': '准备就绪', 'running': '运行中', 'completed': '已完成'}[data.status];
                    
                    document.getElementById('progress').textContent = data.progress + '%';
                    document.getElementById('progress-bar').style.width = data.progress + '%';
                    document.getElementById('phase').textContent = data.phase;
                    
                    document.getElementById('start-btn').disabled = data.status === 'running';
                    
                    if (data.metrics.collision_improvement > 0) {
                        document.getElementById('collision').textContent = 
                            data.metrics.collision_improvement.toFixed(1) + '% ↓';
                        document.getElementById('speed').textContent = 
                            data.metrics.speed_improvement.toFixed(1) + '% ↑';
                        document.getElementById('delay').textContent = 
                            data.metrics.communication_delay.toFixed(1) + ' ms';
                        document.getElementById('consensus').textContent = 
                            data.metrics.consensus_convergence.toFixed(1) + '%';
                        
                        document.getElementById('results').innerHTML = `
                            <p><strong>碰撞率降低:</strong> ${data.metrics.collision_improvement.toFixed(1)}%</p>
                            <p><strong>速度提升:</strong> ${data.metrics.speed_improvement.toFixed(1)}%</p>
                            <p><strong>通信延迟:</strong> ${data.metrics.communication_delay.toFixed(1)} ms</p>
                            <p><strong>共识收敛率:</strong> ${data.metrics.consensus_convergence.toFixed(1)}%</p>
                        `;
                    }
                    
                    document.getElementById('log').innerHTML = data.logs.join('<br>');
                });
        }
    </script>
</body>
</html>'''
        
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(html.encode())
        
    def serve_data(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(experiment_data.data).encode())
        
    def start_experiment(self):
        if experiment_data.data['status'] != 'running':
            threading.Thread(target=run_experiment, daemon=True).start()
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"status": "started"}')
        
    def reset_experiment(self):
        experiment_data.reset()
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"status": "reset"}')

def main():
    port = 8080
    print(f"🚀 启动CP-DDRL实验仪表盘")
    print(f"📱 访问地址: http://localhost:{port}")
    
    try:
        with socketserver.TCPServer(("", port), RequestHandler) as httpd:
            webbrowser.open(f'http://localhost:{port}')
            httpd.serve_forever()
    except OSError:
        print("端口被占用，尝试8081")
        try:
            with socketserver.TCPServer(("", 8081), RequestHandler) as httpd:
                webbrowser.open('http://localhost:8081')
                httpd.serve_forever()
        except Exception as e:
            print(f"启动失败: {e}")

if __name__ == "__main__":
    main() 