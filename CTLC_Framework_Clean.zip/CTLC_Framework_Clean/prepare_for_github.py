#!/usr/bin/env python3
"""
GitHub Upload Preparation Script for CTLC Framework
准备CTLC框架代码上传到GitHub的脚本

This script creates a clean copy of the CTLC Framework suitable for GitHub upload.
该脚本创建一个适合上传到GitHub的CTLC框架清理版本。
"""

import os
import shutil
import json
from pathlib import Path

def should_exclude_file(file_path):
    """
    Determine if a file should be excluded from GitHub upload
    判断文件是否应该从GitHub上传中排除
    """
    exclude_patterns = [
        # macOS metadata files
        '._',
        '.DS_Store',
        
        # Python cache
        '__pycache__',
        '*.pyc',
        '*.pyo',
        
        # Virtual environment
        'venv/',
        
        # Log files
        '*.log',
        
        # Large data files (keep small ones)
        '*.xlsx',
        
        # Temporary experiment results
        'quick_experiment_',
        'comprehensive_experiment_results_',
        'seven_day_analysis_',
        'seven_day_detailed_analysis_',
        'vehicle_count_clarification_',
        
        # Binary files that are too large
        'verify_terminology.py',  # This file is 1GB+ corrupted
    ]
    
    file_str = str(file_path)
    for pattern in exclude_patterns:
        if pattern in file_str or file_str.startswith(pattern):
            return True
    return False

def copy_directory_structure(src_dir, dest_dir):
    """
    Copy directory structure while filtering files
    复制目录结构并过滤文件
    """
    if dest_dir.exists():
        shutil.rmtree(dest_dir)
    
    dest_dir.mkdir(parents=True, exist_ok=True)
    
    files_copied = 0
    files_skipped = 0
    
    for root, dirs, files in os.walk(src_dir):
        # Skip excluded directories
        dirs[:] = [d for d in dirs if not should_exclude_file(d)]
        
        # Create relative path
        rel_path = Path(root).relative_to(src_dir)
        dest_root = dest_dir / rel_path
        dest_root.mkdir(parents=True, exist_ok=True)
        
        for file in files:
            src_file = Path(root) / file
            dest_file = dest_root / file
            
            if should_exclude_file(file):
                files_skipped += 1
                print(f"Skipped: {src_file}")
                continue
            
            try:
                # Check file size (skip files > 100MB)
                if src_file.stat().st_size > 100 * 1024 * 1024:
                    files_skipped += 1
                    print(f"Skipped (too large): {src_file}")
                    continue
                
                shutil.copy2(src_file, dest_file)
                files_copied += 1
                print(f"Copied: {src_file} -> {dest_file}")
                
            except Exception as e:
                files_skipped += 1
                print(f"Error copying {src_file}: {e}")
    
    return files_copied, files_skipped

def create_github_readme():
    """
    Create an enhanced README for GitHub
    为GitHub创建增强版README
    """
    readme_content = '''# CTLC Framework - Hardware Simulation Control Panel Dashboard
# CTLC框架 - 硬件仿真控制面板仪表盘

**Consensus-Driven Trustworthy Learning and Control Framework for 6G-IoT Vehicular Systems**
**基于共识的可信学习与控制框架，适用于6G-IoT车联网系统**

## 🚀 Overview / 概述

The CTLC (Consensus-Driven Trustworthy Learning and Control) Framework is a comprehensive implementation for Connected and Automated Vehicle (CAV) coordination in 6G-IoT environments. This repository contains the complete source code, simulation tools, and real-time dashboard systems.

CTLC（基于共识的可信学习与控制）框架是针对6G-IoT环境中联网自动驾驶车辆(CAV)协调的综合实现。本仓库包含完整的源代码、仿真工具和实时仪表盘系统。

## 🌟 Key Features / 主要特性

### Core Components / 核心组件
- **🧠 Adaptive Policy Selector**: 6G-aware reward modulation / 6G感知的奖励调制
- **🤝 Consensus-Driven Learning**: Byzantine fault-tolerant learning / 拜占庭容错学习
- **🔗 Multi-modal Sensor Fusion**: ST-GNN backbone / 基于ST-GNN的多模态传感器融合
- **🛡️ Safety Layer**: HOCBF-inspired safety filtering / 基于HOCBF的安全过滤
- **📡 6G Network Simulation**: uRLLC/eMBB mode switching / uRLLC/eMBB模式切换

### Dashboard & Visualization / 仪表盘与可视化
- **Real-time Monitoring**: Live simulation data visualization / 实时仿真数据可视化
- **Web-based Dashboard**: Browser-accessible control panels / 基于浏览器的控制面板
- **Performance Analytics**: Comprehensive experiment analysis / 综合实验分析
- **Multi-language Support**: English and Chinese interfaces / 英中文界面支持

## 🚀 Quick Start / 快速开始

### Prerequisites / 先决条件
```bash
Python 3.8+
PyTorch with geometric extensions
Pygame for visualization
Flask for web dashboard
```

### Installation / 安装
```bash
# Clone the repository / 克隆仓库
git clone https://github.com/PolyUDavid/CTLC_Framework_Hardware_Simulation_ControlPannelDashboard.git
cd CTLC_Framework_Hardware_Simulation_ControlPannelDashboard

# Create virtual environment / 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\\Scripts\\activate

# Install dependencies / 安装依赖
pip install -r requirements.txt
```

### Running Simulations / 运行仿真

#### 1. Interactive Pygame Simulation / 交互式Pygame仿真
```bash
# Enhanced CTLC simulation / 增强型CTLC仿真
python3 run_enhanced.py

# Distributed simulation / 分布式仿真
python3 run_distributed.py
```

#### 2. Web Dashboard / 网页仪表盘
```bash
# English dashboard / 英文仪表盘
python3 english_dashboard.py

# Chinese dashboard / 中文仪表盘
python3 优化版仪表盘.py

# Simple web dashboard / 简单网页仪表盘
python3 simple_web_dashboard.py
```

#### 3. Quick Demo / 快速演示
```bash
# No-GUI comprehensive demo / 无GUI综合演示
python3 simple_demo.py

# Validation demo / 验证演示
python3 validation_demo.py
```

## 📁 Project Structure / 项目结构

```
CTLC_Framework/
├── src/                          # Core source code / 核心源代码
│   ├── simulation/              # Simulation engine / 仿真引擎
│   ├── models/                  # Neural network models / 神经网络模型
│   ├── agents/                  # Agent controllers / 智能体控制器
│   └── utils/                   # Utilities / 工具函数
├── DDRL_Framework/              # Distributed DRL / 分布式深度强化学习
├── ST_GNN_Framework/            # Spatio-Temporal GNN / 时空图神经网络
├── dashboards/                  # Dashboard applications / 仪表盘应用
├── docs/                        # Documentation / 文档
└── examples/                    # Example scripts / 示例脚本
```

## 🔧 Configuration / 配置

Key parameters can be modified in `src/utils/config.py`:
主要参数可在 `src/utils/config.py` 中修改：

```python
# Simulation Parameters / 仿真参数
NUM_VEHICLES = 5              # Number of vehicles / 车辆数量
CONSENSUS_ROUNDS = 50         # Consensus frequency / 共识频率
TRIMMED_MEAN_BETA = 0.1      # Fault tolerance / 容错参数

# Network Parameters / 网络参数
COMM_RANGE = 200             # V2X range / V2X通信范围
```

## 📊 Dashboard Features / 仪表盘功能

### Real-time Monitoring / 实时监控
- **Consensus Metrics**: Agreement rates, Byzantine detection / 共识指标：一致性率、拜占庭检测
- **Learning Progress**: Reward curves, policy adaptation / 学习进度：奖励曲线、策略适应
- **Network Status**: 6G mode switching, QoS metrics / 网络状态：6G模式切换、QoS指标
- **Safety Monitoring**: Collision avoidance, HOCBF status / 安全监控：避碰、HOCBF状态

### Interactive Controls / 交互控制
- **Start/Stop Simulation**: Real-time control / 启动/停止仿真：实时控制
- **Parameter Adjustment**: Live configuration updates / 参数调整：实时配置更新
- **Scenario Selection**: Pre-defined test cases / 场景选择：预定义测试用例
- **Data Export**: Results and visualizations / 数据导出：结果和可视化

## 🧪 Experiment Tools / 实验工具

### Automated Experiment Suite / 自动化实验套件
```bash
# Run comprehensive experiments / 运行综合实验
python3 automated_experiment_suite.py

# Generate analysis reports / 生成分析报告
python3 seven_day_data_analyzer.py

# Create performance plots / 创建性能图表
python3 generate_plots.py
```

### Performance Analysis / 性能分析
- **Multi-day Analysis**: Long-term performance tracking / 多日分析：长期性能跟踪
- **Comparative Studies**: Algorithm comparison / 对比研究：算法比较
- **Statistical Validation**: Hypothesis testing / 统计验证：假设检验

## 🌐 6G Network Features / 6G网络特性

### Network Mode Adaptation / 网络模式适应
- **uRLLC Mode**: Ultra-low latency for safety-critical / uRLLC模式：安全关键的超低延迟
- **eMBB Mode**: High bandwidth for data-intensive / eMBB模式：数据密集的高带宽
- **Dynamic Switching**: Real-time mode selection / 动态切换：实时模式选择

### V2X Communication / V2X通信
- **Vehicle-to-Vehicle (V2V)**: Inter-vehicle coordination / 车对车：车间协调
- **Vehicle-to-Infrastructure (V2I)**: RSU interactions / 车对基础设施：RSU交互
- **Vehicle-to-Network (V2N)**: Cloud connectivity / 车对网络：云连接

## 🔬 Research Validation / 研究验证

### Key Metrics Achieved / 达成的关键指标
- **+27.9% Learning Improvement**: From consensus-driven approach / 基于共识方法的27.9%学习改进
- **Zero Collisions**: With HOCBF safety layer / 通过HOCBF安全层实现零碰撞
- **Byzantine Resilience**: Up to 30% malicious nodes / 拜占庭韧性：高达30%恶意节点
- **Real-time Performance**: <10ms consensus updates / 实时性能：<10ms共识更新

### Validation Results / 验证结果
- **6G Mode Distribution**: uRLLC(33%), eMBB(27%), Mixed(40%) / 6G模式分布
- **Consensus Convergence**: Stable under Byzantine attacks / 共识收敛：拜占庭攻击下稳定
- **Multi-modal Fusion**: Heterogeneous sensor integration / 多模态融合：异构传感器集成

## 📚 Documentation / 文档

### Technical Specifications / 技术规格
- [Technical Specifications](TECHNICAL_SPECIFICATIONS.md) / [技术规格](TECHNICAL_SPECIFICATIONS.md)
- [ST-GNN Details](ST-GNN技术规格详细说明.md) / [ST-GNN详情](ST-GNN技术规格详细说明.md)
- [Dashboard User Guide](English_Dashboard_User_Guide.md) / [仪表盘用户指南](English_Dashboard_User_Guide.md)

### Research Papers / 研究论文
- [6G IoV Discussion](6G_IoV_Discussion_Section.md) / [6G车联网讨论](6G_IoV_Discussion_Section.md)
- [Paper Recommendations](PAPER_RECOMMENDATIONS.md) / [论文建议](PAPER_RECOMMENDATIONS.md)

## 🤝 Contributing / 贡献

We welcome contributions! Please see our contributing guidelines:
欢迎贡献！请查看我们的贡献指南：

1. Fork the repository / 分叉仓库
2. Create a feature branch / 创建功能分支
3. Commit your changes / 提交更改
4. Push to the branch / 推送到分支
5. Create a Pull Request / 创建拉取请求

## 📄 License / 许可证

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
本项目采用MIT许可证 - 详情请参阅[LICENSE](LICENSE)文件。

## 📞 Contact / 联系方式

- **Repository**: https://github.com/PolyUDavid/CTLC_Framework_Hardware_Simulation_ControlPannelDashboard
- **Issues**: Please use GitHub Issues for bug reports and feature requests
- **问题反馈**: 请使用GitHub Issues报告错误和功能请求

## 🙏 Acknowledgments / 致谢

This work is supported by research in Connected and Automated Vehicles (CAV) and 6G-IoT systems. Special thanks to the open-source community for the foundational tools and libraries.

本工作得到了联网自动驾驶车辆(CAV)和6G-IoT系统研究的支持。特别感谢开源社区提供的基础工具和库。

---

**For more information, please refer to the detailed documentation and examples in this repository.**
**更多信息，请参考本仓库中的详细文档和示例。**
'''
    
    return readme_content

def create_gitignore():
    """
    Create a comprehensive .gitignore file
    创建综合的.gitignore文件
    """
    gitignore_content = '''# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# Virtual Environment
venv/
env/
ENV/

# PyTorch
*.pth
*.pt

# Jupyter Notebook
.ipynb_checkpoints

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Logs
*.log
logs/

# Experiment Results
quick_experiment_*/
comprehensive_experiment_results_*.json
seven_day_analysis_*.txt
seven_day_detailed_analysis_*.json
vehicle_count_clarification_*.json
vehicle_count_clarification_*.txt

# Large Data Files
*.xlsx
*.xls
*.csv
data/
results/

# Temporary Files
*.tmp
*.temp
'''
    return gitignore_content

def main():
    """
    Main function to prepare CTLC Framework for GitHub upload
    准备CTLC框架上传到GitHub的主函数
    """
    print("🚀 Preparing CTLC Framework for GitHub Upload")
    print("🚀 准备CTLC框架上传到GitHub")
    print("=" * 50)
    
    # Define paths
    current_dir = Path.cwd()
    src_dir = current_dir
    dest_dir = current_dir / "CTLC_Framework_GitHub_Ready"
    
    print(f"📁 Source Directory: {src_dir}")
    print(f"📁 Destination Directory: {dest_dir}")
    print()
    
    # Copy directory structure
    print("📋 Copying files...")
    files_copied, files_skipped = copy_directory_structure(src_dir, dest_dir)
    
    # Create enhanced README
    print("📝 Creating enhanced README.md...")
    readme_path = dest_dir / "README.md"
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(create_github_readme())
    
    # Create .gitignore
    print("🚫 Creating .gitignore...")
    gitignore_path = dest_dir / ".gitignore"
    with open(gitignore_path, 'w', encoding='utf-8') as f:
        f.write(create_gitignore())
    
    # Create upload instructions
    print("📋 Creating upload instructions...")
    instructions_path = dest_dir / "GITHUB_UPLOAD_INSTRUCTIONS.md"
    instructions_content = '''# GitHub Upload Instructions
# GitHub上传说明

## English Instructions

1. **Navigate to your destination directory:**
   ```bash
   cd CTLC_Framework_GitHub_Ready
   ```

2. **Initialize Git repository:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit: CTLC Framework complete implementation"
   ```

3. **Add remote repository:**
   ```bash
   git remote add origin https://github.com/PolyUDavid/CTLC_Framework_Hardware_Simulation_ControlPannelDashboard.git
   ```

4. **Push to GitHub:**
   ```bash
   git branch -M main
   git push -u origin main
   ```

## 中文说明

1. **导航到目标目录：**
   ```bash
   cd CTLC_Framework_GitHub_Ready
   ```

2. **初始化Git仓库：**
   ```bash
   git init
   git add .
   git commit -m "Initial commit: CTLC Framework complete implementation"
   ```

3. **添加远程仓库：**
   ```bash
   git remote add origin https://github.com/PolyUDavid/CTLC_Framework_Hardware_Simulation_ControlPannelDashboard.git
   ```

4. **推送到GitHub：**
   ```bash
   git branch -M main
   git push -u origin main
   ```

## Alternative: Using GitHub Desktop
## 替代方案：使用GitHub Desktop

1. Open GitHub Desktop
2. File → Add Local Repository
3. Choose the `CTLC_Framework_GitHub_Ready` folder
4. Publish repository to GitHub
5. Set repository name: `CTLC_Framework_Hardware_Simulation_ControlPannelDashboard`

## Files Prepared for Upload
## 准备上传的文件

This cleaned version includes:
这个清理版本包括：

- ✅ All source code and frameworks
- ✅ Documentation and user guides  
- ✅ Example scripts and demos
- ✅ Configuration files
- ✅ README with bilingual support
- ✅ Proper .gitignore file

Excluded:
排除的文件：

- ❌ Log files and temporary data
- ❌ Virtual environment folders
- ❌ macOS metadata files
- ❌ Large experimental result files
- ❌ Python cache files

Total size should be manageable for GitHub upload.
总大小应该适合GitHub上传。
'''
    
    with open(instructions_path, 'w', encoding='utf-8') as f:
        f.write(instructions_content)
    
    # Summary
    print()
    print("✅ Preparation Complete!")
    print("✅ 准备完成！")
    print("=" * 50)
    print(f"📊 Files copied: {files_copied}")
    print(f"📊 Files skipped: {files_skipped}")
    print(f"📁 Ready for upload: {dest_dir}")
    print()
    print("🔍 Next steps:")
    print("1. Review the GITHUB_UPLOAD_INSTRUCTIONS.md file")
    print("2. Navigate to the CTLC_Framework_GitHub_Ready directory")
    print("3. Follow the upload instructions")
    print()
    print("🔍 下一步：")
    print("1. 查看 GITHUB_UPLOAD_INSTRUCTIONS.md 文件")
    print("2. 导航到 CTLC_Framework_GitHub_Ready 目录")
    print("3. 按照上传说明进行操作")

if __name__ == "__main__":
    main() 