"""
Seven-Day Comprehensive Data Analyzer
七天完整数据分析器

从API实验结果中提取和分析：
1. 平峰、高峰、波谷时间对比
2. 周一-周五工作日对比  
3. 周六-周日周末对比
4. 完整七天趋势分析
"""

import json
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
from typing import Dict, List, Any, Tuple
import pandas as pd

class SevenDayDataAnalyzer:
    """七天数据分析器"""
    
    def __init__(self, results_file: str):
        """初始化分析器并加载数据"""
        print("📊 初始化七天数据分析器...")
        
        with open(results_file, 'r', encoding='utf-8') as f:
            self.raw_data = json.load(f)
        
        # 数据分类存储
        self.time_period_data = {
            'morning_peak': [],
            'evening_peak': [], 
            'normal': [],
            'valley': []
        }
        
        self.daily_data = {
            'Monday': [], 'Tuesday': [], 'Wednesday': [], 'Thursday': [], 'Friday': [],
            'Saturday': [], 'Sunday': []
        }
        
        self.weekday_data = []  # 周一到周五
        self.weekend_data = []  # 周六周日
        
        # 处理和分类数据
        self._process_raw_data()
        print("✅ 数据加载和分类完成！")
    
    def _process_raw_data(self):
        """处理原始数据并分类"""
        print("🔄 处理和分类原始数据...")
        
        for day_name, day_data in self.raw_data['daily_results'].items():
            day_scenarios = []
            
            for scenario in day_data['scenarios']:
                scenario_info = scenario['scenario_info']
                metrics = scenario['performance_metrics']
                
                # 提取关键指标
                processed_scenario = {
                    'name': scenario_info['name'],
                    'time_period': scenario_info['time_period'],
                    'day_type': scenario_info['day_type'],
                    'vehicle_count': scenario_info['vehicle_count'],
                    'collision_rate_baseline': metrics['safety']['collision_rate']['baseline'],
                    'collision_rate_distributed': metrics['safety']['collision_rate']['distributed'],
                    'collision_improvement': metrics['safety']['collision_rate']['improvement'],
                    'speed_baseline': metrics['efficiency']['avg_speed']['baseline'],
                    'speed_distributed': metrics['efficiency']['avg_speed']['distributed'],
                    'speed_improvement': metrics['efficiency']['avg_speed']['improvement'],
                    'delay_baseline': metrics['communication']['end_to_end_delay']['baseline'],
                    'delay_distributed': metrics['communication']['end_to_end_delay']['distributed'],
                    'delay_improvement': metrics['communication']['end_to_end_delay']['improvement'],
                    'consensus_baseline': metrics['consensus']['convergence_time']['baseline'],
                    'consensus_distributed': metrics['consensus']['convergence_time']['distributed'],
                    'consensus_improvement': metrics['consensus']['convergence_time']['improvement'],
                    'safety_violations': metrics['safety']['safety_violations']['count'],
                    'emergency_brakes': metrics['safety']['emergency_brakes']['count'],
                    'throughput_baseline': metrics['efficiency']['throughput']['baseline'],
                    'throughput_distributed': metrics['efficiency']['throughput']['distributed']
                }
                
                # 按时间段分类
                time_period = scenario_info['time_period']
                if time_period in self.time_period_data:
                    self.time_period_data[time_period].append(processed_scenario)
                
                # 按日期分类
                day_scenarios.append(processed_scenario)
                
                # 工作日vs周末分类
                if scenario_info['day_type'] == 'weekday':
                    self.weekday_data.append(processed_scenario)
                else:
                    self.weekend_data.append(processed_scenario)
            
            self.daily_data[day_name] = day_scenarios
    
    def analyze_time_periods(self) -> Dict[str, Any]:
        """分析不同时间段的对比数据"""
        print("\n🕐 分析时间段对比数据...")
        
        analysis_results = {}
        
        for period_name, scenarios in self.time_period_data.items():
            if not scenarios:
                continue
                
            # 计算该时间段的平均指标
            metrics = {
                'scenario_count': len(scenarios),
                'avg_vehicle_count': np.mean([s['vehicle_count'] for s in scenarios]),
                'collision_rate': {
                    'baseline_avg': np.mean([s['collision_rate_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['collision_rate_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([s['collision_improvement'] for s in scenarios]),
                    'improvement_std': np.std([s['collision_improvement'] for s in scenarios])
                },
                'speed': {
                    'baseline_avg': np.mean([s['speed_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['speed_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([s['speed_improvement'] for s in scenarios]),
                    'improvement_std': np.std([s['speed_improvement'] for s in scenarios])
                },
                'delay': {
                    'baseline_avg': np.mean([s['delay_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['delay_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([s['delay_improvement'] for s in scenarios]),
                    'improvement_std': np.std([s['delay_improvement'] for s in scenarios])
                },
                'consensus': {
                    'baseline_avg': np.mean([s['consensus_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['consensus_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([s['consensus_improvement'] for s in scenarios]),
                    'improvement_std': np.std([s['consensus_improvement'] for s in scenarios])
                },
                'throughput': {
                    'baseline_avg': np.mean([s['throughput_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['throughput_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([(s['throughput_distributed'] - s['throughput_baseline']) / s['throughput_baseline'] * 100 for s in scenarios])
                },
                'safety_events': {
                    'avg_violations': np.mean([s['safety_violations'] for s in scenarios]),
                    'avg_emergency_brakes': np.mean([s['emergency_brakes'] for s in scenarios])
                }
            }
            
            analysis_results[period_name] = metrics
        
        return analysis_results
    
    def analyze_weekly_patterns(self) -> Dict[str, Any]:
        """分析每日模式和工作日vs周末对比"""
        print("\n📅 分析每日模式和工作日vs周末对比...")
        
        # 每日分析
        daily_analysis = {}
        for day_name, scenarios in self.daily_data.items():
            if not scenarios:
                continue
                
            daily_metrics = {
                'scenario_count': len(scenarios),
                'total_vehicles': sum([s['vehicle_count'] for s in scenarios]),
                'avg_collision_improvement': np.mean([s['collision_improvement'] for s in scenarios]),
                'avg_speed_improvement': np.mean([s['speed_improvement'] for s in scenarios]),
                'avg_delay_improvement': np.mean([s['delay_improvement'] for s in scenarios]),
                'avg_consensus_improvement': np.mean([s['consensus_improvement'] for s in scenarios]),
                'total_safety_violations': sum([s['safety_violations'] for s in scenarios]),
                'total_emergency_brakes': sum([s['emergency_brakes'] for s in scenarios]),
                'avg_throughput_improvement': np.mean([(s['throughput_distributed'] - s['throughput_baseline']) / s['throughput_baseline'] * 100 for s in scenarios])
            }
            daily_analysis[day_name] = daily_metrics
        
        # 工作日vs周末对比
        weekday_vs_weekend = {
            'weekday': {
                'scenario_count': len(self.weekday_data),
                'avg_collision_improvement': np.mean([s['collision_improvement'] for s in self.weekday_data]),
                'avg_speed_improvement': np.mean([s['speed_improvement'] for s in self.weekday_data]),
                'avg_delay_improvement': np.mean([s['delay_improvement'] for s in self.weekday_data]),
                'avg_consensus_improvement': np.mean([s['consensus_improvement'] for s in self.weekday_data]),
                'avg_vehicle_density': np.mean([s['vehicle_count'] for s in self.weekday_data]),
                'total_safety_violations': sum([s['safety_violations'] for s in self.weekday_data]),
                'avg_throughput_baseline': np.mean([s['throughput_baseline'] for s in self.weekday_data]),
                'avg_throughput_distributed': np.mean([s['throughput_distributed'] for s in self.weekday_data])
            },
            'weekend': {
                'scenario_count': len(self.weekend_data),
                'avg_collision_improvement': np.mean([s['collision_improvement'] for s in self.weekend_data]),
                'avg_speed_improvement': np.mean([s['speed_improvement'] for s in self.weekend_data]),
                'avg_delay_improvement': np.mean([s['delay_improvement'] for s in self.weekend_data]),
                'avg_consensus_improvement': np.mean([s['consensus_improvement'] for s in self.weekend_data]),
                'avg_vehicle_density': np.mean([s['vehicle_count'] for s in self.weekend_data]),
                'total_safety_violations': sum([s['safety_violations'] for s in self.weekend_data]),
                'avg_throughput_baseline': np.mean([s['throughput_baseline'] for s in self.weekend_data]),
                'avg_throughput_distributed': np.mean([s['throughput_distributed'] for s in self.weekend_data])
            }
        }
        
        return {
            'daily_analysis': daily_analysis,
            'weekday_vs_weekend': weekday_vs_weekend
        }
    
    def analyze_monday_friday_comparison(self) -> Dict[str, Any]:
        """专门分析周一和周五的对比"""
        print("\n📊 分析周一vs周五专项对比...")
        
        monday_data = self.daily_data.get('Monday', [])
        friday_data = self.daily_data.get('Friday', [])
        
        def calculate_day_metrics(scenarios):
            if not scenarios:
                return None
            return {
                'morning_peak': next((s for s in scenarios if 'morning_peak' in s['name']), None),
                'evening_peak': next((s for s in scenarios if 'evening_peak' in s['name']), None),
                'normal_avg': np.mean([s['speed_improvement'] for s in scenarios if s['time_period'] == 'normal']),
                'valley': next((s for s in scenarios if 'valley' in s['name']), None),
                'daily_avg_speed_improvement': np.mean([s['speed_improvement'] for s in scenarios]),
                'daily_avg_collision_improvement': np.mean([s['collision_improvement'] for s in scenarios]),
                'daily_total_vehicles': sum([s['vehicle_count'] for s in scenarios]),
                'daily_safety_violations': sum([s['safety_violations'] for s in scenarios])
            }
        
        monday_metrics = calculate_day_metrics(monday_data)
        friday_metrics = calculate_day_metrics(friday_data)
        
        return {
            'Monday': monday_metrics,
            'Friday': friday_metrics,
            'comparison': {
                'speed_improvement_diff': friday_metrics['daily_avg_speed_improvement'] - monday_metrics['daily_avg_speed_improvement'] if monday_metrics and friday_metrics else 0,
                'safety_violations_diff': friday_metrics['daily_safety_violations'] - monday_metrics['daily_safety_violations'] if monday_metrics and friday_metrics else 0,
                'vehicle_load_diff': friday_metrics['daily_total_vehicles'] - monday_metrics['daily_total_vehicles'] if monday_metrics and friday_metrics else 0
            }
        }
    
    def analyze_weekend_patterns(self) -> Dict[str, Any]:
        """分析周六周日的模式"""
        print("\n🏖️ 分析周末模式（周六vs周日）...")
        
        saturday_data = self.daily_data.get('Saturday', [])
        sunday_data = self.daily_data.get('Sunday', [])
        
        def calculate_weekend_metrics(scenarios, day_name):
            if not scenarios:
                return None
            return {
                'day_name': day_name,
                'scenario_count': len(scenarios),
                'avg_vehicle_count': np.mean([s['vehicle_count'] for s in scenarios]),
                'avg_speed_improvement': np.mean([s['speed_improvement'] for s in scenarios]),
                'avg_delay_improvement': np.mean([s['delay_improvement'] for s in scenarios]),
                'total_throughput_baseline': sum([s['throughput_baseline'] for s in scenarios]),
                'total_throughput_distributed': sum([s['throughput_distributed'] for s in scenarios]),
                'safety_profile': {
                    'total_violations': sum([s['safety_violations'] for s in scenarios]),
                    'total_emergency_brakes': sum([s['emergency_brakes'] for s in scenarios]),
                    'avg_collision_improvement': np.mean([s['collision_improvement'] for s in scenarios])
                }
            }
        
        saturday_metrics = calculate_weekend_metrics(saturday_data, 'Saturday')
        sunday_metrics = calculate_weekend_metrics(sunday_data, 'Sunday')
        
        return {
            'Saturday': saturday_metrics,
            'Sunday': sunday_metrics,
            'weekend_comparison': {
                'traffic_volume_diff': saturday_metrics['avg_vehicle_count'] - sunday_metrics['avg_vehicle_count'] if saturday_metrics and sunday_metrics else 0,
                'performance_consistency': abs(saturday_metrics['avg_speed_improvement'] - sunday_metrics['avg_speed_improvement']) if saturday_metrics and sunday_metrics else 0,
                'safety_trend': saturday_metrics['safety_profile']['total_violations'] - sunday_metrics['safety_profile']['total_violations'] if saturday_metrics and sunday_metrics else 0
            }
        }
    
    def generate_comprehensive_report(self) -> str:
        """生成完整的七天分析报告"""
        print("\n📝 生成完整分析报告...")
        
        # 执行所有分析
        time_analysis = self.analyze_time_periods()
        weekly_analysis = self.analyze_weekly_patterns()
        monday_friday = self.analyze_monday_friday_comparison()
        weekend_analysis = self.analyze_weekend_patterns()
        
        # 生成报告
        report = f"""
🚗 CDTVDLF框架 - 七天完整仿真数据分析报告
================================================================

📊 实验总览:
- 实验期间: 完整7天周期
- 总场景数: {self.raw_data['meta_info']['total_scenarios']}
- 数据收集时间: {self.raw_data['meta_info']['start_time']} - {self.raw_data['meta_info']['end_time']}

🕐 时间段对比分析
================================================================

1️⃣ 早高峰时段 (Morning Peak):
   - 场景数量: {time_analysis.get('morning_peak', {}).get('scenario_count', 0)}
   - 平均车辆数: {time_analysis.get('morning_peak', {}).get('avg_vehicle_count', 0):.1f}
   - 碰撞率改善: {time_analysis.get('morning_peak', {}).get('collision_rate', {}).get('improvement_avg', 0):.1f}%
   - 速度提升: {time_analysis.get('morning_peak', {}).get('speed', {}).get('improvement_avg', 0):.1f}%
   - 延迟降低: {time_analysis.get('morning_peak', {}).get('delay', {}).get('improvement_avg', 0):.1f}%
   - 吞吐量提升: {time_analysis.get('morning_peak', {}).get('throughput', {}).get('improvement_avg', 0):.1f}%

2️⃣ 晚高峰时段 (Evening Peak):
   - 场景数量: {time_analysis.get('evening_peak', {}).get('scenario_count', 0)}
   - 平均车辆数: {time_analysis.get('evening_peak', {}).get('avg_vehicle_count', 0):.1f}
   - 碰撞率改善: {time_analysis.get('evening_peak', {}).get('collision_rate', {}).get('improvement_avg', 0):.1f}%
   - 速度提升: {time_analysis.get('evening_peak', {}).get('speed', {}).get('improvement_avg', 0):.1f}%
   - 延迟降低: {time_analysis.get('evening_peak', {}).get('delay', {}).get('improvement_avg', 0):.1f}%
   - 吞吐量提升: {time_analysis.get('evening_peak', {}).get('throughput', {}).get('improvement_avg', 0):.1f}%

3️⃣ 平峰时段 (Normal):
   - 场景数量: {time_analysis.get('normal', {}).get('scenario_count', 0)}
   - 平均车辆数: {time_analysis.get('normal', {}).get('avg_vehicle_count', 0):.1f}
   - 碰撞率改善: {time_analysis.get('normal', {}).get('collision_rate', {}).get('improvement_avg', 0):.1f}%
   - 速度提升: {time_analysis.get('normal', {}).get('speed', {}).get('improvement_avg', 0):.1f}%
   - 延迟降低: {time_analysis.get('normal', {}).get('delay', {}).get('improvement_avg', 0):.1f}%
   - 吞吐量提升: {time_analysis.get('normal', {}).get('throughput', {}).get('improvement_avg', 0):.1f}%

4️⃣ 波谷时段 (Valley):
   - 场景数量: {time_analysis.get('valley', {}).get('scenario_count', 0)}
   - 平均车辆数: {time_analysis.get('valley', {}).get('avg_vehicle_count', 0):.1f}
   - 碰撞率改善: {time_analysis.get('valley', {}).get('collision_rate', {}).get('improvement_avg', 0):.1f}%
   - 速度提升: {time_analysis.get('valley', {}).get('speed', {}).get('improvement_avg', 0):.1f}%
   - 延迟降低: {time_analysis.get('valley', {}).get('delay', {}).get('improvement_avg', 0):.1f}%
   - 吞吐量提升: {time_analysis.get('valley', {}).get('throughput', {}).get('improvement_avg', 0):.1f}%

📅 工作日 vs 周末对比分析
================================================================

🏢 工作日表现 (周一-周五):
   - 总场景数: {weekly_analysis['weekday_vs_weekend']['weekday']['scenario_count']}
   - 平均车辆密度: {weekly_analysis['weekday_vs_weekend']['weekday']['avg_vehicle_density']:.1f}
   - 碰撞率改善: {weekly_analysis['weekday_vs_weekend']['weekday']['avg_collision_improvement']:.1f}%
   - 速度提升: {weekly_analysis['weekday_vs_weekend']['weekday']['avg_speed_improvement']:.1f}%
   - 延迟降低: {weekly_analysis['weekday_vs_weekend']['weekday']['avg_delay_improvement']:.1f}%
   - 安全违规事件: {weekly_analysis['weekday_vs_weekend']['weekday']['total_safety_violations']}
   - 平均吞吐量提升: {((weekly_analysis['weekday_vs_weekend']['weekday']['avg_throughput_distributed'] - weekly_analysis['weekday_vs_weekend']['weekday']['avg_throughput_baseline']) / weekly_analysis['weekday_vs_weekend']['weekday']['avg_throughput_baseline'] * 100):.1f}%

🏖️ 周末表现 (周六-周日):
   - 总场景数: {weekly_analysis['weekday_vs_weekend']['weekend']['scenario_count']}
   - 平均车辆密度: {weekly_analysis['weekday_vs_weekend']['weekend']['avg_vehicle_density']:.1f}
   - 碰撞率改善: {weekly_analysis['weekday_vs_weekend']['weekend']['avg_collision_improvement']:.1f}%
   - 速度提升: {weekly_analysis['weekday_vs_weekend']['weekend']['avg_speed_improvement']:.1f}%
   - 延迟降低: {weekly_analysis['weekday_vs_weekend']['weekend']['avg_delay_improvement']:.1f}%
   - 安全违规事件: {weekly_analysis['weekday_vs_weekend']['weekend']['total_safety_violations']}
   - 平均吞吐量提升: {((weekly_analysis['weekday_vs_weekend']['weekend']['avg_throughput_distributed'] - weekly_analysis['weekday_vs_weekend']['weekend']['avg_throughput_baseline']) / weekly_analysis['weekday_vs_weekend']['weekend']['avg_throughput_baseline'] * 100):.1f}%

📊 周一 vs 周五 专项对比
================================================================

🌅 周一表现:
   - 速度改善: {monday_friday['Monday']['daily_avg_speed_improvement']:.1f}%
   - 碰撞改善: {monday_friday['Monday']['daily_avg_collision_improvement']:.1f}%
   - 总车辆数: {monday_friday['Monday']['daily_total_vehicles']}
   - 安全违规: {monday_friday['Monday']['daily_safety_violations']}

🌇 周五表现:
   - 速度改善: {monday_friday['Friday']['daily_avg_speed_improvement']:.1f}%
   - 碰撞改善: {monday_friday['Friday']['daily_avg_collision_improvement']:.1f}%
   - 总车辆数: {monday_friday['Friday']['daily_total_vehicles']}
   - 安全违规: {monday_friday['Friday']['daily_safety_violations']}

📈 周一vs周五差异:
   - 速度改善差异: {monday_friday['comparison']['speed_improvement_diff']:.2f}%
   - 车辆负载差异: {monday_friday['comparison']['vehicle_load_diff']} 辆
   - 安全事件差异: {monday_friday['comparison']['safety_violations_diff']} 起

🏖️ 周六 vs 周日 周末对比
================================================================

📅 周六表现:
   - 场景数: {weekend_analysis['Saturday']['scenario_count']}
   - 平均车辆: {weekend_analysis['Saturday']['avg_vehicle_count']:.1f}
   - 速度提升: {weekend_analysis['Saturday']['avg_speed_improvement']:.1f}%
   - 延迟降低: {weekend_analysis['Saturday']['avg_delay_improvement']:.1f}%
   - 安全违规: {weekend_analysis['Saturday']['safety_profile']['total_violations']}

📅 周日表现:
   - 场景数: {weekend_analysis['Sunday']['scenario_count']}
   - 平均车辆: {weekend_analysis['Sunday']['avg_vehicle_count']:.1f}
   - 速度提升: {weekend_analysis['Sunday']['avg_speed_improvement']:.1f}%
   - 延迟降低: {weekend_analysis['Sunday']['avg_delay_improvement']:.1f}%
   - 安全违规: {weekend_analysis['Sunday']['safety_profile']['total_violations']}
        """
        
        return report
    
    def save_analysis_results(self, filename: str = None) -> str:
        """保存详细分析结果到JSON文件"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"seven_day_detailed_analysis_{timestamp}.json"
        
        analysis_results = {
            'meta_info': {
                'analysis_time': datetime.now().isoformat(),
                'source_file': 'comprehensive_experiment_results_20250627_221253.json',
                'total_scenarios_analyzed': self.raw_data['meta_info']['total_scenarios']
            },
            'time_period_analysis': self.analyze_time_periods(),
            'weekly_patterns': self.analyze_weekly_patterns(),
            'monday_friday_comparison': self.analyze_monday_friday_comparison(),
            'weekend_analysis': self.analyze_weekend_patterns(),
            'detailed_daily_breakdown': {}
        }
        
        # 添加每日详细分解
        for day_name, scenarios in self.daily_data.items():
            analysis_results['detailed_daily_breakdown'][day_name] = {
                'total_scenarios': len(scenarios),
                'scenarios_detail': scenarios
            }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(analysis_results, f, indent=2, ensure_ascii=False, default=str)
        
        print(f"📁 详细分析结果已保存至: {filename}")
        return filename

def main():
    """主函数"""
    # 使用之前生成的API结果文件
    results_file = "comprehensive_experiment_results_20250627_221253.json"
    
    print("🚀 开始七天数据深度分析...")
    analyzer = SevenDayDataAnalyzer(results_file)
    
    # 生成完整报告
    report = analyzer.generate_comprehensive_report()
    print(report)
    
    # 保存详细分析结果
    analysis_file = analyzer.save_analysis_results()
    
    # 保存报告到文件
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = f"seven_day_analysis_report_{timestamp}.txt"
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"📄 分析报告已保存至: {report_file}")
    
    return analyzer, report, analysis_file

if __name__ == "__main__":
    analyzer, report, analysis_file = main() 
Seven-Day Comprehensive Data Analyzer
七天完整数据分析器

从API实验结果中提取和分析：
1. 平峰、高峰、波谷时间对比
2. 周一-周五工作日对比  
3. 周六-周日周末对比
4. 完整七天趋势分析
"""

import json
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
from typing import Dict, List, Any, Tuple
import pandas as pd

class SevenDayDataAnalyzer:
    """七天数据分析器"""
    
    def __init__(self, results_file: str):
        """初始化分析器并加载数据"""
        print("📊 初始化七天数据分析器...")
        
        with open(results_file, 'r', encoding='utf-8') as f:
            self.raw_data = json.load(f)
        
        # 数据分类存储
        self.time_period_data = {
            'morning_peak': [],
            'evening_peak': [], 
            'normal': [],
            'valley': []
        }
        
        self.daily_data = {
            'Monday': [], 'Tuesday': [], 'Wednesday': [], 'Thursday': [], 'Friday': [],
            'Saturday': [], 'Sunday': []
        }
        
        self.weekday_data = []  # 周一到周五
        self.weekend_data = []  # 周六周日
        
        # 处理和分类数据
        self._process_raw_data()
        print("✅ 数据加载和分类完成！")
    
    def _process_raw_data(self):
        """处理原始数据并分类"""
        print("🔄 处理和分类原始数据...")
        
        for day_name, day_data in self.raw_data['daily_results'].items():
            day_scenarios = []
            
            for scenario in day_data['scenarios']:
                scenario_info = scenario['scenario_info']
                metrics = scenario['performance_metrics']
                
                # 提取关键指标
                processed_scenario = {
                    'name': scenario_info['name'],
                    'time_period': scenario_info['time_period'],
                    'day_type': scenario_info['day_type'],
                    'vehicle_count': scenario_info['vehicle_count'],
                    'collision_rate_baseline': metrics['safety']['collision_rate']['baseline'],
                    'collision_rate_distributed': metrics['safety']['collision_rate']['distributed'],
                    'collision_improvement': metrics['safety']['collision_rate']['improvement'],
                    'speed_baseline': metrics['efficiency']['avg_speed']['baseline'],
                    'speed_distributed': metrics['efficiency']['avg_speed']['distributed'],
                    'speed_improvement': metrics['efficiency']['avg_speed']['improvement'],
                    'delay_baseline': metrics['communication']['end_to_end_delay']['baseline'],
                    'delay_distributed': metrics['communication']['end_to_end_delay']['distributed'],
                    'delay_improvement': metrics['communication']['end_to_end_delay']['improvement'],
                    'consensus_baseline': metrics['consensus']['convergence_time']['baseline'],
                    'consensus_distributed': metrics['consensus']['convergence_time']['distributed'],
                    'consensus_improvement': metrics['consensus']['convergence_time']['improvement'],
                    'safety_violations': metrics['safety']['safety_violations']['count'],
                    'emergency_brakes': metrics['safety']['emergency_brakes']['count'],
                    'throughput_baseline': metrics['efficiency']['throughput']['baseline'],
                    'throughput_distributed': metrics['efficiency']['throughput']['distributed']
                }
                
                # 按时间段分类
                time_period = scenario_info['time_period']
                if time_period in self.time_period_data:
                    self.time_period_data[time_period].append(processed_scenario)
                
                # 按日期分类
                day_scenarios.append(processed_scenario)
                
                # 工作日vs周末分类
                if scenario_info['day_type'] == 'weekday':
                    self.weekday_data.append(processed_scenario)
                else:
                    self.weekend_data.append(processed_scenario)
            
            self.daily_data[day_name] = day_scenarios
    
    def analyze_time_periods(self) -> Dict[str, Any]:
        """分析不同时间段的对比数据"""
        print("\n🕐 分析时间段对比数据...")
        
        analysis_results = {}
        
        for period_name, scenarios in self.time_period_data.items():
            if not scenarios:
                continue
                
            # 计算该时间段的平均指标
            metrics = {
                'scenario_count': len(scenarios),
                'avg_vehicle_count': np.mean([s['vehicle_count'] for s in scenarios]),
                'collision_rate': {
                    'baseline_avg': np.mean([s['collision_rate_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['collision_rate_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([s['collision_improvement'] for s in scenarios]),
                    'improvement_std': np.std([s['collision_improvement'] for s in scenarios])
                },
                'speed': {
                    'baseline_avg': np.mean([s['speed_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['speed_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([s['speed_improvement'] for s in scenarios]),
                    'improvement_std': np.std([s['speed_improvement'] for s in scenarios])
                },
                'delay': {
                    'baseline_avg': np.mean([s['delay_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['delay_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([s['delay_improvement'] for s in scenarios]),
                    'improvement_std': np.std([s['delay_improvement'] for s in scenarios])
                },
                'consensus': {
                    'baseline_avg': np.mean([s['consensus_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['consensus_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([s['consensus_improvement'] for s in scenarios]),
                    'improvement_std': np.std([s['consensus_improvement'] for s in scenarios])
                },
                'throughput': {
                    'baseline_avg': np.mean([s['throughput_baseline'] for s in scenarios]),
                    'distributed_avg': np.mean([s['throughput_distributed'] for s in scenarios]),
                    'improvement_avg': np.mean([(s['throughput_distributed'] - s['throughput_baseline']) / s['throughput_baseline'] * 100 for s in scenarios])
                },
                'safety_events': {
                    'avg_violations': np.mean([s['safety_violations'] for s in scenarios]),
                    'avg_emergency_brakes': np.mean([s['emergency_brakes'] for s in scenarios])
                }
            }
            
            analysis_results[period_name] = metrics
        
        return analysis_results
    
    def analyze_weekly_patterns(self) -> Dict[str, Any]:
        """分析每日模式和工作日vs周末对比"""
        print("\n📅 分析每日模式和工作日vs周末对比...")
        
        # 每日分析
        daily_analysis = {}
        for day_name, scenarios in self.daily_data.items():
            if not scenarios:
                continue
                
            daily_metrics = {
                'scenario_count': len(scenarios),
                'total_vehicles': sum([s['vehicle_count'] for s in scenarios]),
                'avg_collision_improvement': np.mean([s['collision_improvement'] for s in scenarios]),
                'avg_speed_improvement': np.mean([s['speed_improvement'] for s in scenarios]),
                'avg_delay_improvement': np.mean([s['delay_improvement'] for s in scenarios]),
                'avg_consensus_improvement': np.mean([s['consensus_improvement'] for s in scenarios]),
                'total_safety_violations': sum([s['safety_violations'] for s in scenarios]),
                'total_emergency_brakes': sum([s['emergency_brakes'] for s in scenarios]),
                'avg_throughput_improvement': np.mean([(s['throughput_distributed'] - s['throughput_baseline']) / s['throughput_baseline'] * 100 for s in scenarios])
            }
            daily_analysis[day_name] = daily_metrics
        
        # 工作日vs周末对比
        weekday_vs_weekend = {
            'weekday': {
                'scenario_count': len(self.weekday_data),
                'avg_collision_improvement': np.mean([s['collision_improvement'] for s in self.weekday_data]),
                'avg_speed_improvement': np.mean([s['speed_improvement'] for s in self.weekday_data]),
                'avg_delay_improvement': np.mean([s['delay_improvement'] for s in self.weekday_data]),
                'avg_consensus_improvement': np.mean([s['consensus_improvement'] for s in self.weekday_data]),
                'avg_vehicle_density': np.mean([s['vehicle_count'] for s in self.weekday_data]),
                'total_safety_violations': sum([s['safety_violations'] for s in self.weekday_data]),
                'avg_throughput_baseline': np.mean([s['throughput_baseline'] for s in self.weekday_data]),
                'avg_throughput_distributed': np.mean([s['throughput_distributed'] for s in self.weekday_data])
            },
            'weekend': {
                'scenario_count': len(self.weekend_data),
                'avg_collision_improvement': np.mean([s['collision_improvement'] for s in self.weekend_data]),
                'avg_speed_improvement': np.mean([s['speed_improvement'] for s in self.weekend_data]),
                'avg_delay_improvement': np.mean([s['delay_improvement'] for s in self.weekend_data]),
                'avg_consensus_improvement': np.mean([s['consensus_improvement'] for s in self.weekend_data]),
                'avg_vehicle_density': np.mean([s['vehicle_count'] for s in self.weekend_data]),
                'total_safety_violations': sum([s['safety_violations'] for s in self.weekend_data]),
                'avg_throughput_baseline': np.mean([s['throughput_baseline'] for s in self.weekend_data]),
                'avg_throughput_distributed': np.mean([s['throughput_distributed'] for s in self.weekend_data])
            }
        }
        
        return {
            'daily_analysis': daily_analysis,
            'weekday_vs_weekend': weekday_vs_weekend
        }
    
    def analyze_monday_friday_comparison(self) -> Dict[str, Any]:
        """专门分析周一和周五的对比"""
        print("\n📊 分析周一vs周五专项对比...")
        
        monday_data = self.daily_data.get('Monday', [])
        friday_data = self.daily_data.get('Friday', [])
        
        def calculate_day_metrics(scenarios):
            if not scenarios:
                return None
            return {
                'morning_peak': next((s for s in scenarios if 'morning_peak' in s['name']), None),
                'evening_peak': next((s for s in scenarios if 'evening_peak' in s['name']), None),
                'normal_avg': np.mean([s['speed_improvement'] for s in scenarios if s['time_period'] == 'normal']),
                'valley': next((s for s in scenarios if 'valley' in s['name']), None),
                'daily_avg_speed_improvement': np.mean([s['speed_improvement'] for s in scenarios]),
                'daily_avg_collision_improvement': np.mean([s['collision_improvement'] for s in scenarios]),
                'daily_total_vehicles': sum([s['vehicle_count'] for s in scenarios]),
                'daily_safety_violations': sum([s['safety_violations'] for s in scenarios])
            }
        
        monday_metrics = calculate_day_metrics(monday_data)
        friday_metrics = calculate_day_metrics(friday_data)
        
        return {
            'Monday': monday_metrics,
            'Friday': friday_metrics,
            'comparison': {
                'speed_improvement_diff': friday_metrics['daily_avg_speed_improvement'] - monday_metrics['daily_avg_speed_improvement'] if monday_metrics and friday_metrics else 0,
                'safety_violations_diff': friday_metrics['daily_safety_violations'] - monday_metrics['daily_safety_violations'] if monday_metrics and friday_metrics else 0,
                'vehicle_load_diff': friday_metrics['daily_total_vehicles'] - monday_metrics['daily_total_vehicles'] if monday_metrics and friday_metrics else 0
            }
        }
    
    def analyze_weekend_patterns(self) -> Dict[str, Any]:
        """分析周六周日的模式"""
        print("\n🏖️ 分析周末模式（周六vs周日）...")
        
        saturday_data = self.daily_data.get('Saturday', [])
        sunday_data = self.daily_data.get('Sunday', [])
        
        def calculate_weekend_metrics(scenarios, day_name):
            if not scenarios:
                return None
            return {
                'day_name': day_name,
                'scenario_count': len(scenarios),
                'avg_vehicle_count': np.mean([s['vehicle_count'] for s in scenarios]),
                'avg_speed_improvement': np.mean([s['speed_improvement'] for s in scenarios]),
                'avg_delay_improvement': np.mean([s['delay_improvement'] for s in scenarios]),
                'total_throughput_baseline': sum([s['throughput_baseline'] for s in scenarios]),
                'total_throughput_distributed': sum([s['throughput_distributed'] for s in scenarios]),
                'safety_profile': {
                    'total_violations': sum([s['safety_violations'] for s in scenarios]),
                    'total_emergency_brakes': sum([s['emergency_brakes'] for s in scenarios]),
                    'avg_collision_improvement': np.mean([s['collision_improvement'] for s in scenarios])
                }
            }
        
        saturday_metrics = calculate_weekend_metrics(saturday_data, 'Saturday')
        sunday_metrics = calculate_weekend_metrics(sunday_data, 'Sunday')
        
        return {
            'Saturday': saturday_metrics,
            'Sunday': sunday_metrics,
            'weekend_comparison': {
                'traffic_volume_diff': saturday_metrics['avg_vehicle_count'] - sunday_metrics['avg_vehicle_count'] if saturday_metrics and sunday_metrics else 0,
                'performance_consistency': abs(saturday_metrics['avg_speed_improvement'] - sunday_metrics['avg_speed_improvement']) if saturday_metrics and sunday_metrics else 0,
                'safety_trend': saturday_metrics['safety_profile']['total_violations'] - sunday_metrics['safety_profile']['total_violations'] if saturday_metrics and sunday_metrics else 0
            }
        }
    
    def generate_comprehensive_report(self) -> str:
        """生成完整的七天分析报告"""
        print("\n📝 生成完整分析报告...")
        
        # 执行所有分析
        time_analysis = self.analyze_time_periods()
        weekly_analysis = self.analyze_weekly_patterns()
        monday_friday = self.analyze_monday_friday_comparison()
        weekend_analysis = self.analyze_weekend_patterns()
        
        # 生成报告
        report = f"""
🚗 CDTVDLF框架 - 七天完整仿真数据分析报告
================================================================

📊 实验总览:
- 实验期间: 完整7天周期
- 总场景数: {self.raw_data['meta_info']['total_scenarios']}
- 数据收集时间: {self.raw_data['meta_info']['start_time']} - {self.raw_data['meta_info']['end_time']}

🕐 时间段对比分析
================================================================

1️⃣ 早高峰时段 (Morning Peak):
   - 场景数量: {time_analysis.get('morning_peak', {}).get('scenario_count', 0)}
   - 平均车辆数: {time_analysis.get('morning_peak', {}).get('avg_vehicle_count', 0):.1f}
   - 碰撞率改善: {time_analysis.get('morning_peak', {}).get('collision_rate', {}).get('improvement_avg', 0):.1f}%
   - 速度提升: {time_analysis.get('morning_peak', {}).get('speed', {}).get('improvement_avg', 0):.1f}%
   - 延迟降低: {time_analysis.get('morning_peak', {}).get('delay', {}).get('improvement_avg', 0):.1f}%
   - 吞吐量提升: {time_analysis.get('morning_peak', {}).get('throughput', {}).get('improvement_avg', 0):.1f}%

2️⃣ 晚高峰时段 (Evening Peak):
   - 场景数量: {time_analysis.get('evening_peak', {}).get('scenario_count', 0)}
   - 平均车辆数: {time_analysis.get('evening_peak', {}).get('avg_vehicle_count', 0):.1f}
   - 碰撞率改善: {time_analysis.get('evening_peak', {}).get('collision_rate', {}).get('improvement_avg', 0):.1f}%
   - 速度提升: {time_analysis.get('evening_peak', {}).get('speed', {}).get('improvement_avg', 0):.1f}%
   - 延迟降低: {time_analysis.get('evening_peak', {}).get('delay', {}).get('improvement_avg', 0):.1f}%
   - 吞吐量提升: {time_analysis.get('evening_peak', {}).get('throughput', {}).get('improvement_avg', 0):.1f}%

3️⃣ 平峰时段 (Normal):
   - 场景数量: {time_analysis.get('normal', {}).get('scenario_count', 0)}
   - 平均车辆数: {time_analysis.get('normal', {}).get('avg_vehicle_count', 0):.1f}
   - 碰撞率改善: {time_analysis.get('normal', {}).get('collision_rate', {}).get('improvement_avg', 0):.1f}%
   - 速度提升: {time_analysis.get('normal', {}).get('speed', {}).get('improvement_avg', 0):.1f}%
   - 延迟降低: {time_analysis.get('normal', {}).get('delay', {}).get('improvement_avg', 0):.1f}%
   - 吞吐量提升: {time_analysis.get('normal', {}).get('throughput', {}).get('improvement_avg', 0):.1f}%

4️⃣ 波谷时段 (Valley):
   - 场景数量: {time_analysis.get('valley', {}).get('scenario_count', 0)}
   - 平均车辆数: {time_analysis.get('valley', {}).get('avg_vehicle_count', 0):.1f}
   - 碰撞率改善: {time_analysis.get('valley', {}).get('collision_rate', {}).get('improvement_avg', 0):.1f}%
   - 速度提升: {time_analysis.get('valley', {}).get('speed', {}).get('improvement_avg', 0):.1f}%
   - 延迟降低: {time_analysis.get('valley', {}).get('delay', {}).get('improvement_avg', 0):.1f}%
   - 吞吐量提升: {time_analysis.get('valley', {}).get('throughput', {}).get('improvement_avg', 0):.1f}%

📅 工作日 vs 周末对比分析
================================================================

🏢 工作日表现 (周一-周五):
   - 总场景数: {weekly_analysis['weekday_vs_weekend']['weekday']['scenario_count']}
   - 平均车辆密度: {weekly_analysis['weekday_vs_weekend']['weekday']['avg_vehicle_density']:.1f}
   - 碰撞率改善: {weekly_analysis['weekday_vs_weekend']['weekday']['avg_collision_improvement']:.1f}%
   - 速度提升: {weekly_analysis['weekday_vs_weekend']['weekday']['avg_speed_improvement']:.1f}%
   - 延迟降低: {weekly_analysis['weekday_vs_weekend']['weekday']['avg_delay_improvement']:.1f}%
   - 安全违规事件: {weekly_analysis['weekday_vs_weekend']['weekday']['total_safety_violations']}
   - 平均吞吐量提升: {((weekly_analysis['weekday_vs_weekend']['weekday']['avg_throughput_distributed'] - weekly_analysis['weekday_vs_weekend']['weekday']['avg_throughput_baseline']) / weekly_analysis['weekday_vs_weekend']['weekday']['avg_throughput_baseline'] * 100):.1f}%

🏖️ 周末表现 (周六-周日):
   - 总场景数: {weekly_analysis['weekday_vs_weekend']['weekend']['scenario_count']}
   - 平均车辆密度: {weekly_analysis['weekday_vs_weekend']['weekend']['avg_vehicle_density']:.1f}
   - 碰撞率改善: {weekly_analysis['weekday_vs_weekend']['weekend']['avg_collision_improvement']:.1f}%
   - 速度提升: {weekly_analysis['weekday_vs_weekend']['weekend']['avg_speed_improvement']:.1f}%
   - 延迟降低: {weekly_analysis['weekday_vs_weekend']['weekend']['avg_delay_improvement']:.1f}%
   - 安全违规事件: {weekly_analysis['weekday_vs_weekend']['weekend']['total_safety_violations']}
   - 平均吞吐量提升: {((weekly_analysis['weekday_vs_weekend']['weekend']['avg_throughput_distributed'] - weekly_analysis['weekday_vs_weekend']['weekend']['avg_throughput_baseline']) / weekly_analysis['weekday_vs_weekend']['weekend']['avg_throughput_baseline'] * 100):.1f}%

📊 周一 vs 周五 专项对比
================================================================

🌅 周一表现:
   - 速度改善: {monday_friday['Monday']['daily_avg_speed_improvement']:.1f}%
   - 碰撞改善: {monday_friday['Monday']['daily_avg_collision_improvement']:.1f}%
   - 总车辆数: {monday_friday['Monday']['daily_total_vehicles']}
   - 安全违规: {monday_friday['Monday']['daily_safety_violations']}

🌇 周五表现:
   - 速度改善: {monday_friday['Friday']['daily_avg_speed_improvement']:.1f}%
   - 碰撞改善: {monday_friday['Friday']['daily_avg_collision_improvement']:.1f}%
   - 总车辆数: {monday_friday['Friday']['daily_total_vehicles']}
   - 安全违规: {monday_friday['Friday']['daily_safety_violations']}

📈 周一vs周五差异:
   - 速度改善差异: {monday_friday['comparison']['speed_improvement_diff']:.2f}%
   - 车辆负载差异: {monday_friday['comparison']['vehicle_load_diff']} 辆
   - 安全事件差异: {monday_friday['comparison']['safety_violations_diff']} 起

🏖️ 周六 vs 周日 周末对比
================================================================

📅 周六表现:
   - 场景数: {weekend_analysis['Saturday']['scenario_count']}
   - 平均车辆: {weekend_analysis['Saturday']['avg_vehicle_count']:.1f}
   - 速度提升: {weekend_analysis['Saturday']['avg_speed_improvement']:.1f}%
   - 延迟降低: {weekend_analysis['Saturday']['avg_delay_improvement']:.1f}%
   - 安全违规: {weekend_analysis['Saturday']['safety_profile']['total_violations']}

📅 周日表现:
   - 场景数: {weekend_analysis['Sunday']['scenario_count']}
   - 平均车辆: {weekend_analysis['Sunday']['avg_vehicle_count']:.1f}
   - 速度提升: {weekend_analysis['Sunday']['avg_speed_improvement']:.1f}%
   - 延迟降低: {weekend_analysis['Sunday']['avg_delay_improvement']:.1f}%
   - 安全违规: {weekend_analysis['Sunday']['safety_profile']['total_violations']}
        """
        
        return report
    
    def save_analysis_results(self, filename: str = None) -> str:
        """保存详细分析结果到JSON文件"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"seven_day_detailed_analysis_{timestamp}.json"
        
        analysis_results = {
            'meta_info': {
                'analysis_time': datetime.now().isoformat(),
                'source_file': 'comprehensive_experiment_results_20250627_221253.json',
                'total_scenarios_analyzed': self.raw_data['meta_info']['total_scenarios']
            },
            'time_period_analysis': self.analyze_time_periods(),
            'weekly_patterns': self.analyze_weekly_patterns(),
            'monday_friday_comparison': self.analyze_monday_friday_comparison(),
            'weekend_analysis': self.analyze_weekend_patterns(),
            'detailed_daily_breakdown': {}
        }
        
        # 添加每日详细分解
        for day_name, scenarios in self.daily_data.items():
            analysis_results['detailed_daily_breakdown'][day_name] = {
                'total_scenarios': len(scenarios),
                'scenarios_detail': scenarios
            }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(analysis_results, f, indent=2, ensure_ascii=False, default=str)
        
        print(f"📁 详细分析结果已保存至: {filename}")
        return filename

def main():
    """主函数"""
    # 使用之前生成的API结果文件
    results_file = "comprehensive_experiment_results_20250627_221253.json"
    
    print("🚀 开始七天数据深度分析...")
    analyzer = SevenDayDataAnalyzer(results_file)
    
    # 生成完整报告
    report = analyzer.generate_comprehensive_report()
    print(report)
    
    # 保存详细分析结果
    analysis_file = analyzer.save_analysis_results()
    
    # 保存报告到文件
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = f"seven_day_analysis_report_{timestamp}.txt"
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"📄 分析报告已保存至: {report_file}")
    
    return analyzer, report, analysis_file

if __name__ == "__main__":
    analyzer, report, analysis_file = main() 