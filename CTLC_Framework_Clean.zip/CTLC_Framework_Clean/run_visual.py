#!/usr/bin/env python3
"""
CTLC Framework Enhanced Visual Simulation
Optimized for macOS display with forced window focus
"""

import pygame
import sys
import os
import traceback
import time

from src.utils.config import Config
from src.simulation.simulation_manager import SimulationManager

def main():
    """
    Enhanced main entry point with better macOS compatibility
    """
    # Force display environment for macOS
    os.environ['SDL_VIDEO_WINDOW_POS'] = '100,100'
    
    pygame.init()
    
    # Create display with explicit flags for macOS
    screen = pygame.display.set_mode(
        (Config.WIDTH, Config.HEIGHT), 
        pygame.SHOWN | pygame.DOUBLEBUF
    )
    
    pygame.display.set_caption("🚗 CTLC Framework: 6G-Aware Vehicular Coordination")
    
    # Force window to front on macOS
    pygame.display.flip()
    
    sim_manager = None
    clock = pygame.time.Clock()
    
    try:
        print("🚀 Initializing CTLC Framework Simulation...")
        sim_manager = SimulationManager(screen)
        print("✅ SimulationManager initialized successfully")
        print("📱 Window should now be visible!")
        print("🎮 Controls: SPACE=Add Vehicle, R=Reset, ESC=Exit")
        print("="*60)
        
        running = True
        step_count = 0
        
        while running:
            # Handle events
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    print("🛑 Quit requested via window close")
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        print("🛑 Quit requested via ESC key")
                        running = False
                    elif event.key == pygame.K_r:
                        print("🔄 Reset requested")
                        # Could implement reset logic here
                    elif event.key == pygame.K_SPACE:
                        print("🚗 Add vehicle requested")
                        # Vehicle addition handled in simulation
            
            # Handle continuous keyboard input
            keys = pygame.key.get_pressed()
            sim_manager.handle_keyboard_input(keys)
            
            # Run simulation step
            sim_manager.step()
            
            # Update display
            pygame.display.flip()
            
            # Control frame rate (60 FPS)
            clock.tick(60)
            
            step_count += 1
            
            # Print status every 300 steps (5 seconds at 60 FPS)
            if step_count % 300 == 0:
                print(f"📊 Simulation running... Step {step_count}")

    except KeyboardInterrupt:
        print("\n🛑 Simulation interrupted by user (Ctrl+C)")
        
    except Exception as e:
        print("\n" + "="*60)
        print("❌ SIMULATION ERROR OCCURRED")
        print("="*60)
        print(f"🔍 Error Type: {type(e).__name__}")
        print(f"📝 Error Details: {e}")
        print("-"*60)
        print("📋 Full Traceback:")
        traceback.print_exc()
        print("="*60)
        print("💡 Try: python3 no_training_demo.py for a simpler version")
        
    finally:
        print("\n🏁 Cleaning up and exiting...")
        pygame.quit()
        print("✅ Cleanup completed")

if __name__ == "__main__":
    main() 