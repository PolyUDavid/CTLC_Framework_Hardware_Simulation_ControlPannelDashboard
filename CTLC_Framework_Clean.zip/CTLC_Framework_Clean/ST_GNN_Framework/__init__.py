"""
ST-GNN Framework: Spatio-Temporal Graph Neural Network for 6G-IoT Systems

This framework provides a modular, API-driven implementation of ST-GNN models
specifically designed for vehicular networks and IoT applications.

Key Features:
- Hardware-agnostic API interface
- Real-time graph processing
- 6G network-aware adaptations
- Third-party system integration support
"""

__version__ = "1.0.0"
__author__ = "CTLC Research Team"

from .api.stgnn_api import STGNN_API
from .models.stgnn_core import STGNNCore
from .utils.graph_utils import GraphProcessor

__all__ = [
    'STGNN_API',
    'STGNNCore', 
    'GraphProcessor'
] 