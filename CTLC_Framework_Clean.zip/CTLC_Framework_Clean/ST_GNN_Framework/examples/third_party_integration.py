"""
Third-Party Integration Example for ST-GNN Framework

This example demonstrates how external hardware/software systems
can integrate with the ST-GNN framework for real-time processing.
"""

import numpy as np
import time
from dataclasses import dataclass
from typing import List, Dict, Any

# Import the ST-GNN framework
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api.stgnn_api import STGNN_API, NetworkNode, NetworkEdge

class SimulatedHardwareDevice:
    """
    Simulates a third-party hardware device (e.g., vehicle ECU, edge server).
    """
    
    def __init__(self, device_id: str, device_type: str):
        self.device_id = device_id
        self.device_type = device_type
        self.position = np.random.uniform(0, 1000, 2)
        self.velocity = np.random.uniform(-10, 10, 2)
        
    def get_sensor_data(self) -> Dict[str, Any]:
        """Simulate sensor readings from hardware."""
        return {
            'acceleration': np.random.uniform(-2, 2),
            'steering_angle': np.random.uniform(-30, 30),
            'speed': np.linalg.norm(self.velocity),
            'battery_level': np.random.uniform(0.2, 1.0),
            'timestamp': time.time()
        }
    
    def update_position(self, dt: float = 0.1):
        """Update device position (for mobile devices)."""
        self.position += self.velocity * dt
        # Add some noise to velocity
        self.velocity += np.random.normal(0, 0.1, 2)
        self.velocity = np.clip(self.velocity, -15, 15)

def main():
    """
    Main example showing third-party integration workflow.
    """
    print("🚀 ST-GNN Framework Third-Party Integration Example")
    print("=" * 60)
    
    # Initialize ST-GNN API
    config = {
        'feature_size': 8,
        'hidden_size': 64,
        'output_size': 32,
        'device': 'cpu'
    }
    
    stgnn_api = STGNN_API(config)
    print("✅ ST-GNN API initialized")
    
    # Create simulated hardware devices
    devices = [
        SimulatedHardwareDevice("vehicle_001", "vehicle"),
        SimulatedHardwareDevice("vehicle_002", "vehicle"), 
        SimulatedHardwareDevice("rsu_001", "rsu"),
        SimulatedHardwareDevice("sensor_001", "sensor")
    ]
    
    print(f"📱 Created {len(devices)} simulated hardware devices")
    
    # Register devices with ST-GNN framework
    for device in devices:
        node = NetworkNode(
            id=device.device_id,
            position=tuple(device.position),
            velocity=tuple(device.velocity),
            features=device.get_sensor_data(),
            timestamp=time.time(),
            device_type=device.device_type
        )
        
        success = stgnn_api.register_device(node)
        if success:
            print(f"✅ Registered {device.device_id} ({device.device_type})")
        else:
            print(f"❌ Failed to register {device.device_id}")
    
    print("\n🔄 Starting real-time processing simulation...")
    
    # Simulate real-time processing loop
    for step in range(50):
        print(f"\n--- Processing Step {step + 1} ---")
        
        # Update device positions and get current data
        nodes = []
        for device in devices:
            if device.device_type == "vehicle":  # Only vehicles move
                device.update_position()
            
            node = NetworkNode(
                id=device.device_id,
                position=tuple(device.position),
                velocity=tuple(device.velocity),
                features=device.get_sensor_data(),
                timestamp=time.time(),
                device_type=device.device_type
            )
            nodes.append(node)
        
        # Simulate communication links between devices
        edges = []
        for i, node_i in enumerate(nodes):
            for j, node_j in enumerate(nodes):
                if i != j:
                    # Calculate distance
                    dist = np.linalg.norm(np.array(node_i.position) - np.array(node_j.position))
                    
                    # Create edge if within communication range
                    if dist < 200:  # 200m communication range
                        edge = NetworkEdge(
                            source_id=node_i.id,
                            target_id=node_j.id,
                            weight=1.0 / (dist + 1),  # Distance-based weight
                            connection_type="v2v" if "vehicle" in node_i.id and "vehicle" in node_j.id else "v2i",
                            quality_metrics={
                                'latency': 1.0 + dist * 0.01,  # Distance affects latency
                                'bandwidth': max(10, 1000 - dist * 2),  # Distance affects bandwidth
                                'reliability': max(0.5, 1.0 - dist * 0.001)
                            }
                        )
                        edges.append(edge)
        
        # Update network topology
        stgnn_api.update_network_topology(edges)
        
        # Process real-time data with ST-GNN
        results = stgnn_api.process_realtime_data(nodes, edges)
        
        if 'error' not in results:
            print(f"✅ Processed {results['num_nodes']} nodes, {results['num_edges']} edges")
            print(f"⏱️  Processing time: {results['processing_time_ms']:.2f}ms")
            
            # Example: Use embeddings for decision making
            embeddings = results['embeddings']
            if embeddings is not None:
                print(f"🧠 Generated embeddings shape: {embeddings.shape}")
                
                # Simulate using embeddings for application-specific logic
                for i, node_id in enumerate(results['node_ids']):
                    embedding = embeddings[i]
                    # Example application logic
                    risk_score = float(torch.norm(embedding).item())
                    print(f"   {node_id}: Risk Score = {risk_score:.3f}")
        else:
            print(f"❌ Processing error: {results['error']}")
        
        # Get processing statistics
        if step % 10 == 9:  # Every 10 steps
            stats = stgnn_api.get_processing_stats()
            print(f"\n📊 Processing Statistics:")
            print(f"   Total inferences: {stats['total_inferences']}")
            print(f"   Average latency: {stats['avg_latency_ms']:.2f}ms")
        
        # Simulate real-time delay
        time.sleep(0.1)
    
    print("\n🎯 Demonstrating model export for hardware deployment...")
    
    # Export model for hardware deployment
    export_path = "stgnn_model_for_hardware.onnx"
    success = stgnn_api.export_model_for_hardware(export_path, format='onnx')
    
    if success:
        print(f"✅ Model exported to {export_path}")
        print("   This model can now be deployed on edge devices, FPGAs, etc.")
    else:
        print("❌ Model export failed")
    
    # Final statistics
    final_stats = stgnn_api.get_processing_stats()
    print(f"\n📈 Final Performance Report:")
    print(f"   Total processing rounds: {final_stats['total_inferences']}")
    print(f"   Average processing time: {final_stats['avg_latency_ms']:.2f}ms")
    print(f"   Framework efficiency: {'✅ Excellent' if final_stats['avg_latency_ms'] < 50 else '⚠️ Needs optimization'}")
    
    print("\n🏁 Third-party integration example completed successfully!")
    print("   Your hardware can now integrate with ST-GNN framework using similar patterns.")

if __name__ == "__main__":
    # Add error handling for demo
    try:
        main()
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Please ensure the ST-GNN framework is properly installed.")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("Please check your configuration and try again.") 