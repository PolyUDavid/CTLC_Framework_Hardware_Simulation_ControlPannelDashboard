"""
ST-GNN API Interface for Third-Party Integration

This API provides a standardized interface for external systems (hardware/software)
to integrate with the ST-GNN framework for real-time graph processing.
"""

import torch
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
import json
import time
from dataclasses import dataclass

from ..models.stgnn_core import STGNNCore
from ..utils.graph_utils import GraphProcessor

@dataclass
class NetworkNode:
    """Standardized node representation for third-party systems"""
    id: str
    position: Tuple[float, float]
    velocity: Tuple[float, float]
    features: Dict[str, Any]
    timestamp: float
    device_type: str  # 'vehicle', 'rsu', 'sensor', 'custom'

@dataclass
class NetworkEdge:
    """Standardized edge representation for communication links"""
    source_id: str
    target_id: str
    weight: float
    connection_type: str  # 'v2v', 'v2i', 'i2i', 'custom'
    quality_metrics: Dict[str, float]  # latency, bandwidth, reliability

class STGNN_API:
    """
    Main API interface for ST-GNN framework integration.
    
    This class provides methods for:
    - Real-time graph processing
    - Hardware device integration
    - 6G network adaptation
    - Distributed inference
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize ST-GNN API.
        
        Args:
            config: Configuration dictionary for ST-GNN parameters
        """
        self.config = self._load_default_config()
        if config:
            self.config.update(config)
            
        # Initialize core components
        self.stgnn_core = STGNNCore(
            feature_size=self.config['feature_size'],
            hidden_size=self.config['hidden_size'], 
            output_size=self.config['output_size']
        )
        
        self.graph_processor = GraphProcessor()
        self.device = torch.device(self.config.get('device', 'cpu'))
        self.stgnn_core.to(self.device)
        
        # State management
        self.hidden_state = None
        self.node_registry = {}  # Track registered nodes
        self.edge_registry = {}  # Track active connections
        self.processing_stats = {
            'total_inferences': 0,
            'avg_latency_ms': 0.0,
            'last_update': time.time()
        }
        
    def register_device(self, node: NetworkNode) -> bool:
        """
        Register a new device/node in the network.
        
        Args:
            node: NetworkNode object with device information
            
        Returns:
            bool: True if registration successful
        """
        try:
            self.node_registry[node.id] = {
                'node_info': node,
                'last_seen': time.time(),
                'status': 'active'
            }
            print(f"[ST-GNN API] Device {node.id} ({node.device_type}) registered successfully")
            return True
        except Exception as e:
            print(f"[ST-GNN API] Device registration failed: {e}")
            return False
    
    def unregister_device(self, node_id: str) -> bool:
        """Remove a device from the network."""
        if node_id in self.node_registry:
            del self.node_registry[node_id]
            print(f"[ST-GNN API] Device {node_id} unregistered")
            return True
        return False
    
    def update_network_topology(self, edges: List[NetworkEdge]) -> bool:
        """
        Update network communication topology.
        
        Args:
            edges: List of NetworkEdge objects representing connections
            
        Returns:
            bool: True if update successful
        """
        try:
            self.edge_registry.clear()
            for edge in edges:
                edge_key = f"{edge.source_id}-{edge.target_id}"
                self.edge_registry[edge_key] = edge
            
            print(f"[ST-GNN API] Network topology updated with {len(edges)} connections")
            return True
        except Exception as e:
            print(f"[ST-GNN API] Topology update failed: {e}")
            return False
    
    def process_realtime_data(self, nodes: List[NetworkNode], 
                            edges: List[NetworkEdge]) -> Dict[str, torch.Tensor]:
        """
        Main API method for real-time ST-GNN processing.
        
        Args:
            nodes: Current network nodes with latest sensor data
            edges: Current network connections
            
        Returns:
            Dict containing node embeddings and processing metadata
        """
        start_time = time.time()
        
        try:
            # Convert to graph data format
            graph_data = self.graph_processor.build_graph_from_api_data(nodes, edges)
            
            if graph_data is None:
                return {'embeddings': None, 'error': 'Invalid graph data'}
            
            # Initialize hidden state if needed
            if self.hidden_state is None or self.hidden_state.shape[1] != len(nodes):
                self.hidden_state = self.stgnn_core.init_hidden(len(nodes))
            
            # ST-GNN inference
            with torch.no_grad():
                embeddings, self.hidden_state = self.stgnn_core(graph_data, self.hidden_state)
            
            # Update statistics
            processing_time = (time.time() - start_time) * 1000  # ms
            self._update_stats(processing_time)
            
            # Prepare results
            results = {
                'embeddings': embeddings,
                'node_ids': [node.id for node in nodes],
                'processing_time_ms': processing_time,
                'timestamp': time.time(),
                'num_nodes': len(nodes),
                'num_edges': len(edges)
            }
            
            return results
            
        except Exception as e:
            print(f"[ST-GNN API] Processing error: {e}")
            return {'embeddings': None, 'error': str(e)}
    
    def get_node_embedding(self, node_id: str) -> Optional[torch.Tensor]:
        """Get the latest embedding for a specific node."""
        # This would require storing embeddings with node mappings
        # Implementation depends on specific use case
        pass
    
    def export_model_for_hardware(self, output_path: str, 
                                 format: str = 'onnx') -> bool:
        """
        Export ST-GNN model for hardware deployment.
        
        Args:
            output_path: Path to save exported model
            format: Export format ('onnx', 'tensorrt', 'tflite')
            
        Returns:
            bool: True if export successful
        """
        try:
            if format.lower() == 'onnx':
                # Create dummy input for tracing
                dummy_graph = self.graph_processor.create_dummy_graph(
                    num_nodes=4, feature_size=self.config['feature_size']
                )
                dummy_hidden = self.stgnn_core.init_hidden(4)
                
                torch.onnx.export(
                    self.stgnn_core,
                    (dummy_graph, dummy_hidden),
                    output_path,
                    export_params=True,
                    opset_version=11,
                    do_constant_folding=True,
                    input_names=['graph_data', 'hidden_state'],
                    output_names=['embeddings', 'new_hidden_state']
                )
                print(f"[ST-GNN API] Model exported to {output_path}")
                return True
            else:
                print(f"[ST-GNN API] Export format {format} not yet supported")
                return False
                
        except Exception as e:
            print(f"[ST-GNN API] Model export failed: {e}")
            return False
    
    def get_processing_stats(self) -> Dict[str, Any]:
        """Get current processing performance statistics."""
        return self.processing_stats.copy()
    
    def reset_hidden_state(self):
        """Reset the ST-GNN hidden state (useful for new episodes)."""
        self.hidden_state = None
        print("[ST-GNN API] Hidden state reset")
    
    def _load_default_config(self) -> Dict[str, Any]:
        """Load default configuration for ST-GNN."""
        return {
            'feature_size': 8,
            'hidden_size': 64,
            'output_size': 32,
            'device': 'cpu',
            'max_nodes': 100,
            'processing_timeout': 50  # ms
        }
    
    def _update_stats(self, processing_time: float):
        """Update processing statistics."""
        self.processing_stats['total_inferences'] += 1
        # Running average of latency
        alpha = 0.1  # smoothing factor
        self.processing_stats['avg_latency_ms'] = (
            alpha * processing_time + 
            (1 - alpha) * self.processing_stats['avg_latency_ms']
        )
        self.processing_stats['last_update'] = time.time() 