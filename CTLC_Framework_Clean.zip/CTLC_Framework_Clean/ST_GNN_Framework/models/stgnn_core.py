"""
ST-GNN Core Model Implementation

Enhanced version of the original ST-GNN with additional features for
hardware deployment and third-party integration.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from typing import Tuple, Optional

class STGNNCore(nn.Module):
    """
    Enhanced ST-GNN core model with deployment-ready features.
    
    Features:
    - Optimized for ONNX export
    - Hardware-friendly operations
    - Configurable architecture
    - Built-in performance monitoring
    """
    
    def __init__(self, feature_size: int, hidden_size: int, output_size: int):
        super(STGNNCore, self).__init__()
        
        self.feature_size = feature_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        # Spatial feature extraction using Graph Convolutional Networks
        self.gcn1 = GCNConv(feature_size, hidden_size)
        self.gcn2 = GCNConv(hidden_size, hidden_size)
        
        # Temporal feature extraction using GRU
        self.gru = nn.GRU(hidden_size, output_size, batch_first=False)
        
        # Additional layers for enhanced performance
        self.dropout = nn.Dropout(0.1)
        self.layer_norm = nn.LayerNorm(hidden_size)
        
        # Performance tracking
        self.inference_count = 0
        
    def forward(self, data, h_prev: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Enhanced forward pass with performance optimizations.
        
        Args:
            data: Graph data with x (node features) and edge_index
            h_prev: Previous hidden state
            
        Returns:
            Tuple of (node_embeddings, new_hidden_state)
        """
        x, edge_index = data.x, data.edge_index
        
        # Spatial processing with residual connections
        spatial_features = F.relu(self.gcn1(x, edge_index))
        spatial_features = self.dropout(spatial_features)
        spatial_features = self.layer_norm(spatial_features)
        
        spatial_features = self.gcn2(spatial_features, edge_index)
        
        # Prepare for temporal processing
        gru_input = spatial_features.unsqueeze(0)  # Add time dimension
        
        # Initialize hidden state if not provided
        if h_prev is None:
            h_prev = self.init_hidden(spatial_features.shape[0])
            
        # Temporal processing
        gnn_output, h_t = self.gru(gru_input, h_prev)
        gnn_output = gnn_output.squeeze(0)
        
        self.inference_count += 1
        
        return gnn_output, h_t
    
    def init_hidden(self, num_nodes: int) -> torch.Tensor:
        """Initialize hidden state for GRU."""
        return torch.zeros(1, num_nodes, self.output_size, device=next(self.parameters()).device)
    
    def get_model_info(self) -> dict:
        """Get model architecture information."""
        return {
            'feature_size': self.feature_size,
            'hidden_size': self.hidden_size,
            'output_size': self.output_size,
            'total_parameters': sum(p.numel() for p in self.parameters()),
            'trainable_parameters': sum(p.numel() for p in self.parameters() if p.requires_grad),
            'inference_count': self.inference_count
        }
    
    def reset_stats(self):
        """Reset performance statistics."""
        self.inference_count = 0 