"""
ST-GNN Framework Models

Neural network models for spatio-temporal graph processing.
"""

from .stgnn_core import STGNNCore

__all__ = [
    'STGNNCore'
] 