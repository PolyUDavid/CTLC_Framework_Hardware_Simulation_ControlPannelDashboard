"""
Graph Processing Utilities for ST-GNN Framework

Provides tools for converting various data formats to PyTorch Geometric
graph representations suitable for ST-GNN processing.
"""

import torch
import numpy as np
from torch_geometric.data import Data
from typing import List, Dict, Tuple, Optional, Any
import networkx as nx

class GraphProcessor:
    """
    Utility class for graph data processing and conversion.
    """
    
    def __init__(self):
        self.node_feature_extractors = {
            'vehicle': self._extract_vehicle_features,
            'rsu': self._extract_rsu_features,
            'sensor': self._extract_sensor_features,
            'custom': self._extract_custom_features
        }
    
    def build_graph_from_api_data(self, nodes: List, edges: List) -> Optional[Data]:
        """
        Convert API node/edge data to PyTorch Geometric Data object.
        
        Args:
            nodes: List of NetworkNode objects
            edges: List of NetworkEdge objects
            
        Returns:
            PyTorch Geometric Data object or None if conversion fails
        """
        try:
            if not nodes:
                return None
                
            # Extract node features
            node_features = []
            node_id_map = {}
            
            for i, node in enumerate(nodes):
                node_id_map[node.id] = i
                features = self._extract_node_features(node)
                node_features.append(features)
            
            # Convert to tensor
            x = torch.FloatTensor(np.array(node_features))
            
            # Build edge index and attributes
            edge_indices = []
            edge_attrs = []
            
            for edge in edges:
                if edge.source_id in node_id_map and edge.target_id in node_id_map:
                    source_idx = node_id_map[edge.source_id]
                    target_idx = node_id_map[edge.target_id]
                    
                    # Add bidirectional edges
                    edge_indices.extend([[source_idx, target_idx], [target_idx, source_idx]])
                    
                    # Extract edge attributes
                    edge_attr = self._extract_edge_features(edge)
                    edge_attrs.extend([edge_attr, edge_attr])
            
            # Convert to tensors
            if edge_indices:
                edge_index = torch.LongTensor(edge_indices).t().contiguous()
                edge_attr = torch.FloatTensor(edge_attrs) if edge_attrs else None
            else:
                # No edges - create empty tensors
                edge_index = torch.zeros((2, 0), dtype=torch.long)
                edge_attr = None
            
            # Create graph data object
            data = Data(
                x=x,
                edge_index=edge_index,
                edge_attr=edge_attr,
                num_nodes=len(nodes)
            )
            
            return data
            
        except Exception as e:
            print(f"[GraphProcessor] Error building graph: {e}")
            return None
    
    def build_graph_from_simulation_state(self, entities: List) -> Optional[Data]:
        """
        Convert simulation entities to graph representation.
        Legacy compatibility method for existing simulation.
        """
        try:
            vehicles = [e for e in entities if hasattr(e, 'velocity')]
            
            if not vehicles:
                return None
            
            # Extract features for each vehicle
            node_features = []
            for vehicle in vehicles:
                features = np.concatenate([
                    vehicle.position,
                    vehicle.velocity,
                    [vehicle.acceleration, vehicle.steering_angle],
                    [len(vehicle.v2v_neighbors), len(vehicle.connected_rsus)]
                ])
                # Pad to consistent size
                if len(features) < 8:
                    features = np.pad(features, (0, 8 - len(features)))
                node_features.append(features[:8])
            
            x = torch.FloatTensor(node_features)
            
            # Build connectivity based on communication ranges
            edge_indices = []
            for i, vehicle_i in enumerate(vehicles):
                for j, vehicle_j in enumerate(vehicles):
                    if i != j:
                        dist = np.linalg.norm(vehicle_i.position - vehicle_j.position)
                        if dist < 150:  # Communication range
                            edge_indices.append([i, j])
            
            if edge_indices:
                edge_index = torch.LongTensor(edge_indices).t().contiguous()
            else:
                edge_index = torch.zeros((2, 0), dtype=torch.long)
            
            return Data(x=x, edge_index=edge_index, num_nodes=len(vehicles))
            
        except Exception as e:
            print(f"[GraphProcessor] Error in simulation conversion: {e}")
            return None
    
    def create_dummy_graph(self, num_nodes: int, feature_size: int) -> Data:
        """Create dummy graph for model export/testing."""
        x = torch.randn(num_nodes, feature_size)
        edge_index = torch.randint(0, num_nodes, (2, num_nodes * 2))
        return Data(x=x, edge_index=edge_index, num_nodes=num_nodes)
    
    def _extract_node_features(self, node) -> np.ndarray:
        """Extract features from a NetworkNode object."""
        device_type = getattr(node, 'device_type', 'custom')
        
        if device_type in self.node_feature_extractors:
            return self.node_feature_extractors[device_type](node)
        else:
            return self._extract_custom_features(node)
    
    def _extract_vehicle_features(self, node) -> np.ndarray:
        """Extract features specific to vehicle nodes."""
        features = []
        
        # Position and velocity
        features.extend(node.position)
        features.extend(node.velocity)
        
        # Additional vehicle-specific features from node.features dict
        vehicle_features = node.features
        features.append(vehicle_features.get('acceleration', 0.0))
        features.append(vehicle_features.get('steering_angle', 0.0))
        features.append(vehicle_features.get('speed', np.linalg.norm(node.velocity)))
        features.append(vehicle_features.get('battery_level', 1.0))
        
        return np.array(features, dtype=np.float32)
    
    def _extract_rsu_features(self, node) -> np.ndarray:
        """Extract features specific to RSU nodes."""
        features = []
        
        # Position (RSUs are stationary)
        features.extend(node.position)
        features.extend([0.0, 0.0])  # Zero velocity
        
        # RSU-specific features
        rsu_features = node.features
        features.append(rsu_features.get('coverage_radius', 100.0))
        features.append(rsu_features.get('processing_load', 0.0))
        features.append(rsu_features.get('connected_vehicles', 0))
        features.append(rsu_features.get('signal_strength', 1.0))
        
        return np.array(features, dtype=np.float32)
    
    def _extract_sensor_features(self, node) -> np.ndarray:
        """Extract features for sensor nodes."""
        features = []
        
        features.extend(node.position)
        features.extend([0.0, 0.0])  # Sensors are typically stationary
        
        sensor_features = node.features
        features.append(sensor_features.get('sensor_type_id', 0))
        features.append(sensor_features.get('detection_range', 50.0))
        features.append(sensor_features.get('accuracy', 0.95))
        features.append(sensor_features.get('battery_level', 1.0))
        
        return np.array(features, dtype=np.float32)
    
    def _extract_custom_features(self, node) -> np.ndarray:
        """Default feature extraction for custom node types."""
        features = []
        
        # Basic spatial features
        features.extend(node.position)
        features.extend(getattr(node, 'velocity', [0.0, 0.0]))
        
        # Extract numeric features from the features dict
        for key, value in node.features.items():
            if isinstance(value, (int, float)):
                features.append(float(value))
            if len(features) >= 8:  # Limit feature size
                break
                
        # Pad to minimum size
        while len(features) < 8:
            features.append(0.0)
            
        return np.array(features[:8], dtype=np.float32)
    
    def _extract_edge_features(self, edge) -> List[float]:
        """Extract features from a NetworkEdge object."""
        features = [
            edge.weight,
            edge.quality_metrics.get('latency', 10.0),
            edge.quality_metrics.get('bandwidth', 100.0),
            edge.quality_metrics.get('reliability', 0.9)
        ]
        return features 