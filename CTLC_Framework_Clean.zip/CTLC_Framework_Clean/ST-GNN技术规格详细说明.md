# ST-GNN技术规格详细说明
## Spatio-Temporal Graph Neural Network Input/Output Matrix Specifications

---

## 1. 总体架构概述

### 1.1 ST-GNN Backbone结构
```
多模态传感器输入 → 异构节点编码器 → 多尺度图卷积 → 时空注意力 → 分布式决策输出
```

### 1.2 数据流向
```
Raw Sensor Data → Feature Encoding → Graph Construction → ST-GNN Processing → Action Planning
```

---

## 2. 输入矩阵详细规格

### 2.1 节点特征矩阵 (Node Feature Matrix)

#### **基础节点特征矩阵 X ∈ ℝ^(N×F)**
- **维度**: N个节点 × F个特征维度
- **N**: 动态节点数量 (车辆数量，通常10个车辆)
- **F**: 节点特征维度 = 64 (Config.GNN_FEATURE_SIZE)

#### **特征向量组成** (F=64维)
```python
feature_vector = [
    # 1. 车辆动力学状态 (9维)
    norm_speed,                    # [0]: 归一化速度 ∈ [0,1]
    norm_angle,                    # [1]: 归一化转向角 ∈ [-0.5,0.5]
    velocity_x,                    # [2]: X方向速度 ∈ [-1,1]
    velocity_y,                    # [3]: Y方向速度 ∈ [-1,1]
    position_x,                    # [4]: 归一化X位置 ∈ [0,1]
    position_y,                    # [5]: 归一化Y位置 ∈ [0,1]
    acceleration,                  # [6]: 当前加速度 ∈ [-1,1]
    steering_angle,                # [7]: 方向盘角度 ∈ [-1,1]
    emergency_brake_status,        # [8]: 紧急制动状态 ∈ {0,1}
    
    # 2. LiDAR传感器特征 (16维)
    lidar_front_distance,          # [9]: 前方最近障碍物距离
    lidar_left_distance,           # [10]: 左侧最近障碍物距离
    lidar_right_distance,          # [11]: 右侧最近障碍物距离
    lidar_rear_distance,           # [12]: 后方最近障碍物距离
    lidar_point_density,           # [13]: 点云密度特征
    lidar_object_count,            # [14]: 检测到的对象数量
    lidar_confidence_avg,          # [15]: 平均检测置信度
    lidar_scan_quality,            # [16]: 扫描质量评分
    lidar_angular_resolution,      # [17]: 角度分辨率
    lidar_range_accuracy,          # [18]: 距离精度
    lidar_noise_level,             # [19]: 噪声水平
    lidar_weather_impact,          # [20]: 天气影响因子
    lidar_dynamic_objects,         # [21]: 动态对象数量
    lidar_static_objects,          # [22]: 静态对象数量
    lidar_occlusion_ratio,         # [23]: 遮挡比例
    lidar_elevation_variance,      # [24]: 高程变化
    
    # 3. Computer Vision特征 (16维)
    camera_pothole_detected,       # [25]: 坑洞检测标志 ∈ {0,1}
    camera_vehicle_count,          # [26]: 视野内车辆数量
    camera_lane_detection,         # [27]: 车道线检测置信度
    camera_traffic_sign,           # [28]: 交通标志识别
    camera_visibility,             # [29]: 可见度评分
    camera_brightness,             # [30]: 亮度水平
    camera_contrast,               # [31]: 对比度
    camera_blur_level,             # [32]: 模糊程度
    camera_weather_condition,      # [33]: 天气条件编码
    camera_object_tracking,        # [34]: 对象跟踪质量
    camera_depth_estimation,       # [35]: 深度估计精度
    camera_motion_blur,            # [36]: 运动模糊检测
    camera_lens_distortion,        # [37]: 镜头畸变补偿
    camera_exposure_level,         # [38]: 曝光水平
    camera_color_temperature,      # [39]: 色温
    camera_image_noise,            # [40]: 图像噪声
    
    # 4. V2V通信特征 (12维)
    v2v_neighbor_count,            # [41]: V2V邻居数量
    v2v_signal_strength,           # [42]: 平均信号强度
    v2v_packet_loss_rate,          # [43]: 丢包率
    v2v_latency_avg,               # [44]: 平均延迟
    v2v_bandwidth_utilization,     # [45]: 带宽利用率
    v2v_interference_level,        # [46]: 干扰水平
    v2v_handover_frequency,        # [47]: 切换频率
    v2v_consensus_agreement,       # [48]: 共识一致性
    v2v_data_freshness,            # [49]: 数据新鲜度
    v2v_trust_score,               # [50]: 邻居信任评分
    v2v_byzantine_suspicion,       # [51]: 拜占庭怀疑度
    v2v_cooperation_level,         # [52]: 合作程度
    
    # 5. V2I通信特征 (8维)
    v2i_rsu_connected,             # [53]: RSU连接状态 ∈ {0,1}
    v2i_signal_quality,            # [54]: V2I信号质量
    v2i_data_rate,                 # [55]: 数据传输速率
    v2i_infrastructure_load,       # [56]: 基础设施负载
    v2i_service_availability,      # [57]: 服务可用性
    v2i_edge_compute_latency,      # [58]: 边缘计算延迟
    v2i_traffic_info_quality,      # [59]: 交通信息质量
    v2i_security_level,            # [60]: 安全等级
    
    # 6. 预留扩展特征 (4维)
    reserved_feature_1,            # [61]: 预留特征1
    reserved_feature_2,            # [62]: 预留特征2
    reserved_feature_3,            # [63]: 预留特征3
    reserved_feature_4             # [64]: 预留特征4
]
```

### 2.2 边特征矩阵 (Edge Feature Matrix)

#### **边索引矩阵 edge_index ∈ ℤ^(2×E)**
- **维度**: 2 × E (E为边数量)
- **格式**: [[source_nodes], [target_nodes]]
- **连接条件**: 欧几里得距离 < COMM_RANGE (400像素)

#### **边属性矩阵 edge_attr ∈ ℝ^(E×D_edge)**
- **D_edge**: 边特征维度 = 8
```python
edge_features = [
    euclidean_distance,            # [0]: 欧几里得距离 (归一化)
    relative_velocity,             # [1]: 相对速度
    signal_strength,               # [2]: 通信信号强度
    packet_loss_rate,              # [3]: 数据包丢失率
    communication_latency,         # [4]: 通信延迟
    bandwidth_capacity,            # [5]: 带宽容量
    interference_level,            # [6]: 干扰水平
    link_reliability              # [7]: 链路可靠性
]
```

### 2.3 时序特征矩阵 (Temporal Feature Matrix)

#### **时序历史矩阵 H_t ∈ ℝ^(T×N×F_temp)**
- **T**: 时序长度 = 10 (历史步数)
- **N**: 节点数量
- **F_temp**: 时序特征维度 = 32

### 2.4 网络条件矩阵 (Network Condition Matrix)

#### **6G网络状态向量 C_net ∈ ℝ^32**
```python
network_condition = [
    # uRLLC特征 (8维)
    urllc_latency,                 # [0]: uRLLC延迟 (1-5ms)
    urllc_reliability,             # [1]: uRLLC可靠性 (99.999%)
    urllc_jitter,                  # [2]: 抖动水平
    urllc_error_rate,              # [3]: 错误率
    urllc_availability,            # [4]: 服务可用性
    urllc_priority_level,          # [5]: 优先级等级
    urllc_slice_isolation,         # [6]: 切片隔离度
    urllc_deterministic_delay,     # [7]: 确定性延迟
    
    # eMBB特征 (8维)
    embb_throughput,               # [8]: eMBB吞吐量 (Gbps)
    embb_bandwidth,                # [9]: 可用带宽
    embb_spectrum_efficiency,      # [10]: 频谱效率
    embb_user_density,             # [11]: 用户密度
    embb_load_balancing,           # [12]: 负载均衡
    embb_carrier_aggregation,      # [13]: 载波聚合
    embb_mimo_efficiency,          # [14]: MIMO效率
    embb_beamforming_gain,         # [15]: 波束成形增益
    
    # 网络切片特征 (8维)
    slice_allocation_ratio,        # [16]: 切片分配比例
    slice_switching_time,          # [17]: 切片切换时间
    slice_resource_utilization,    # [18]: 资源利用率
    slice_qos_satisfaction,        # [19]: QoS满足度
    slice_orchestration_delay,     # [20]: 编排延迟
    slice_tenant_isolation,        # [21]: 租户隔离
    slice_elasticity,              # [22]: 弹性伸缩
    slice_sla_compliance,          # [23]: SLA合规性
    
    # 边缘计算特征 (8维)
    mec_compute_capacity,          # [24]: 边缘计算容量
    mec_storage_availability,      # [25]: 存储可用性
    mec_processing_latency,        # [26]: 处理延迟
    mec_cache_hit_ratio,           # [27]: 缓存命中率
    mec_task_offloading,           # [28]: 任务卸载比例
    mec_energy_efficiency,         # [29]: 能效比
    mec_fault_tolerance,           # [30]: 容错能力
    mec_service_migration          # [31]: 服务迁移能力
]
```

---

## 3. 输出矩阵详细规格

### 3.1 主要输出矩阵

#### **节点嵌入矩阵 Z ∈ ℝ^(N×D_out)**
- **维度**: N个节点 × D_out输出维度
- **D_out**: 输出特征维度 = 64 (Config.STGNN_OUTPUT_DIM)

#### **输出特征组成** (D_out=64维)
```python
output_embedding = [
    # 1. 运动规划特征 (16维)
    desired_acceleration,          # [0]: 期望加速度
    desired_steering,              # [1]: 期望转向角
    trajectory_confidence,         # [2]: 轨迹置信度
    path_smoothness,               # [3]: 路径平滑度
    velocity_profile,              # [4]: 速度剖面
    lateral_offset,                # [5]: 横向偏移
    longitudinal_gap,              # [6]: 纵向间距
    lane_change_intention,         # [7]: 换道意图
    emergency_stop_probability,    # [8]: 紧急停车概率
    comfort_level,                 # [9]: 舒适度评分
    fuel_efficiency,               # [10]: 燃油效率
    route_optimization,            # [11]: 路径优化度
    traffic_flow_contribution,     # [12]: 交通流贡献
    cooperative_behavior,          # [13]: 合作行为强度
    risk_assessment,               # [14]: 风险评估
    maneuver_feasibility,          # [15]: 机动可行性
    
    # 2. 安全控制特征 (16维)
    collision_risk,                # [16]: 碰撞风险评估
    safety_margin,                 # [17]: 安全裕度
    brake_urgency,                 # [18]: 制动紧急程度
    avoidance_direction,           # [19]: 避障方向
    threat_level,                  # [20]: 威胁等级
    safety_constraint_violation,   # [21]: 安全约束违反度
    cbf_barrier_value,             # [22]: CBF屏障函数值
    time_to_collision,             # [23]: 碰撞时间
    minimum_safe_distance,         # [24]: 最小安全距离
    visibility_conditions,         # [25]: 可见性条件
    road_surface_conditions,       # [26]: 路面条件
    weather_impact_factor,         # [27]: 天气影响因子
    vehicle_health_status,         # [28]: 车辆健康状态
    sensor_reliability,            # [29]: 传感器可靠性
    actuator_response_time,        # [30]: 执行器响应时间
    safety_system_status,          # [31]: 安全系统状态
    
    # 3. 通信协调特征 (16维)
    consensus_weight,              # [32]: 共识权重
    neighbor_trust_level,          # [33]: 邻居信任水平
    information_value,             # [34]: 信息价值
    communication_priority,        # [35]: 通信优先级
    data_sharing_willingness,      # [36]: 数据共享意愿
    coordination_efficiency,       # [37]: 协调效率
    distributed_agreement,         # [38]: 分布式一致性
    byzantine_resilience,          # [39]: 拜占庭韧性
    network_topology_awareness,    # [40]: 网络拓扑感知
    qos_requirements,              # [41]: QoS需求
    bandwidth_allocation,          # [42]: 带宽分配
    latency_tolerance,             # [43]: 延迟容忍度
    reliability_requirements,      # [44]: 可靠性需求
    security_level_needed,         # [45]: 所需安全等级
    privacy_preservation,          # [46]: 隐私保护程度
    interoperability_score,        # [47]: 互操作性评分
    
    # 4. 决策融合特征 (16维)
    action_confidence,             # [48]: 动作置信度
    multi_objective_balance,       # [49]: 多目标平衡
    uncertainty_quantification,    # [50]: 不确定性量化
    robustness_measure,            # [51]: 鲁棒性度量
    adaptability_score,            # [52]: 适应性评分
    learning_progress,             # [53]: 学习进度
    performance_prediction,        # [54]: 性能预测
    resource_utilization,          # [55]: 资源利用率
    system_efficiency,             # [56]: 系统效率
    scalability_factor,            # [57]: 可扩展性因子
    fault_tolerance_level,         # [58]: 容错水平
    real_time_capability,          # [59]: 实时能力
    energy_consumption,            # [60]: 能耗水平
    environmental_impact,          # [61]: 环境影响
    user_satisfaction,             # [62]: 用户满意度
    system_intelligence_level      # [63]: 系统智能水平
]
```

### 3.2 辅助输出矩阵

#### **注意力权重矩阵 A ∈ ℝ^(N×N×H)**
- **维度**: N×N×H (H为注意力头数=8)
- **用途**: 分析节点间注意力分布

#### **时序隐状态矩阵 H_out ∈ ℝ^(1×N×D_hidden)**
- **维度**: 1×N×D_hidden (D_hidden=128)
- **用途**: GRU时序记忆状态

---

## 4. 数学公式描述

### 4.1 ST-GNN前向传播

#### **空间图卷积**
```
H^(l+1) = σ(D^(-1/2)ÂD^(-1/2)H^(l)W^(l))
```
其中:
- Â = A + I (邻接矩阵加自环)
- D为度矩阵
- W^(l)为第l层权重矩阵

#### **多头注意力机制**
```
Attention(Q,K,V) = softmax(QK^T/√d_k)V

MultiHead(Q,K,V) = Concat(head_1,...,head_h)W^O
```

#### **时序GRU更新**
```
h_t = GRU(spatial_features_t, h_{t-1})
```

### 4.2 网络条件自适应权重
```
λ_uRLLC = min(1.0, L_target / L_current)
λ_eMBB = min(1.0, R_current / R_target)

# 归一化权重
λ_uRLLC = λ_uRLLC / (λ_uRLLC + λ_eMBB)
λ_eMBB = λ_eMBB / (λ_uRLLC + λ_eMBB)
```

---

## 5. 序列和结构设计

### 5.1 时序序列结构
```python
# 时序窗口结构
temporal_sequence = {
    'window_size': 10,              # 历史时间窗口
    'prediction_horizon': 5,        # 预测时间跨度
    'sampling_rate': 30,            # 采样率 (30 FPS)
    'temporal_resolution': 0.033,   # 时间分辨率 (秒)
    'memory_decay': 0.95,           # 记忆衰减因子
    'adaptive_window': True         # 自适应窗口大小
}
```

### 5.2 图结构动态性
```python
# 动态图结构
graph_dynamics = {
    'node_addition': True,          # 支持节点动态添加
    'node_removal': True,           # 支持节点动态移除
    'edge_rewiring': True,          # 支持边的重连
    'topology_adaptation': True,    # 拓扑自适应
    'structure_learning': True,     # 结构学习
    'heterogeneity_handling': True  # 异构性处理
}
```

### 5.3 变量维度映射表

| 符号 | 变量名 | 维度 | 描述 |
|------|--------|------|------|
| N | num_nodes | 动态(≤20) | 节点数量(车辆数) |
| F | feature_dim | 64 | 节点特征维度 |
| E | num_edges | 动态 | 边数量 |
| D_edge | edge_feature_dim | 8 | 边特征维度 |
| T | sequence_length | 10 | 时序长度 |
| H | num_heads | 8 | 注意力头数 |
| D_hidden | hidden_dim | 128 | 隐层维度 |
| D_out | output_dim | 64 | 输出维度 |
| B | batch_size | 1 | 批次大小 |
| C_net | network_condition_dim | 32 | 网络条件维度 |

---

## 6. 实现细节

### 6.1 数据预处理
```python
def preprocess_sensor_data(raw_data):
    """传感器数据预处理管道"""
    # 1. 数据归一化
    normalized_data = normalize_features(raw_data)
    
    # 2. 缺失值处理
    imputed_data = handle_missing_values(normalized_data)
    
    # 3. 异常值检测和处理
    cleaned_data = detect_and_handle_outliers(imputed_data)
    
    # 4. 特征工程
    engineered_features = feature_engineering(cleaned_data)
    
    return engineered_features
```

### 6.2 图构建算法
```python
def build_dynamic_graph(vehicles, rsus, timestamp):
    """动态图构建算法"""
    # 1. 节点特征提取
    node_features = extract_node_features(vehicles)
    
    # 2. 边连接确定
    edge_index, edge_attr = determine_connectivity(vehicles, rsus)
    
    # 3. 时序信息融合
    temporal_features = fuse_temporal_info(timestamp)
    
    # 4. 网络条件编码
    network_condition = encode_network_state()
    
    return create_graph_data(node_features, edge_index, edge_attr, 
                           temporal_features, network_condition)
```

这个技术规格文档为您的论文提供了ST-GNN模型的完整技术细节，包括精确的输入输出矩阵定义、维度规格和数学公式，可以直接用于学术写作。 