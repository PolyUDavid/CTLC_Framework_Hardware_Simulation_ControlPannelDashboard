"""
Consensus Manager for Byzantine Fault-Tolerant Model Aggregation

Implements various consensus algorithms for distributed learning
with Byzantine fault tolerance.
"""

import torch
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
import statistics
from collections import defaultdict

class ConsensusManager:
    """
    Manager for consensus-driven model parameter aggregation.
    
    Supports multiple consensus algorithms:
    - Trimmed Mean (Byzantine fault-tolerant)
    - Krum Algorithm  
    - Geometric Median
    - FedAvg (baseline)
    """
    
    def __init__(self, byzantine_tolerance: float = 0.3):
        """
        Initialize consensus manager.
        
        Args:
            byzantine_tolerance: Fraction of Byzantine agents to tolerate (0.0-0.5)
        """
        self.byzantine_tolerance = min(byzantine_tolerance, 0.5)
        self.consensus_history = []
        self.algorithm_stats = {
            'trimmed_mean': {'calls': 0, 'avg_time': 0.0},
            'krum': {'calls': 0, 'avg_time': 0.0}, 
            'fedavg': {'calls': 0, 'avg_time': 0.0}
        }
        
    def byzantine_consensus(self, agent_parameters: List[Dict[str, torch.Tensor]], 
                          algorithm: str = 'trimmed_mean') -> Dict[str, torch.Tensor]:
        """
        Perform Byzantine fault-tolerant consensus.
        
        Args:
            agent_parameters: List of parameter dictionaries from agents
            algorithm: Consensus algorithm ('trimmed_mean', 'krum', 'fedavg')
            
        Returns:
            Consensus parameters
        """
        if not agent_parameters:
            return {}
            
        start_time = torch.cuda.Event(enable_timing=True) if torch.cuda.is_available() else None
        if start_time:
            start_time.record()
            
        if algorithm == 'trimmed_mean':
            consensus_params = self._trimmed_mean_consensus(agent_parameters)
        elif algorithm == 'krum':
            consensus_params = self._krum_consensus(agent_parameters)
        elif algorithm == 'fedavg':
            consensus_params = self._federated_averaging(agent_parameters)
        else:
            raise ValueError(f"Unknown consensus algorithm: {algorithm}")
            
        if start_time:
            end_time = torch.cuda.Event(enable_timing=True)
            end_time.record()
            torch.cuda.synchronize()
            elapsed_time = start_time.elapsed_time(end_time) / 1000.0  # Convert to seconds
            self._update_algorithm_stats(algorithm, elapsed_time)
            
        # Store consensus history
        self.consensus_history.append({
            'algorithm': algorithm,
            'num_participants': len(agent_parameters),
            'consensus_quality': self._evaluate_consensus_quality(agent_parameters, consensus_params)
        })
        
        return consensus_params
    
    def _trimmed_mean_consensus(self, agent_parameters: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """
        Trimmed mean consensus - Byzantine fault-tolerant.
        
        Removes outlier parameter values before averaging to handle Byzantine agents.
        """
        if len(agent_parameters) < 3:
            return self._federated_averaging(agent_parameters)
            
        consensus_params = {}
        
        # Calculate trim amount based on Byzantine tolerance
        trim_ratio = self.byzantine_tolerance
        trim_count = int(len(agent_parameters) * trim_ratio)
        
        for param_name in agent_parameters[0].keys():
            # Stack parameters from all agents
            param_stack = torch.stack([params[param_name] for params in agent_parameters])
            
            # Flatten for easier processing
            original_shape = param_stack.shape[1:]
            param_stack_flat = param_stack.view(param_stack.shape[0], -1)
            
            # Apply trimmed mean along agent dimension
            trimmed_params = []
            for i in range(param_stack_flat.shape[1]):
                values = param_stack_flat[:, i].cpu().numpy()
                # Remove extreme values
                values_sorted = np.sort(values)
                trimmed_values = values_sorted[trim_count:len(values)-trim_count] if trim_count > 0 else values_sorted
                trimmed_mean = np.mean(trimmed_values) if len(trimmed_values) > 0 else np.mean(values)
                trimmed_params.append(trimmed_mean)
            
            # Reshape back and convert to tensor
            consensus_tensor = torch.FloatTensor(trimmed_params).view(original_shape)
            consensus_params[param_name] = consensus_tensor.to(param_stack.device)
            
        return consensus_params
    
    def _krum_consensus(self, agent_parameters: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """
        Krum consensus algorithm - selects most representative agent.
        
        Selects the agent whose parameters are closest to the majority.
        """
        if len(agent_parameters) <= 1:
            return agent_parameters[0] if agent_parameters else {}
            
        n = len(agent_parameters)
        f = int(n * self.byzantine_tolerance)  # Number of Byzantine agents
        m = n - f - 2  # Krum parameter
        
        if m <= 0:
            return self._federated_averaging(agent_parameters)
            
        # Calculate pairwise distances
        distances = []
        for i, params_i in enumerate(agent_parameters):
            agent_distances = []
            for j, params_j in enumerate(agent_parameters):
                if i != j:
                    dist = self._calculate_parameter_distance(params_i, params_j)
                    agent_distances.append((dist, j))
            
            # Sort by distance and take m closest
            agent_distances.sort()
            closest_distances = [d[0] for d in agent_distances[:m]]
            total_distance = sum(closest_distances)
            distances.append((total_distance, i))
        
        # Select agent with minimum total distance to its m closest neighbors
        distances.sort()
        selected_agent_idx = distances[0][1]
        
        return agent_parameters[selected_agent_idx]
    
    def _federated_averaging(self, agent_parameters: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        """
        Standard federated averaging (FedAvg).
        
        Simple averaging of all agent parameters - not Byzantine fault-tolerant.
        """
        if not agent_parameters:
            return {}
            
        consensus_params = {}
        
        for param_name in agent_parameters[0].keys():
            # Stack and average parameters
            param_stack = torch.stack([params[param_name] for params in agent_parameters])
            consensus_params[param_name] = torch.mean(param_stack, dim=0)
            
        return consensus_params
    
    def _calculate_parameter_distance(self, params1: Dict[str, torch.Tensor], 
                                    params2: Dict[str, torch.Tensor]) -> float:
        """Calculate Euclidean distance between parameter sets."""
        total_distance = 0.0
        
        for param_name in params1.keys():
            if param_name in params2:
                p1_flat = params1[param_name].flatten()
                p2_flat = params2[param_name].flatten()
                distance = torch.norm(p1_flat - p2_flat, p=2).item()
                total_distance += distance
                
        return total_distance
    
    def _evaluate_consensus_quality(self, agent_parameters: List[Dict[str, torch.Tensor]], 
                                  consensus_params: Dict[str, torch.Tensor]) -> float:
        """
        Evaluate quality of consensus by measuring parameter variance.
        
        Returns:
            Quality score (lower variance = higher quality)
        """
        if not agent_parameters or not consensus_params:
            return 0.0
            
        total_variance = 0.0
        param_count = 0
        
        for param_name in consensus_params.keys():
            consensus_param = consensus_params[param_name].flatten()
            
            # Calculate variance from consensus
            variances = []
            for agent_params in agent_parameters:
                if param_name in agent_params:
                    agent_param = agent_params[param_name].flatten()
                    variance = torch.var(agent_param - consensus_param).item()
                    variances.append(variance)
            
            if variances:
                total_variance += np.mean(variances)
                param_count += 1
                
        return total_variance / param_count if param_count > 0 else 0.0
    
    def _update_algorithm_stats(self, algorithm: str, elapsed_time: float):
        """Update performance statistics for consensus algorithms."""
        if algorithm in self.algorithm_stats:
            stats = self.algorithm_stats[algorithm]
            stats['calls'] += 1
            # Running average of execution time
            stats['avg_time'] = (stats['avg_time'] * (stats['calls'] - 1) + elapsed_time) / stats['calls']
    
    def get_consensus_statistics(self) -> Dict[str, Any]:
        """Get comprehensive consensus performance statistics."""
        if not self.consensus_history:
            return {'message': 'No consensus operations performed yet'}
            
        stats = {
            'total_consensus_rounds': len(self.consensus_history),
            'algorithm_performance': self.algorithm_stats.copy(),
            'recent_quality': [h['consensus_quality'] for h in self.consensus_history[-10:]],
            'participant_distribution': {}
        }
        
        # Analyze participant distribution
        participant_counts = [h['num_participants'] for h in self.consensus_history]
        stats['participant_distribution'] = {
            'min': min(participant_counts),
            'max': max(participant_counts), 
            'avg': np.mean(participant_counts),
            'std': np.std(participant_counts)
        }
        
        return stats
    
    def adaptive_consensus_selection(self, agent_parameters: List[Dict[str, torch.Tensor]], 
                                   network_conditions: Dict[str, float]) -> str:
        """
        Adaptively select consensus algorithm based on network conditions.
        
        Args:
            agent_parameters: Current agent parameters
            network_conditions: Network latency, bandwidth, etc.
            
        Returns:
            Recommended consensus algorithm
        """
        num_agents = len(agent_parameters)
        latency = network_conditions.get('latency', 10.0)  # ms
        bandwidth = network_conditions.get('bandwidth', 100.0)  # Mbps
        
        # Decision logic based on network conditions
        if num_agents < 3:
            return 'fedavg'  # Not enough agents for Byzantine tolerance
        elif latency > 50 or bandwidth < 10:
            return 'fedavg'  # Poor network - use fast algorithm
        elif num_agents > 10 and self.byzantine_tolerance > 0.2:
            return 'krum'  # Many agents with high Byzantine tolerance
        else:
            return 'trimmed_mean'  # Default Byzantine fault-tolerant choice 