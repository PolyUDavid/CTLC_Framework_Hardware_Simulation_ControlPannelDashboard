"""
DDRL API Interface for Third-Party Integration

This API provides a standardized interface for external systems to integrate
with distributed deep reinforcement learning algorithms.
"""

import torch
import numpy as np
from typing import Dict, List, Tuple, Optional, Any, Callable
import json
import time
from dataclasses import dataclass
from enum import Enum

from ..algorithms.sac_distributed import DistributedSAC
from ..algorithms.consensus_manager import ConsensusManager
from ..utils.distributed_buffer import DistributedReplayBuffer

class AgentType(Enum):
    LEARNER = "learner"
    ACTOR = "actor" 
    BOTH = "both"

@dataclass
class AgentConfig:
    """Configuration for DDRL agents"""
    agent_id: str
    agent_type: AgentType
    state_dim: int
    action_dim: int
    hidden_dim: int = 256
    learning_rate: float = 3e-4
    device: str = "cpu"
    
@dataclass
class Experience:
    """Standard experience tuple for RL"""
    state: np.ndarray
    action: np.ndarray
    reward: float
    next_state: np.ndarray
    done: bool
    timestamp: float
    agent_id: str

class DDRL_API:
    """
    Main API interface for Distributed Deep Reinforcement Learning.
    
    This class provides methods for:
    - Multi-agent distributed training
    - Byzantine fault-tolerant consensus
    - Hardware device integration
    - Real-time policy updates
    """
    
    def __init__(self, network_config: Dict[str, Any] = None):
        """
        Initialize DDRL API.
        
        Args:
            network_config: Network configuration for distributed training
        """
        self.network_config = self._load_default_network_config()
        if network_config:
            self.network_config.update(network_config)
            
        # Core components
        self.agents = {}  # Dict[agent_id, DistributedSAC]
        self.consensus_manager = ConsensusManager(
            byzantine_tolerance=self.network_config.get('byzantine_tolerance', 0.3)
        )
        
        # Global shared buffer (optional)
        if self.network_config.get('use_shared_buffer', False):
            self.shared_buffer = DistributedReplayBuffer(
                buffer_size=self.network_config.get('shared_buffer_size', 100000)
            )
        else:
            self.shared_buffer = None
            
        # Network state
        self.registered_agents = {}
        self.training_stats = {
            'total_episodes': 0,
            'consensus_rounds': 0,
            'avg_reward': 0.0,
            'model_synchronizations': 0,
            'last_consensus_time': 0.0
        }
        
        # Hardware integration callbacks
        self.hardware_callbacks = {
            'pre_action': [],
            'post_action': [],
            'pre_learning': [],
            'post_learning': []
        }
        
    def register_agent(self, config: AgentConfig) -> bool:
        """
        Register a new agent in the distributed network.
        
        Args:
            config: AgentConfig object with agent specifications
            
        Returns:
            bool: True if registration successful
        """
        try:
            # Create distributed SAC agent
            agent = DistributedSAC(
                agent_id=config.agent_id,
                state_dim=config.state_dim,
                action_dim=config.action_dim,
                hidden_dim=config.hidden_dim,
                learning_rate=config.learning_rate,
                device=config.device
            )
            
            self.agents[config.agent_id] = agent
            self.registered_agents[config.agent_id] = {
                'config': config,
                'last_seen': time.time(),
                'status': 'active',
                'rewards_history': [],
                'training_steps': 0
            }
            
            print(f"[DDRL API] Agent {config.agent_id} registered successfully")
            return True
            
        except Exception as e:
            print(f"[DDRL API] Agent registration failed: {e}")
            return False
    
    def unregister_agent(self, agent_id: str) -> bool:
        """Remove an agent from the distributed network."""
        if agent_id in self.agents:
            del self.agents[agent_id]
            del self.registered_agents[agent_id]
            print(f"[DDRL API] Agent {agent_id} unregistered")
            return True
        return False
    
    def select_action(self, agent_id: str, state: np.ndarray, 
                     evaluation_mode: bool = False) -> Optional[np.ndarray]:
        """
        API method for action selection.
        
        Args:
            agent_id: ID of the acting agent
            state: Current observation/state
            evaluation_mode: Whether to use deterministic policy
            
        Returns:
            Selected action or None if agent not found
        """
        if agent_id not in self.agents:
            print(f"[DDRL API] Agent {agent_id} not found")
            return None
            
        try:
            # Execute pre-action callbacks
            for callback in self.hardware_callbacks['pre_action']:
                callback(agent_id, state)
                
            # Agent selects action
            action = self.agents[agent_id].select_action(state, evaluation_mode)
            
            # Execute post-action callbacks  
            for callback in self.hardware_callbacks['post_action']:
                callback(agent_id, state, action)
                
            return action
            
        except Exception as e:
            print(f"[DDRL API] Action selection error for {agent_id}: {e}")
            return None
    
    def store_experience(self, experience: Experience) -> bool:
        """
        Store experience in agent's replay buffer.
        
        Args:
            experience: Experience tuple to store
            
        Returns:
            bool: True if storage successful
        """
        agent_id = experience.agent_id
        
        if agent_id not in self.agents:
            return False
            
        try:
            # Store in agent's local buffer
            self.agents[agent_id].store_experience(
                experience.state,
                experience.action, 
                experience.reward,
                experience.next_state,
                experience.done
            )
            
            # Optionally store in shared buffer
            if self.shared_buffer:
                self.shared_buffer.push(experience)
                
            # Update agent stats
            self.registered_agents[agent_id]['rewards_history'].append(experience.reward)
            self.registered_agents[agent_id]['last_seen'] = time.time()
            
            return True
            
        except Exception as e:
            print(f"[DDRL API] Experience storage error: {e}")
            return False
    
    def update_agent(self, agent_id: str) -> Dict[str, float]:
        """
        Perform learning update for a specific agent.
        
        Args:
            agent_id: ID of the agent to update
            
        Returns:
            Dict containing training metrics
        """
        if agent_id not in self.agents:
            return {'error': 'Agent not found'}
            
        try:
            # Execute pre-learning callbacks
            for callback in self.hardware_callbacks['pre_learning']:
                callback(agent_id)
                
            # Perform learning update
            metrics = self.agents[agent_id].update()
            
            # Update training stats
            if metrics:
                self.registered_agents[agent_id]['training_steps'] += 1
                
            # Execute post-learning callbacks
            for callback in self.hardware_callbacks['post_learning']:
                callback(agent_id, metrics)
                
            return metrics or {}
            
        except Exception as e:
            print(f"[DDRL API] Learning update error for {agent_id}: {e}")
            return {'error': str(e)}
    
    def perform_consensus_update(self, participant_ids: List[str] = None) -> Dict[str, Any]:
        """
        Perform distributed consensus update across agents.
        
        Args:
            participant_ids: List of agent IDs to include (None = all agents)
            
        Returns:
            Dict containing consensus results
        """
        if participant_ids is None:
            participant_ids = list(self.agents.keys())
            
        try:
            start_time = time.time()
            
            # Collect model parameters from participants
            agent_parameters = {}
            for agent_id in participant_ids:
                if agent_id in self.agents:
                    params = self.agents[agent_id].get_model_parameters()
                    agent_parameters[agent_id] = params
            
            if len(agent_parameters) < 2:
                return {'error': 'Need at least 2 agents for consensus'}
                
            # Perform Byzantine fault-tolerant consensus
            consensus_params = self.consensus_manager.byzantine_consensus(
                list(agent_parameters.values())
            )
            
            # Update all participating agents
            updated_agents = 0
            for agent_id in participant_ids:
                if agent_id in self.agents:
                    self.agents[agent_id].update_model_parameters(consensus_params)
                    updated_agents += 1
            
            # Update statistics
            consensus_time = time.time() - start_time
            self.training_stats['consensus_rounds'] += 1
            self.training_stats['model_synchronizations'] += updated_agents
            self.training_stats['last_consensus_time'] = consensus_time
            
            return {
                'success': True,
                'participants': len(agent_parameters),
                'updated_agents': updated_agents,
                'consensus_time_ms': consensus_time * 1000,
                'round_number': self.training_stats['consensus_rounds']
            }
            
        except Exception as e:
            print(f"[DDRL API] Consensus update error: {e}")
            return {'error': str(e)}
    
    def export_agent_model(self, agent_id: str, output_path: str, 
                          format: str = 'pytorch') -> bool:
        """
        Export trained model for hardware deployment.
        
        Args:
            agent_id: ID of agent to export
            output_path: Path to save model
            format: Export format ('pytorch', 'onnx', 'tensorrt')
            
        Returns:
            bool: True if export successful
        """
        if agent_id not in self.agents:
            return False
            
        try:
            return self.agents[agent_id].export_model(output_path, format)
        except Exception as e:
            print(f"[DDRL API] Model export error: {e}")
            return False
    
    def get_training_statistics(self) -> Dict[str, Any]:
        """Get comprehensive training statistics."""
        stats = self.training_stats.copy()
        
        # Calculate aggregate metrics
        all_rewards = []
        total_training_steps = 0
        
        for agent_info in self.registered_agents.values():
            all_rewards.extend(agent_info['rewards_history'][-100:])  # Last 100 rewards
            total_training_steps += agent_info['training_steps']
            
        if all_rewards:
            stats['avg_reward'] = np.mean(all_rewards)
            stats['reward_std'] = np.std(all_rewards)
            
        stats['total_training_steps'] = total_training_steps
        stats['active_agents'] = len(self.agents)
        
        return stats
    
    def register_hardware_callback(self, event_type: str, callback: Callable):
        """
        Register hardware integration callbacks.
        
        Args:
            event_type: Type of event ('pre_action', 'post_action', etc.)
            callback: Function to call on event
        """
        if event_type in self.hardware_callbacks:
            self.hardware_callbacks[event_type].append(callback)
            print(f"[DDRL API] Hardware callback registered for {event_type}")
        else:
            print(f"[DDRL API] Unknown event type: {event_type}")
    
    def _load_default_network_config(self) -> Dict[str, Any]:
        """Load default network configuration."""
        return {
            'byzantine_tolerance': 0.3,
            'consensus_frequency': 50,  # steps
            'use_shared_buffer': False,
            'shared_buffer_size': 100000,
            'max_agents': 20,
            'communication_timeout': 5.0  # seconds
        } 