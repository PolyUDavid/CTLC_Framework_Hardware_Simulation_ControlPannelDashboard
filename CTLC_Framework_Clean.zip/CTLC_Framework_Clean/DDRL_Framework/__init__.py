"""
DDRL Framework: Distributed Deep Reinforcement Learning for 6G-IoT Systems

This framework provides a modular, consensus-driven implementation of distributed
deep reinforcement learning algorithms optimized for vehicular networks.

Key Features:
- Hardware-agnostic API interface  
- Byzantine fault-tolerant consensus
- Real-time distributed training
- Third-party hardware integration
- SAC/PPO/DDPG algorithm support
"""

__version__ = "1.0.0"
__author__ = "CTLC Research Team"

from .api.ddrl_api import DDRL_API
from .algorithms.sac_distributed import DistributedSAC
from .algorithms.consensus_manager import ConsensusManager
from .utils.distributed_buffer import DistributedReplayBuffer

__all__ = [
    'DDRL_API',
    'DistributedSAC',
    'ConsensusManager', 
    'DistributedReplayBuffer'
] 