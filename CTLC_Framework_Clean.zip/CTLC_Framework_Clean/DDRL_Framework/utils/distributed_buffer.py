"""
Distributed Replay Buffer for Multi-Agent Systems

Provides shared experience storage and sampling for distributed learning.
"""

import numpy as np
import threading
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
import time

@dataclass
class DistributedExperience:
    """Experience tuple for distributed systems."""
    agent_id: str
    state: np.ndarray
    action: np.ndarray
    reward: float
    next_state: np.ndarray
    done: bool
    timestamp: float
    priority: float = 1.0

class DistributedReplayBuffer:
    """
    Thread-safe distributed replay buffer for multi-agent learning.
    
    Features:
    - Thread-safe operations
    - Priority-based sampling
    - Agent-specific filtering
    - Memory-efficient storage
    """
    
    def __init__(self, buffer_size: int = 100000):
        """
        Initialize distributed replay buffer.
        
        Args:
            buffer_size: Maximum number of experiences to store
        """
        self.buffer_size = buffer_size
        self.buffer = []
        self.position = 0
        self.size = 0
        
        # Thread safety
        self.lock = threading.RLock()
        
        # Statistics
        self.stats = {
            'total_pushes': 0,
            'total_samples': 0,
            'agent_contributions': {},
            'last_update': time.time()
        }
        
    def push(self, experience: DistributedExperience):
        """
        Add experience to buffer in thread-safe manner.
        
        Args:
            experience: DistributedExperience to add
        """
        with self.lock:
            if len(self.buffer) < self.buffer_size:
                self.buffer.append(experience)
                self.size += 1
            else:
                self.buffer[self.position] = experience
                
            self.position = (self.position + 1) % self.buffer_size
            
            # Update statistics
            self.stats['total_pushes'] += 1
            agent_id = experience.agent_id
            if agent_id not in self.stats['agent_contributions']:
                self.stats['agent_contributions'][agent_id] = 0
            self.stats['agent_contributions'][agent_id] += 1
            self.stats['last_update'] = time.time()
    
    def sample(self, batch_size: int, agent_id: Optional[str] = None) -> List[DistributedExperience]:
        """
        Sample experiences from buffer.
        
        Args:
            batch_size: Number of experiences to sample
            agent_id: If specified, sample only from this agent
            
        Returns:
            List of sampled experiences
        """
        with self.lock:
            if self.size == 0:
                return []
                
            # Filter by agent if specified
            if agent_id:
                available_experiences = [exp for exp in self.buffer[:self.size] 
                                       if exp.agent_id == agent_id]
            else:
                available_experiences = self.buffer[:self.size]
                
            if len(available_experiences) == 0:
                return []
                
            # Sample with priority weights
            priorities = np.array([exp.priority for exp in available_experiences])
            probabilities = priorities / np.sum(priorities)
            
            sample_size = min(batch_size, len(available_experiences))
            indices = np.random.choice(len(available_experiences), 
                                     size=sample_size, 
                                     p=probabilities, 
                                     replace=True)
            
            sampled_experiences = [available_experiences[i] for i in indices]
            
            # Update statistics
            self.stats['total_samples'] += len(sampled_experiences)
            
            return sampled_experiences
    
    def get_agent_buffer_size(self, agent_id: str) -> int:
        """Get number of experiences for specific agent."""
        with self.lock:
            return sum(1 for exp in self.buffer[:self.size] if exp.agent_id == agent_id)
    
    def clear_agent_data(self, agent_id: str):
        """Remove all experiences from specific agent."""
        with self.lock:
            self.buffer = [exp for exp in self.buffer[:self.size] if exp.agent_id != agent_id]
            self.size = len(self.buffer)
            self.position = self.size % self.buffer_size
            
            # Update statistics
            if agent_id in self.stats['agent_contributions']:
                del self.stats['agent_contributions'][agent_id]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get buffer usage statistics."""
        with self.lock:
            stats = self.stats.copy()
            stats['current_size'] = self.size
            stats['buffer_utilization'] = self.size / self.buffer_size
            stats['unique_agents'] = len(self.stats['agent_contributions'])
            return stats
    
    def __len__(self) -> int:
        """Get current buffer size."""
        return self.size 