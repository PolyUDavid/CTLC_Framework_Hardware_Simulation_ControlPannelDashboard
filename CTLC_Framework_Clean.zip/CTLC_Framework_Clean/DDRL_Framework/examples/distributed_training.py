"""
Distributed DDRL Training Example

This example demonstrates how to set up distributed deep reinforcement
learning with Byzantine fault-tolerant consensus for vehicular networks.
"""

import numpy as np
import time
from typing import List, Dict, Any

# Import the DDRL framework
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from api.ddrl_api import DDRL_API, AgentConfig, Experience, AgentType

class SimulatedVehicle:
    """
    Simulates a vehicle with learning capabilities.
    """
    
    def __init__(self, vehicle_id: str, initial_position: np.ndarray):
        self.vehicle_id = vehicle_id
        self.position = initial_position.copy()
        self.velocity = np.zeros(2)
        self.target_position = np.random.uniform(0, 1000, 2)
        
        # Vehicle characteristics
        self.max_speed = 20.0
        self.max_acceleration = 5.0
        
    def get_state(self) -> np.ndarray:
        """Get current vehicle state for RL."""
        # Relative position to target
        rel_pos = self.target_position - self.position
        
        state = np.concatenate([
            self.position / 1000.0,  # Normalized position
            self.velocity / self.max_speed,  # Normalized velocity
            rel_pos / 1000.0,  # Normalized relative position
            [np.linalg.norm(rel_pos) / 1000.0]  # Distance to target
        ])
        
        return state.astype(np.float32)
    
    def apply_action(self, action: np.ndarray, dt: float = 0.1):
        """Apply RL action to vehicle dynamics."""
        # Action: [acceleration_x, acceleration_y]
        acceleration = np.clip(action * self.max_acceleration, -self.max_acceleration, self.max_acceleration)
        
        # Update velocity and position
        self.velocity += acceleration * dt
        self.velocity = np.clip(self.velocity, -self.max_speed, self.max_speed)
        self.position += self.velocity * dt
        
        # Keep vehicle in bounds
        self.position = np.clip(self.position, 0, 1000)
        
    def get_reward(self) -> float:
        """Calculate reward for current state."""
        # Distance to target (negative reward)
        distance_to_target = np.linalg.norm(self.target_position - self.position)
        distance_reward = -distance_to_target / 1000.0
        
        # Speed penalty (encourage smooth driving)
        speed_penalty = -0.1 * (np.linalg.norm(self.velocity) / self.max_speed) ** 2
        
        # Target reached bonus
        target_bonus = 10.0 if distance_to_target < 50 else 0.0
        
        return distance_reward + speed_penalty + target_bonus
    
    def is_at_target(self) -> bool:
        """Check if vehicle reached target."""
        return np.linalg.norm(self.target_position - self.position) < 50
    
    def reset_target(self):
        """Set new random target."""
        self.target_position = np.random.uniform(0, 1000, 2)

def simulate_network_conditions() -> Dict[str, float]:
    """Simulate varying 6G network conditions."""
    # Base 6G conditions
    base_latency = 1.0  # ms
    base_bandwidth = 1000.0  # Mbps
    
    # Add realistic variations
    latency_noise = np.random.normal(0, 0.3)
    bandwidth_noise = np.random.normal(0, 200)
    
    return {
        'latency': max(0.1, base_latency + latency_noise),
        'bandwidth': max(100, base_bandwidth + bandwidth_noise),
        'reliability': np.random.uniform(0.8, 1.0)
    }

def simulate_byzantine_agents(agent_configs: List[AgentConfig], 
                            byzantine_ratio: float = 0.2) -> List[str]:
    """Randomly select agents to simulate Byzantine behavior."""
    num_byzantine = int(len(agent_configs) * byzantine_ratio)
    all_ids = [config.agent_id for config in agent_configs]
    byzantine_ids = np.random.choice(all_ids, num_byzantine, replace=False)
    return list(byzantine_ids)

def main():
    """
    Main distributed DDRL training demonstration.
    """
    print("🤖 Distributed DDRL Training with Consensus Example")
    print("=" * 60)
    
    # Configuration
    num_vehicles = 8
    state_dim = 7  # [pos_x, pos_y, vel_x, vel_y, rel_pos_x, rel_pos_y, distance]
    action_dim = 2  # [accel_x, accel_y]
    training_steps = 200
    consensus_frequency = 25  # Perform consensus every 25 steps
    
    # Initialize DDRL API
    network_config = {
        'byzantine_tolerance': 0.3,
        'consensus_frequency': consensus_frequency,
        'use_shared_buffer': False,
        'max_agents': num_vehicles
    }
    
    ddrl_api = DDRL_API(network_config)
    print("✅ DDRL API initialized with Byzantine fault tolerance")
    
    # Create vehicle fleet
    vehicles = []
    agent_configs = []
    
    for i in range(num_vehicles):
        # Create vehicle
        initial_pos = np.random.uniform(100, 900, 2)
        vehicle = SimulatedVehicle(f"vehicle_{i:03d}", initial_pos)
        vehicles.append(vehicle)
        
        # Create agent configuration
        config = AgentConfig(
            agent_id=vehicle.vehicle_id,
            agent_type=AgentType.BOTH,  # Each agent both learns and acts
            state_dim=state_dim,
            action_dim=action_dim,
            hidden_dim=128,
            learning_rate=3e-4,
            device='cpu'
        )
        agent_configs.append(config)
        
        # Register agent with DDRL API
        success = ddrl_api.register_agent(config)
        if success:
            print(f"✅ Registered {vehicle.vehicle_id}")
        else:
            print(f"❌ Failed to register {vehicle.vehicle_id}")
    
    # Simulate Byzantine agents (for demonstration)
    byzantine_agents = simulate_byzantine_agents(agent_configs, 0.2)
    print(f"⚠️  Simulating Byzantine behavior in: {byzantine_agents}")
    
    # Hardware integration example
    def hardware_callback(agent_id: str, state: np.ndarray, action: np.ndarray = None):
        """Example hardware integration callback."""
        if agent_id in byzantine_agents:
            # Simulate hardware malfunction logging
            print(f"🔍 Hardware monitor detected anomaly in {agent_id}")
    
    ddrl_api.register_hardware_callback('post_action', hardware_callback)
    print("🔧 Hardware integration callbacks registered")
    
    print(f"\n🚀 Starting distributed training with {num_vehicles} agents...")
    
    # Training loop
    for step in range(training_steps):
        step_start_time = time.time()
        
        print(f"\n--- Training Step {step + 1} ---")
        
        # Simulate network conditions
        network_conditions = simulate_network_conditions()
        
        # Each vehicle takes action and learns
        step_rewards = []
        step_actions = []
        
        for vehicle in vehicles:
            # Get current state
            current_state = vehicle.get_state()
            
            # Agent selects action
            action = ddrl_api.select_action(vehicle.vehicle_id, current_state)
            
            if action is not None:
                # Apply action to vehicle
                vehicle.apply_action(action)
                
                # Calculate reward
                reward = vehicle.get_reward()
                step_rewards.append(reward)
                step_actions.append(action)
                
                # Get next state
                next_state = vehicle.get_state()
                done = vehicle.is_at_target()
                
                # Store experience
                experience = Experience(
                    state=current_state,
                    action=action,
                    reward=reward,
                    next_state=next_state,
                    done=done,
                    timestamp=time.time(),
                    agent_id=vehicle.vehicle_id
                )
                
                ddrl_api.store_experience(experience)
                
                # Perform learning update
                metrics = ddrl_api.update_agent(vehicle.vehicle_id)
                
                # Reset target if reached
                if done:
                    vehicle.reset_target()
                    print(f"🎯 {vehicle.vehicle_id} reached target!")
                
                # Simulate Byzantine behavior
                if vehicle.vehicle_id in byzantine_agents and np.random.random() < 0.1:
                    print(f"⚠️  Byzantine behavior from {vehicle.vehicle_id}")
            else:
                print(f"❌ Action selection failed for {vehicle.vehicle_id}")
        
        # Periodic consensus updates
        if (step + 1) % consensus_frequency == 0 and len(step_rewards) > 0:
            print(f"\n🤝 Performing consensus update...")
            
            # Adaptive consensus algorithm selection
            from algorithms.consensus_manager import ConsensusManager
            consensus_manager = ConsensusManager(byzantine_tolerance=0.3)
            algorithm = consensus_manager.adaptive_consensus_selection(
                [], network_conditions  # Simplified for example
            )
            
            consensus_results = ddrl_api.perform_consensus_update()
            
            if 'error' not in consensus_results:
                print(f"✅ Consensus completed:")
                print(f"   Participants: {consensus_results['participants']}")
                print(f"   Updated agents: {consensus_results['updated_agents']}")
                print(f"   Time: {consensus_results['consensus_time_ms']:.2f}ms")
                print(f"   Algorithm: {algorithm}")
            else:
                print(f"❌ Consensus failed: {consensus_results['error']}")
        
        # Performance reporting
        if len(step_rewards) > 0:
            avg_reward = np.mean(step_rewards)
            print(f"📊 Step {step + 1} Performance:")
            print(f"   Average reward: {avg_reward:.3f}")
            print(f"   Active agents: {len(step_rewards)}")
            print(f"   Network latency: {network_conditions['latency']:.2f}ms")
            print(f"   Network bandwidth: {network_conditions['bandwidth']:.0f}Mbps")
        
        step_time = time.time() - step_start_time
        print(f"⏱️  Step time: {step_time:.3f}s")
        
        # Brief pause to simulate real-time operation
        time.sleep(0.05)
    
    print("\n📈 Training completed! Generating final statistics...")
    
    # Get comprehensive training statistics
    final_stats = ddrl_api.get_training_statistics()
    
    print(f"\n🏆 Final Training Report:")
    print(f"   Total consensus rounds: {final_stats['consensus_rounds']}")
    print(f"   Model synchronizations: {final_stats['model_synchronizations']}")
    print(f"   Average reward: {final_stats.get('avg_reward', 0):.3f}")
    print(f"   Active agents: {final_stats['active_agents']}")
    print(f"   Total training steps: {final_stats['total_training_steps']}")
    
    # Demonstrate model export for deployment
    print(f"\n🚀 Exporting trained models for deployment...")
    
    export_success_count = 0
    for vehicle in vehicles[:3]:  # Export first 3 vehicles as example
        export_path = f"deployed_models/{vehicle.vehicle_id}_model.pth"
        success = ddrl_api.export_agent_model(vehicle.vehicle_id, export_path)
        
        if success:
            export_success_count += 1
            print(f"✅ Exported {vehicle.vehicle_id} model")
        else:
            print(f"❌ Failed to export {vehicle.vehicle_id} model")
    
    print(f"\n🎯 Successfully exported {export_success_count} models for hardware deployment")
    
    # Cleanup
    for vehicle in vehicles:
        ddrl_api.unregister_agent(vehicle.vehicle_id)
    
    print("\n🏁 Distributed DDRL training example completed successfully!")
    print("   Your system can now deploy these models to real vehicles/hardware.")

if __name__ == "__main__":
    try:
        # Create output directory for models
        os.makedirs("deployed_models", exist_ok=True)
        main()
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Please ensure the DDRL framework is properly installed.")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("Please check your configuration and try again.") 