#!/usr/bin/env python3
"""
分布式决策增强CTLC框架 - 实时仿真
Distributed Decision-Making Enhanced CTLC Framework - Real-time Simulation

与集中式版本完全相同的界面和功能，但所有决策都是分布式进行的
Identical interface and features to centralized version, but all decisions are made distributedly
"""

import pygame
import numpy as np
import torch
import time
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Any

# Import all components
from src.simulation.simulation_manager import SimulationManager
from src.utils.config import Config
from src.utils.network_6g import SixGNetworkModel
from src.algorithms.consensus_protected_ddrl import ConsensusProtectedDDRL, AggregationMethod
from src.agents.hocbf_qp_controller import HOCBFController
from src.agents.hocbf_qp_controller import VehicleState as HOCBFVehicleState
from src.models.multimodal_fusion import MultiModalFusionNetwork, SensorData, SensorModality
from src.agents.dmpc_controller import DistributedMPCController, PredictionHorizon, DMPCConstraint, ConstraintType, VehicleState

# Enable enhanced features
ENHANCED_FEATURES = True

@dataclass
class DistributedAgent:
    """分布式智能体 - 每个车辆都有独立的决策能力"""
    agent_id: str
    vehicle_id: str
    
    # 独立的决策组件
    local_ddrl: ConsensusProtectedDDRL
    local_dmpc: DistributedMPCController
    local_hocbf: HOCBFController
    local_fusion: MultiModalFusionNetwork
    
    # 本地状态和知识
    local_knowledge: Dict[str, Any]
    neighbor_info: Dict[str, Any]
    communication_buffer: List[Dict]
    
    # 决策历史
    decision_history: List[Dict]
    performance_metrics: Dict[str, Any]

class DistributedCTLCSimulation:
    """分布式CTLC仿真 - 完全分布式决策制定"""
    
    def __init__(self, screen):
        self.screen = screen
        
        # 初始化基础仿真管理器（界面保持相同）
        self.sim_manager = SimulationManager(screen)
        
        # 分布式智能体管理
        self.distributed_agents: Dict[str, DistributedAgent] = {}
        self.agent_counter = 0
        
        if ENHANCED_FEATURES:
            # 6G网络模型（为分布式通信提供支持）
            self.network_6g = SixGNetworkModel()
            
            # 分布式协调组件
            self.distributed_coordinator = self._create_distributed_coordinator()
            
        # 性能指标（与集中式版本完全相同的显示）
        self.performance_metrics = {
            'network_6g': {},
            'consensus_ddrl': {},
            'hocbf_safety': {},
            'multimodal_fusion': {},
            'distributed_coordination': {},  # 新增分布式协调指标
            'overall_system': {
                'frame_count': 0,
                'avg_fps': 0,
                'total_runtime': 0,
                'start_time': time.time(),
                'feature_status': {
                    '6g_network': ENHANCED_FEATURES,
                    'distributed_consensus': ENHANCED_FEATURES,
                    'distributed_safety': ENHANCED_FEATURES,
                    'distributed_fusion': ENHANCED_FEATURES,
                    'distributed_coordination': ENHANCED_FEATURES
                }
            }
        }
        
        # 显示字体（与原版完全相同）
        self.font = pygame.font.Font(None, 24)
        self.small_font = pygame.font.Font(None, 18)
        self.title_font = pygame.font.Font(None, 28)
        
        print("🚀 分布式增强CTLC框架初始化完成！")
        if ENHANCED_FEATURES:
            print("✅ 分布式6G网络建模: 激活")
            print("✅ 分布式共识保护DDRL: 激活") 
            print("✅ 分布式HOCBF-QP安全控制: 激活")
            print("✅ 分布式多模态传感器融合: 激活")
            print("✅ 分布式协调决策: 激活")
        else:
            print("⚠️ 仅运行基础功能")
    
    def _create_distributed_coordinator(self):
        """创建分布式协调器"""
        return {
            'consensus_rounds': 0,
            'active_negotiations': {},
            'coordination_history': [],
            'conflict_resolution_count': 0
        }
    
    def create_distributed_agent(self, vehicle_id: str) -> DistributedAgent:
        """为每个车辆创建独立的分布式智能体"""
        if not ENHANCED_FEATURES:
            return None
            
        agent_id = f"agent_{self.agent_counter}"
        self.agent_counter += 1
        
        # 每个智能体都有独立的决策组件
        local_ddrl = ConsensusProtectedDDRL(
            agent_id=agent_id,
            n_agents=5,  # 假设局部邻居数量
            f_byzantine=1,  # 局部拜占庭容错
            aggregation_method=AggregationMethod.TRIMMED_MEAN,
            learning_rate=0.001
        )
        
        # 分布式MPC控制器
        horizon = PredictionHorizon(prediction_steps=8, control_steps=3, dt=0.1)
        constraints = [
            DMPCConstraint(ConstraintType.COLLISION_AVOIDANCE, {'safe_distance': 5.0}),
            DMPCConstraint(ConstraintType.SPEED_LIMIT, {'max_speed': 25.0}),
            DMPCConstraint(ConstraintType.COMMUNICATION_RANGE, {'max_range': 100.0})
        ]
        local_dmpc = DistributedMPCController(vehicle_id, horizon, constraints)
        
        # 本地HOCBF控制器
        local_hocbf = HOCBFController(
            vehicle_id=vehicle_id,
            safe_distance=Config.MIN_SAFE_DIST
        )
        
        # 本地多模态融合网络
        local_fusion = MultiModalFusionNetwork(
            output_dim=256,
            seq_length=5,
            use_temporal=True
        )
        
        agent = DistributedAgent(
            agent_id=agent_id,
            vehicle_id=vehicle_id,
            local_ddrl=local_ddrl,
            local_dmpc=local_dmpc,
            local_hocbf=local_hocbf,
            local_fusion=local_fusion,
            local_knowledge={
                'local_map': {},
                'traffic_patterns': {},
                'learned_policies': {}
            },
            neighbor_info={},
            communication_buffer=[],
            decision_history=[],
            performance_metrics={
                'decisions_made': 0,
                'consensus_participations': 0,
                'safety_interventions': 0,
                'communication_events': 0
            }
        )
        
        self.distributed_agents[vehicle_id] = agent
        print(f"✅ 创建分布式智能体: {agent_id} -> 车辆 {vehicle_id}")
        
        return agent
    
    def simulate_distributed_6g_network(self, vehicles):
        """分布式6G网络仿真 - 每个节点独立管理网络连接"""
        if not ENHANCED_FEATURES:
            return {'network_active': False}
            
        vehicle_count = len(vehicles) if vehicles else 0
        rsu_count = 7
        traffic_density = min(vehicle_count / 20.0, 1.0)
        
        # 更新全局网络状态
        self.network_6g.update_network_conditions(vehicle_count, rsu_count, traffic_density)
        
        # 为每个分布式智能体计算局部网络状态
        for vehicle in vehicles:
            vehicle_id = getattr(vehicle, 'vehicle_id', f'vehicle_{id(vehicle)}')
            if vehicle_id in self.distributed_agents:
                agent = self.distributed_agents[vehicle_id]
                
                # 计算该智能体的局部网络状态
                local_network_state = self._compute_local_network_state(agent, vehicles)
                agent.local_knowledge['network_state'] = local_network_state
        
        # 获取显示状态（与集中式版本相同）
        network_status = self.network_6g.get_network_status_display()
        self.performance_metrics['network_6g'] = network_status
        
        urllc_weight, embb_weight = self.network_6g.get_adaptive_weights()
        
        return {
            'urllc_weight': urllc_weight,
            'embb_weight': embb_weight,
            'network_status': network_status,
            'network_active': True,
            'distributed_nodes': len(self.distributed_agents)
        }
    
    def _compute_local_network_state(self, agent: DistributedAgent, all_vehicles):
        """计算单个智能体的局部网络状态"""
        # 找到通信范围内的邻居
        agent_vehicle = None
        for v in all_vehicles:
            if getattr(v, 'vehicle_id', f'vehicle_{id(v)}') == agent.vehicle_id:
                agent_vehicle = v
                break
        
        if not agent_vehicle:
            return {'neighbors': [], 'local_quality': 0.5}
        
        neighbors = []
        for v in all_vehicles:
            if v != agent_vehicle:
                distance = np.linalg.norm(
                    agent_vehicle.position - v.position
                )
                if distance <= 100.0:  # 通信范围
                    neighbors.append({
                        'vehicle_id': getattr(v, 'vehicle_id', f'vehicle_{id(v)}'),
                        'distance': distance,
                        'signal_quality': max(0.1, 1.0 - distance/100.0)
                    })
        
        local_quality = np.mean([n['signal_quality'] for n in neighbors]) if neighbors else 0.1
        
        return {
            'neighbors': neighbors,
            'local_quality': local_quality,
            'neighbor_count': len(neighbors)
        }
    
    def simulate_distributed_consensus_learning(self, vehicles):
        """分布式共识学习 - 每个智能体独立参与共识过程"""
        if not ENHANCED_FEATURES or not vehicles or len(vehicles) < 2:
            return {'consensus_active': False}
        
        active_agents = []
        for vehicle in vehicles:
            vehicle_id = getattr(vehicle, 'vehicle_id', f'vehicle_{id(vehicle)}')
            if vehicle_id in self.distributed_agents:
                active_agents.append(self.distributed_agents[vehicle_id])
        
        if len(active_agents) < 2:
            return {'consensus_active': False}
        
        # 分布式共识过程
        consensus_results = {}
        total_byzantine_detected = 0
        total_consensus_rounds = 0
        
        # 每个智能体独立进行局部共识
        for agent in active_agents:
            try:
                # 执行共识学习
                neighbor_updates = self._collect_neighbor_updates(agent, active_agents)
                consensus_gradients, consensus_metrics = agent.local_ddrl.consensus_round(neighbor_updates)
                
                # 更新智能体性能指标
                agent.performance_metrics['consensus_participations'] += 1
                agent.performance_metrics['decisions_made'] += 1
                
                # 记录决策历史
                agent.decision_history.append({
                    'timestamp': time.time(),
                    'decision_type': 'consensus_learning',
                    'neighbors_involved': len(neighbor_updates),
                    'byzantine_detected': consensus_metrics.get('byzantine_detected', 0)
                })
                
                consensus_results[agent.agent_id] = consensus_metrics
                total_byzantine_detected += consensus_metrics.get('byzantine_detected', 0)
                total_consensus_rounds += 1
                
            except Exception as e:
                # 处理邻居不足的情况
                error_msg = str(e)
                if "Insufficient updates" in error_msg or "Byzantine tolerance" in error_msg:
                    # 这是正常的网络拓扑情况，不需要显示为错误
                    agent.performance_metrics['consensus_skipped'] = agent.performance_metrics.get('consensus_skipped', 0) + 1
                    
                    # 创建优雅降级的共识结果
                    consensus_results[agent.agent_id] = {
                        'success': False,
                        'reason': 'insufficient_neighbors',
                        'byzantine_detected': 0,
                        'degraded_mode': True
                    }
                else:
                    # 其他真正的错误才显示
                    print(f"Agent {agent.agent_id} consensus error: {e}")
                    consensus_results[agent.agent_id] = {
                        'success': False,
                        'reason': 'execution_error',
                        'error': str(e)
                    }
        
        # 汇总性能指标（用于显示）
        if total_consensus_rounds > 0:
            avg_success_rate = np.mean([
                result.get('success', False) for result in consensus_results.values()
            ])
            
            overall_metrics = {
                'consensus_rounds': total_consensus_rounds,
                'byzantine_detected_total': total_byzantine_detected,
                'success_rate': avg_success_rate,
                'active_agents': len(active_agents),
                'distributed_decisions': len(consensus_results)
            }
            
            self.performance_metrics['consensus_ddrl'] = overall_metrics
            
            return {
                'consensus_active': True,
                'consensus_rounds': total_consensus_rounds,
                'byzantine_detected': total_byzantine_detected,
                'success_rate': avg_success_rate,
                'distributed_agents': len(active_agents),
                'individual_results': consensus_results
            }
        
        return {'consensus_active': False}
    
    def _collect_neighbor_updates(self, agent: DistributedAgent, all_agents: List[DistributedAgent]):
        """收集邻居智能体的模型更新"""
        neighbor_updates = []
        
        # 获取邻居信息
        neighbors = agent.local_knowledge.get('network_state', {}).get('neighbors', [])
        neighbor_ids = [n['vehicle_id'] for n in neighbors]
        
        # 创建自己的模型更新
        self_gradients = {
            'layer1.weight': torch.randn(32, 16),
            'layer1.bias': torch.randn(32),
            'layer2.weight': torch.randn(16, 8),
            'layer2.bias': torch.randn(16)
        }
        
        self_update = agent.local_ddrl.create_model_update(
            local_gradients=self_gradients,
            loss_value=np.random.exponential(0.5)
        )
        neighbor_updates.append(self_update)
        
        # 收集邻居的模型更新
        for other_agent in all_agents:
            if (other_agent.vehicle_id in neighbor_ids and 
                other_agent.agent_id != agent.agent_id):
                
                # 模拟邻居的模型更新
                neighbor_gradients = {
                    'layer1.weight': torch.randn(32, 16),
                    'layer1.bias': torch.randn(32),
                    'layer2.weight': torch.randn(16, 8),
                    'layer2.bias': torch.randn(16)
                }
                
                # 偶尔添加拜占庭行为
                if random.random() < 0.1:  # 10%概率
                    for param_name in neighbor_gradients:
                        neighbor_gradients[param_name] *= 5.0  # 恶意放大
                
                neighbor_update = other_agent.local_ddrl.create_model_update(
                    local_gradients=neighbor_gradients,
                    loss_value=np.random.exponential(0.5)
                )
                neighbor_update.agent_id = other_agent.agent_id
                neighbor_updates.append(neighbor_update)
        
        return neighbor_updates
    
    def simulate_distributed_safety_control(self, vehicles):
        """分布式安全控制 - 每个智能体独立执行安全控制"""
        if not ENHANCED_FEATURES:
            return {'safety_active': False}
        
        safety_results = {}
        total_interventions = 0
        
        for vehicle in vehicles:
            vehicle_id = getattr(vehicle, 'vehicle_id', f'vehicle_{id(vehicle)}')
            if vehicle_id in self.distributed_agents:
                agent = self.distributed_agents[vehicle_id]
                
                # 获取邻居车辆状态
                neighbor_states = self._get_neighbor_vehicle_states(agent, vehicles)
                
                if neighbor_states:
                    try:
                        # 执行分布式DMPC优化
                        current_state = self._get_vehicle_state(vehicle)
                        reference_trajectory = self._generate_reference_trajectory(current_state)
                        neighbor_predictions = {}  # 简化实现
                        
                        optimal_control, control_info = agent.local_dmpc.solve_distributed_mpc(
                            current_state=current_state,
                            reference_trajectory=reference_trajectory,
                            neighbor_states=neighbor_states,
                            neighbor_predictions=neighbor_predictions
                        )
                        
                        # 安全性检查和HOCBF控制
                        if control_info['solver_success']:
                            # 应用HOCBF安全约束
                            # 构建状态向量
                            heading = getattr(vehicle, 'heading', np.arctan2(vehicle.velocity[1], vehicle.velocity[0]))
                            speed = np.linalg.norm(vehicle.velocity)
                            current_state_vec = np.array([
                                vehicle.position[0], 
                                vehicle.position[1], 
                                speed, 
                                heading
                            ])
                            
                            # 创建HOCBFVehicleState对象用于HOCBF
                            ego_state = HOCBFVehicleState(
                                position=vehicle.position,
                                velocity=vehicle.velocity,
                                acceleration=np.array([vehicle.acceleration, 0.0]),
                                heading=heading,
                                timestamp=time.time()
                            )
                            
                            # 获取邻居状态列表
                            neighbor_vehicle_states = []
                            for ns in neighbor_states:
                                neighbor_vehicle_states.append(HOCBFVehicleState(
                                    position=ns.position,
                                    velocity=ns.velocity,
                                    acceleration=ns.acceleration,
                                    heading=ns.heading,
                                    timestamp=ns.timestamp
                                ))
                            
                            safe_control_value, safe_control_info = agent.local_hocbf.solve_safety_qp(
                                ego_state=ego_state,
                                desired_control=optimal_control,
                                neighbor_states=neighbor_vehicle_states
                            )
                            safe_control = {'control': safe_control_value}
                            
                            # 检查是否需要安全干预
                            control_norm = np.linalg.norm(optimal_control - safe_control['control'])
                            if control_norm > 0.1:
                                agent.performance_metrics['safety_interventions'] += 1
                                total_interventions += 1
                            
                            # 记录决策
                            agent.decision_history.append({
                                'timestamp': time.time(),
                                'decision_type': 'safety_control',
                                'intervention_needed': control_norm > 0.1,
                                'solver_time': control_info['solve_time']
                            })
                            
                            safety_results[agent.agent_id] = {
                                'success': True,
                                'solve_time': control_info['solve_time'],
                                'intervention': control_norm > 0.1
                            }
                            
                    except Exception as e:
                        print(f"Agent {agent.agent_id} safety control error: {e}")
                        safety_results[agent.agent_id] = {
                            'success': False,
                            'error': str(e)
                        }
        
        # 汇总安全控制指标
        if safety_results:
            success_rate = sum(1 for r in safety_results.values() if r.get('success', False)) / len(safety_results)
            avg_solve_time = np.mean([
                r.get('solve_time', 0) for r in safety_results.values() if r.get('success', False)
            ])
            
            self.performance_metrics['hocbf_safety'] = {
                'success_rate': success_rate,
                'average_solve_time_ms': avg_solve_time * 1000,
                'total_interventions': total_interventions,
                'active_controllers': len(safety_results)
            }
            
            return {
                'safety_active': True,
                'success_rate': success_rate,
                'interventions': total_interventions,
                'distributed_controllers': len(safety_results)
            }
        
        return {'safety_active': False}
    
    def _get_neighbor_vehicle_states(self, agent: DistributedAgent, all_vehicles):
        """获取邻居车辆状态"""
        neighbors = agent.local_knowledge.get('network_state', {}).get('neighbors', [])
        neighbor_ids = [n['vehicle_id'] for n in neighbors]
        
        neighbor_states = []
        for vehicle in all_vehicles:
            vehicle_id = getattr(vehicle, 'vehicle_id', f'vehicle_{id(vehicle)}')
            if vehicle_id in neighbor_ids:
                state = self._get_vehicle_state(vehicle)
                neighbor_states.append(state)
        
        return neighbor_states
    
    def _get_vehicle_state(self, vehicle) -> VehicleState:
        """将车辆转换为VehicleState对象"""
        return VehicleState(
            position=vehicle.position,
            velocity=vehicle.velocity,
            acceleration=np.array([vehicle.acceleration, 0.0]),  # 使用实际加速度
            heading=getattr(vehicle, 'heading', np.arctan2(vehicle.velocity[1], vehicle.velocity[0])),
            yaw_rate=0.0,  # 简化
            timestamp=time.time()
        )
    
    def _generate_reference_trajectory(self, current_state: VehicleState):
        """生成参考轨迹"""
        trajectory = []
        dt = 0.1
        for i in range(8):  # 8步预测
            # 简单的直线轨迹
            future_pos = current_state.position + current_state.velocity * dt * (i + 1)
            future_state = VehicleState(
                position=future_pos,
                velocity=current_state.velocity,
                acceleration=np.array([0.0, 0.0]),
                heading=current_state.heading,
                yaw_rate=0.0,
                timestamp=current_state.timestamp + dt * (i + 1)
            )
            trajectory.append(future_state)
        return trajectory
    
    def simulate_distributed_multimodal_fusion(self, vehicles):
        """分布式多模态传感器融合 - 每个智能体独立融合多种传感器数据"""
        if not ENHANCED_FEATURES:
            return {'fusion_active': False}
        
        fusion_results = {}
        total_sensors_fused = 0
        
        for vehicle in vehicles:
            vehicle_id = getattr(vehicle, 'vehicle_id', f'vehicle_{id(vehicle)}')
            if vehicle_id in self.distributed_agents:
                agent = self.distributed_agents[vehicle_id]
                
                try:
                    # 收集本地传感器数据
                    sensor_data = vehicle.get_sensor_data(self.sim_manager.entities)
                    
                    # 创建标准的SensorData对象列表
                    sensor_inputs = []
                    
                    # 模拟摄像头数据
                    if vehicle.sensors.get('camera_fpv', {}).get('available', False):
                        camera_data = torch.randn(1, 3, 64, 64)  # (B, C, H, W)
                        sensor_inputs.append(SensorData(
                            modality=SensorModality.CAMERA_RGB,
                            data=camera_data,
                            timestamp=time.time(),
                            confidence=0.9,
                            spatial_resolution=(0.1, 0.1),
                            sensor_id="camera_fpv"
                        ))
                    
                    # 模拟LiDAR数据
                    if vehicle.sensors.get('lidar', {}).get('available', False):
                        lidar_data = torch.randn(1, 256, 3)  # (B, N_points, 3)
                        sensor_inputs.append(SensorData(
                            modality=SensorModality.LIDAR_POINT_CLOUD,
                            data=lidar_data,
                            timestamp=time.time(),
                            confidence=0.95,
                            spatial_resolution=(0.05, 0.05),
                            sensor_id="lidar_main"
                        ))
                    
                    # 模拟雷达数据
                    if vehicle.sensors.get('radar', {}).get('available', True):
                        radar_data = torch.randn(1, 1, 32, 32)  # (B, C, H, W)
                        sensor_inputs.append(SensorData(
                            modality=SensorModality.RADAR_DOPPLER,
                            data=radar_data,
                            timestamp=time.time(),
                            confidence=0.8,
                            spatial_resolution=(0.5, 0.5),
                            sensor_id="radar_front"
                        ))
                    
                    # 进行多模态融合
                    if sensor_inputs:
                        fused_features, fusion_metrics = agent.local_fusion(sensor_inputs)
                    else:
                        # 没有可用传感器，创建零特征
                        fused_features = torch.zeros(1, agent.local_fusion.output_dim)
                        fusion_metrics = {'fusion_quality': 0.0, 'active_modalities': 0}
                    
                    # 统计传感器融合效果
                    available_sensors = len(sensor_inputs)
                    fusion_quality = fusion_metrics.get('fusion_quality', 0.0)
                    
                    # 记录决策历史
                    agent.decision_history.append({
                        'timestamp': time.time(),
                        'decision_type': 'multimodal_fusion',
                        'sensors_count': available_sensors,
                        'fusion_quality': fusion_quality
                    })
                    
                    fusion_results[agent.agent_id] = {
                        'success': True,
                        'sensors_count': available_sensors,
                        'fusion_quality': fusion_quality,
                        'feature_dim': fused_features.shape[-1],
                        'modalities': len(sensor_inputs)
                    }
                    
                    total_sensors_fused += available_sensors
                    
                except Exception as e:
                    print(f"Agent {agent.agent_id} fusion error: {e}")
                    fusion_results[agent.agent_id] = {
                        'success': False,
                        'error': str(e)
                    }
        
        # 汇总多模态融合指标
        if fusion_results:
            success_rate = sum(1 for r in fusion_results.values() if r.get('success', False)) / len(fusion_results)
            avg_quality = np.mean([
                r.get('fusion_quality', 0) for r in fusion_results.values() if r.get('success', False)
            ])
            avg_sensors = np.mean([
                r.get('sensors_count', 0) for r in fusion_results.values() if r.get('success', False)
            ])
            
            self.performance_metrics['multimodal_fusion'] = {
                'success_rate': success_rate,
                'average_quality': avg_quality,
                'average_sensors': avg_sensors,
                'total_fusions': len(fusion_results),
                'total_sensors_active': total_sensors_fused
            }
            
            return {
                'fusion_active': True,
                'success_rate': success_rate,
                'average_quality': avg_quality,
                'distributed_fusion_units': len(fusion_results)
            }
        
        return {'fusion_active': False}
    
    def update_distributed_features(self):
        """更新所有分布式功能"""
        vehicles = [e for e in self.sim_manager.entities if hasattr(e, 'velocity')]
        
        # 为新车辆创建分布式智能体
        for vehicle in vehicles:
            vehicle_id = getattr(vehicle, 'vehicle_id', f'vehicle_{id(vehicle)}')
            setattr(vehicle, 'vehicle_id', vehicle_id)  # 确保有ID
            if vehicle_id not in self.distributed_agents:
                self.create_distributed_agent(vehicle_id)
        
        if ENHANCED_FEATURES:
            # 1. 更新分布式6G网络
            network_info = self.simulate_distributed_6g_network(vehicles)
            
            # 2. 分布式共识学习
            consensus_info = self.simulate_distributed_consensus_learning(vehicles)
            
            # 3. 分布式安全控制
            safety_info = self.simulate_distributed_safety_control(vehicles)
            
            # 4. 分布式多模态传感器融合
            fusion_info = self.simulate_distributed_multimodal_fusion(vehicles)
            
            # 5. 更新分布式协调指标
            self.distributed_coordinator['consensus_rounds'] += 1
            self.performance_metrics['distributed_coordination'] = {
                'active_agents': len(self.distributed_agents),
                'coordination_rounds': self.distributed_coordinator['consensus_rounds'],
                'total_decisions': sum(agent.performance_metrics['decisions_made'] 
                                     for agent in self.distributed_agents.values()),
                'total_communications': sum(agent.performance_metrics['communication_events'] 
                                          for agent in self.distributed_agents.values())
            }
            
            return {
                'network_6g': network_info,
                'consensus_ddrl': consensus_info,
                'safety_control': safety_info,
                'multimodal_fusion': fusion_info,
                'distributed_coordination': self.performance_metrics['distributed_coordination']
            }
        else:
            return {'enhanced_features': False}
    
    def render_enhanced_metrics(self):
        """渲染增强指标显示（与集中式版本相同的UI）"""
        # 指标面板位置（与原版完全相同）
        y_offset = Config.HEIGHT // 2 + 50
        x_offset = Config.WIDTH - 420
        panel_width = 410
        
        # 背景面板
        panel_surface = pygame.Surface((panel_width, Config.HEIGHT // 2 - 60))
        panel_surface.set_alpha(200)
        panel_surface.fill((20, 20, 40))
        self.screen.blit(panel_surface, (x_offset, y_offset))
        
        # 标题
        title = self.title_font.render("🚗 分布式CoRo-DDRL指标", True, (255, 255, 100))
        self.screen.blit(title, (x_offset + 10, y_offset + 10))
        y_offset += 35
        
        # 系统概览
        if ENHANCED_FEATURES:
            status_text = f"⚡ 所有分布式功能: 激活"
            status_color = (0, 255, 0)
        else:
            status_text = f"⚠️ 仅基础功能"
            status_color = (255, 255, 0)
        
        status_surface = self.font.render(status_text, True, status_color)
        self.screen.blit(status_surface, (x_offset + 10, y_offset))
        y_offset += 30
        
        # 分布式智能体状态
        if ENHANCED_FEATURES:
            agent_count = len(self.distributed_agents)
            agent_text = f"🤖 活跃分布式智能体: {agent_count}"
            agent_surface = self.font.render(agent_text, True, (100, 255, 100))
            self.screen.blit(agent_surface, (x_offset + 10, y_offset))
            y_offset += 25
            
            # 6G网络状态
            network_metrics = self.performance_metrics.get('network_6g', {})
            if network_metrics:
                net_text = f"📡 6G网络: uRLLC {network_metrics.get('urllc_latency', 0):.1f}ms"
                net_surface = self.small_font.render(net_text, True, (150, 200, 255))
                self.screen.blit(net_surface, (x_offset + 15, y_offset))
                y_offset += 20
                
                bw_text = f"    eMBB {network_metrics.get('embb_bandwidth', 0):.1f}Gbps"
                bw_surface = self.small_font.render(bw_text, True, (150, 200, 255))
                self.screen.blit(bw_surface, (x_offset + 15, y_offset))
                y_offset += 25
            
            # 分布式共识学习
            consensus_metrics = self.performance_metrics.get('consensus_ddrl', {})
            if consensus_metrics:
                rounds = consensus_metrics.get('consensus_rounds', 0)
                byzantine = consensus_metrics.get('byzantine_detected_total', 0)
                success = consensus_metrics.get('success_rate', 0) * 100
                
                consensus_text = f"🛡️ 分布式CoRo-DDRL: {rounds}轮"
                consensus_surface = self.small_font.render(consensus_text, True, (255, 200, 100))
                self.screen.blit(consensus_surface, (x_offset + 15, y_offset))
                y_offset += 20
                
                byz_text = f"    拜占庭检测: {byzantine}, 成功率: {success:.1f}%"
                byz_surface = self.small_font.render(byz_text, True, (255, 150, 150))
                self.screen.blit(byz_surface, (x_offset + 15, y_offset))
                y_offset += 25
            
            # 分布式安全控制
            safety_metrics = self.performance_metrics.get('hocbf_safety', {})
            if safety_metrics:
                success_rate = safety_metrics.get('success_rate', 0) * 100
                solve_time = safety_metrics.get('average_solve_time_ms', 0)
                interventions = safety_metrics.get('total_interventions', 0)
                
                safety_text = f"⚡ 分布式安全控制: {success_rate:.1f}%"
                safety_surface = self.small_font.render(safety_text, True, (100, 255, 150))
                self.screen.blit(safety_surface, (x_offset + 15, y_offset))
                y_offset += 20
                
                time_text = f"    求解时间: {solve_time:.1f}ms, 干预: {interventions}"
                time_surface = self.small_font.render(time_text, True, (150, 255, 150))
                self.screen.blit(time_surface, (x_offset + 15, y_offset))
                y_offset += 25
            
            # 分布式多模态融合
            fusion_metrics = self.performance_metrics.get('multimodal_fusion', {})
            if fusion_metrics:
                success_rate = fusion_metrics.get('success_rate', 0) * 100
                avg_quality = fusion_metrics.get('average_quality', 0) * 100
                total_fusions = fusion_metrics.get('total_fusions', 0)
                
                fusion_text = f"🔗 分布式FDL-GNN融合: {success_rate:.1f}%"
                fusion_surface = self.small_font.render(fusion_text, True, (255, 180, 100))
                self.screen.blit(fusion_surface, (x_offset + 15, y_offset))
                y_offset += 20
                
                quality_text = f"    融合质量: {avg_quality:.1f}%, 融合单元: {total_fusions}"
                quality_surface = self.small_font.render(quality_text, True, (255, 160, 80))
                self.screen.blit(quality_surface, (x_offset + 15, y_offset))
                y_offset += 25
            
            # 分布式协调状态
            coord_metrics = self.performance_metrics.get('distributed_coordination', {})
            if coord_metrics:
                decisions = coord_metrics.get('total_decisions', 0)
                comms = coord_metrics.get('total_communications', 0)
                
                coord_text = f"🔄 分布式协调: {decisions}决策"
                coord_surface = self.small_font.render(coord_text, True, (200, 150, 255))
                self.screen.blit(coord_surface, (x_offset + 15, y_offset))
                y_offset += 20
                
                comm_text = f"    通信事件: {comms}"
                comm_surface = self.small_font.render(comm_text, True, (180, 130, 255))
                self.screen.blit(comm_surface, (x_offset + 15, y_offset))
                y_offset += 25
        
        # 系统性能（与原版相同）
        overall = self.performance_metrics['overall_system']
        fps_text = f"📊 系统性能: {overall.get('avg_fps', 0):.1f} FPS"
        fps_surface = self.small_font.render(fps_text, True, (200, 200, 200))
        self.screen.blit(fps_surface, (x_offset + 15, y_offset))
        y_offset += 20
        
        runtime = time.time() - overall['start_time']
        runtime_text = f"    运行时间: {runtime:.1f}s"
        runtime_surface = self.small_font.render(runtime_text, True, (180, 180, 180))
        self.screen.blit(runtime_surface, (x_offset + 15, y_offset))
    
    def step(self):
        """仿真步进（界面保持与原版相同）"""
        # 更新基础仿真
        self.sim_manager.step()
        
        # 更新分布式功能
        self.update_distributed_features()
        
        # 更新性能指标
        overall = self.performance_metrics['overall_system']
        overall['frame_count'] += 1
        current_time = time.time()
        runtime = current_time - overall['start_time']
        overall['total_runtime'] = runtime
        if runtime > 0:
            overall['avg_fps'] = overall['frame_count'] / runtime
    
    def render(self):
        """渲染（界面与原版完全相同）"""
        # 清屏
        self.screen.fill((20, 30, 40))
        
        # 渲染基础仿真
        self.sim_manager.renderer.render_frame(
            self.sim_manager.entities, 
            self.sim_manager.simulation_step,
            self.sim_manager.performance_metrics
        )
        
        # 渲染增强指标
        self.render_enhanced_metrics()
        
        # 更新显示
        pygame.display.flip()
    
    def handle_events(self):
        """事件处理（与原版完全相同）"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                elif event.key == pygame.K_SPACE:
                    self.sim_manager.add_vehicle()
                elif event.key == pygame.K_r:
                    self.sim_manager.reset()
                    # 重置分布式智能体
                    self.distributed_agents.clear()
                    self.agent_counter = 0
                    self.distributed_coordinator = self._create_distributed_coordinator()
                elif event.key == pygame.K_n:
                    print("🌐 分布式6G网络分析:")
                    for agent_id, agent in self.distributed_agents.items():
                        network_state = agent.local_knowledge.get('network_state', {})
                        print(f"   {agent_id}: {len(network_state.get('neighbors', []))} 邻居")
                elif event.key == pygame.K_c:
                    print("🛡️ 分布式共识指标:")
                    for agent_id, agent in self.distributed_agents.items():
                        metrics = agent.performance_metrics
                        print(f"   {agent_id}: {metrics['decisions_made']} 决策, {metrics['consensus_participations']} 共识参与")
        
        return True

def main():
    """主函数"""
    try:
        print("✅ 所有增强功能加载成功!")
        print("="*80)
        print("        分布式增强CoRo-DDRL框架 - 实时仿真")
        print("="*80)
        print("🚀 功能:")
        print("   ✅ 分布式6G网络建模 (uRLLC + eMBB)")
        print("   ✅ 分布式CoRo-DDRL保护学习")
        print("   ✅ 分布式HOCBF-QP安全控制")
        print("   ✅ 分布式FDL-GNN传感器融合")
        print("   ✅ 分布式拜占庭故障检测")
        print("   ✅ 分布式网络感知策略适应")
        print()
        print("🎮 控制:")
        print("   SPACE: 添加车辆    R: 重置    ESC: 退出")
        print("   N: 网络分析   C: 共识指标")
        print("="*80)
        
        # 初始化Pygame
        pygame.init()
        screen = pygame.display.set_mode((Config.WIDTH, Config.HEIGHT))
        pygame.display.set_caption("分布式增强CoRo-DDRL框架")
        clock = pygame.time.Clock()
        
        # 创建分布式仿真
        distributed_sim = DistributedCTLCSimulation(screen)
        
        # 主循环
        running = True
        while running:
            # 处理事件
            running = distributed_sim.handle_events()
            
            # 仿真步进
            distributed_sim.step()
            
            # 渲染
            distributed_sim.render()
            
            # 控制帧率
            clock.tick(60)
        
    except KeyboardInterrupt:
        print("\n⚠️ 用户中断仿真")
    except Exception as e:
        print(f"❌ 仿真错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        pygame.quit()
        print("🏁 分布式增强CoRo-DDRL框架仿真完成!")
        print("📊 所有分布式功能演示成功!")

if __name__ == "__main__":
    main() 