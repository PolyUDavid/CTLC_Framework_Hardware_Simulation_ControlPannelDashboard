#!/usr/bin/env python3
"""
CP-DDRL 实验仪表盘启动器
简化版 - 演示实验流程和界面
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import time
import threading
import queue
import random
import json
import os
from datetime import datetime
from typing import Dict, List, Any

class SimpleExperimentDashboard:
    """简化版实验仪表盘 - 演示用"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("CP-DDRL 自动化实验仪表盘 (演示版)")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')
        
        # 实验状态
        self.experiment_running = False
        self.progress_queue = queue.Queue()
        self.experiment_data = {
            'baseline_collision_rate': 0,
            'distributed_collision_rate': 0,
            'baseline_avg_speed': 0,
            'distributed_avg_speed': 0,
            'communication_delay': 0,
            'consensus_convergence': 0
        }
        
        self.setup_ui()
        
    def setup_ui(self):
        """设置用户界面"""
        
        # 标题栏
        title_frame = tk.Frame(self.root, bg='#2c3e50', height=70)
        title_frame.pack(fill='x', padx=5, pady=5)
        title_frame.pack_propagate(False)
        
        title_label = tk.Label(title_frame, 
                              text="🚗 CP-DDRL 分布式仿真实验平台 (演示版)", 
                              font=('Arial', 18, 'bold'),
                              fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        # 主框架
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        # 左侧控制面板
        self.setup_control_panel(main_frame)
        
        # 右侧监控面板
        self.setup_monitoring_panel(main_frame)
        
    def setup_control_panel(self, parent):
        """设置控制面板"""
        control_frame = tk.Frame(parent, bg='white', relief='raised', bd=2)
        control_frame.pack(side='left', fill='y', padx=(0, 5))
        control_frame.configure(width=300)
        control_frame.pack_propagate(False)
        
        # 标题
        tk.Label(control_frame, text="🎛️ 实验控制", 
                font=('Arial', 14, 'bold'), bg='white').pack(pady=10)
        
        # 实验类型选择
        exp_frame = tk.LabelFrame(control_frame, text="实验类型", bg='white')
        exp_frame.pack(fill='x', padx=10, pady=5)
        
        self.exp_type = tk.StringVar(value="quick")
        tk.Radiobutton(exp_frame, text="快速对比 (2分钟)", 
                      variable=self.exp_type, value="quick", bg='white').pack(anchor='w')
        tk.Radiobutton(exp_frame, text="完整仿真 (演示版)", 
                      variable=self.exp_type, value="demo", bg='white').pack(anchor='w')
        
        # 参数设置
        param_frame = tk.LabelFrame(control_frame, text="仿真参数", bg='white')
        param_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Label(param_frame, text="车辆数量:", bg='white').pack(anchor='w')
        self.vehicle_count = tk.Scale(param_frame, from_=5, to=20, 
                                    orient='horizontal', bg='white')
        self.vehicle_count.set(10)
        self.vehicle_count.pack(fill='x')
        
        tk.Label(param_frame, text="仿真时长:", bg='white').pack(anchor='w')
        self.sim_duration = tk.Scale(param_frame, from_=30, to=300, 
                                   orient='horizontal', bg='white')
        self.sim_duration.set(120)
        self.sim_duration.pack(fill='x')
        
        # 控制按钮
        button_frame = tk.Frame(control_frame, bg='white')
        button_frame.pack(fill='x', padx=10, pady=20)
        
        self.start_btn = tk.Button(button_frame, text="🚀 开始实验", 
                                 command=self.start_experiment,
                                 bg='#27ae60', fg='white', 
                                 font=('Arial', 12, 'bold'), height=2)
        self.start_btn.pack(fill='x', pady=2)
        
        self.stop_btn = tk.Button(button_frame, text="⏹️ 停止实验", 
                                command=self.stop_experiment,
                                bg='#e74c3c', fg='white', 
                                font=('Arial', 12, 'bold'), height=2,
                                state='disabled')
        self.stop_btn.pack(fill='x', pady=2)
        
        self.reset_btn = tk.Button(button_frame, text="🔄 重置", 
                                 command=self.reset_experiment,
                                 bg='#f39c12', fg='white', 
                                 font=('Arial', 12, 'bold'), height=2)
        self.reset_btn.pack(fill='x', pady=2)
        
        # 日志显示
        log_frame = tk.LabelFrame(control_frame, text="实验日志", bg='white')
        log_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=12, 
                                                wrap=tk.WORD, bg='#f8f9fa')
        self.log_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        self.log("🔥 实验仪表盘已启动")
        self.log("💡 选择实验类型并点击开始实验")
        
    def setup_monitoring_panel(self, parent):
        """设置监控面板"""
        monitor_frame = tk.Frame(parent, bg='white', relief='raised', bd=2)
        monitor_frame.pack(side='right', fill='both', expand=True)
        
        # 监控标题
        tk.Label(monitor_frame, text="📊 实时监控面板", 
                font=('Arial', 14, 'bold'), bg='white').pack(pady=10)
        
        # 创建选项卡
        notebook = ttk.Notebook(monitor_frame)
        notebook.pack(fill='both', expand=True, padx=10, pady=5)
        
        # 实验概览选项卡
        self.create_overview_tab(notebook)
        
        # 性能对比选项卡
        self.create_performance_tab(notebook)
        
        # 网络状态选项卡
        self.create_network_tab(notebook)
        
    def create_overview_tab(self, notebook):
        """创建概览选项卡"""
        overview_frame = ttk.Frame(notebook)
        notebook.add(overview_frame, text="🎯 实验概览")
        
        # 进度显示
        progress_frame = tk.Frame(overview_frame, bg='white')
        progress_frame.pack(fill='x', padx=20, pady=20)
        
        tk.Label(progress_frame, text="实验进度:", 
                font=('Arial', 12, 'bold'), bg='white').pack(anchor='w')
        self.progress_bar = ttk.Progressbar(progress_frame, length=500, mode='determinate')
        self.progress_bar.pack(fill='x', pady=10)
        
        self.progress_label = tk.Label(progress_frame, text="等待开始", 
                                     font=('Arial', 10), bg='white')
        self.progress_label.pack(anchor='w')
        
        # 关键指标卡片
        metrics_frame = tk.Frame(overview_frame, bg='white')
        metrics_frame.pack(fill='both', expand=True, padx=20, pady=10)
        
        # 第一行指标
        row1 = tk.Frame(metrics_frame, bg='white')
        row1.pack(fill='x', pady=5)
        
        self.collision_card = self.create_metric_card(row1, "🚨 碰撞率改善", "等待数据", "#e74c3c")
        self.speed_card = self.create_metric_card(row1, "🏃 速度提升", "等待数据", "#3498db")
        
        # 第二行指标
        row2 = tk.Frame(metrics_frame, bg='white')
        row2.pack(fill='x', pady=5)
        
        self.delay_card = self.create_metric_card(row2, "📡 通信延迟", "等待数据", "#f39c12")
        self.consensus_card = self.create_metric_card(row2, "🤝 共识效率", "等待数据", "#27ae60")
        
    def create_metric_card(self, parent, title, value, color):
        """创建指标卡片"""
        card = tk.Frame(parent, bg=color, relief='raised', bd=3)
        card.pack(side='left', fill='both', expand=True, padx=5)
        
        tk.Label(card, text=title, font=('Arial', 10, 'bold'), 
                fg='white', bg=color).pack(pady=(10, 5))
        
        value_label = tk.Label(card, text=value, font=('Arial', 14, 'bold'), 
                             fg='white', bg=color)
        value_label.pack(pady=(0, 10))
        
        return value_label
        
    def create_performance_tab(self, notebook):
        """创建性能对比选项卡"""
        perf_frame = ttk.Frame(notebook)
        notebook.add(perf_frame, text="📈 性能对比")
        
        # 模拟的性能对比表格
        tk.Label(perf_frame, text="基线 vs 分布式系统性能对比", 
                font=('Arial', 14, 'bold')).pack(pady=20)
        
        # 创建对比表格
        columns = ('指标', '基线系统', '分布式系统', '改善幅度')
        self.perf_tree = ttk.Treeview(perf_frame, columns=columns, show='headings', height=10)
        
        for col in columns:
            self.perf_tree.heading(col, text=col)
            self.perf_tree.column(col, width=150, anchor='center')
            
        self.perf_tree.pack(fill='both', expand=True, padx=20, pady=10)
        
        # 初始化表格数据
        self.update_performance_table(demo_mode=True)
        
    def create_network_tab(self, notebook):
        """创建网络状态选项卡"""
        network_frame = ttk.Frame(notebook)
        notebook.add(network_frame, text="🌐 网络状态")
        
        tk.Label(network_frame, text="6G网络条件监控", 
                font=('Arial', 14, 'bold')).pack(pady=20)
        
        # 网络状态显示
        status_frame = tk.Frame(network_frame)
        status_frame.pack(fill='both', expand=True, padx=20, pady=10)
        
        # uRLLC状态
        urllc_frame = tk.LabelFrame(status_frame, text="uRLLC (超可靠低延迟)")
        urllc_frame.pack(fill='x', pady=5)
        
        self.urllc_latency = tk.Label(urllc_frame, text="延迟: 3.2ms", font=('Arial', 12))
        self.urllc_latency.pack(pady=5)
        
        self.urllc_reliability = tk.Label(urllc_frame, text="可靠性: 99.999%", font=('Arial', 12))
        self.urllc_reliability.pack(pady=5)
        
        # eMBB状态
        embb_frame = tk.LabelFrame(status_frame, text="eMBB (增强移动宽带)")
        embb_frame.pack(fill='x', pady=5)
        
        self.embb_throughput = tk.Label(embb_frame, text="吞吐量: 2.8 Gbps", font=('Arial', 12))
        self.embb_throughput.pack(pady=5)
        
        self.embb_bandwidth = tk.Label(embb_frame, text="带宽利用率: 78%", font=('Arial', 12))
        self.embb_bandwidth.pack(pady=5)
        
    def log(self, message):
        """添加日志消息"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_msg = f"[{timestamp}] {message}\n"
        self.log_text.insert(tk.END, formatted_msg)
        self.log_text.see(tk.END)
        self.root.update_idletasks()
        
    def start_experiment(self):
        """开始实验"""
        if self.experiment_running:
            return
            
        self.experiment_running = True
        self.start_btn.config(state='disabled')
        self.stop_btn.config(state='normal')
        
        exp_type = self.exp_type.get()
        vehicles = self.vehicle_count.get()
        duration = self.sim_duration.get()
        
        self.log(f"🚀 开始{exp_type}实验")
        self.log(f"📋 参数: {vehicles}辆车，{duration}秒")
        
        # 重置进度
        self.progress_bar['value'] = 0
        self.progress_label.config(text="初始化...")
        
        # 启动实验线程
        exp_thread = threading.Thread(target=self.run_experiment_demo, 
                                     args=(exp_type, duration))
        exp_thread.daemon = True
        exp_thread.start()
        
        # 启动进度更新
        self.update_progress()
        
    def run_experiment_demo(self, exp_type, duration):
        """运行演示实验"""
        try:
            if exp_type == "quick":
                self.run_quick_demo(duration)
            else:
                self.run_full_demo(duration)
        except Exception as e:
            self.progress_queue.put(('error', str(e)))
        finally:
            self.progress_queue.put(('complete', None))
            
    def run_quick_demo(self, duration):
        """运行快速演示"""
        steps = int(duration / 4)  # 每个阶段的时间
        
        # 阶段1: 基线测试
        self.progress_queue.put(('progress', 25, "运行基线系统测试..."))
        time.sleep(steps * 0.01)  # 加速演示
        
        # 模拟基线结果
        self.experiment_data['baseline_collision_rate'] = random.uniform(2.0, 3.5)
        self.experiment_data['baseline_avg_speed'] = random.uniform(15, 25)
        
        # 阶段2: 分布式测试
        self.progress_queue.put(('progress', 50, "运行分布式系统测试..."))
        time.sleep(steps * 0.01)
        
        # 模拟分布式结果（更好的性能）
        self.experiment_data['distributed_collision_rate'] = self.experiment_data['baseline_collision_rate'] * 0.4
        self.experiment_data['distributed_avg_speed'] = self.experiment_data['baseline_avg_speed'] * 1.25
        
        # 阶段3: 网络性能测试
        self.progress_queue.put(('progress', 75, "测试6G网络性能..."))
        time.sleep(steps * 0.01)
        
        self.experiment_data['communication_delay'] = random.uniform(2, 5)
        self.experiment_data['consensus_convergence'] = random.uniform(85, 95)
        
        # 阶段4: 结果分析
        self.progress_queue.put(('progress', 100, "分析结果并生成报告..."))
        time.sleep(steps * 0.01)
        
    def run_full_demo(self, duration):
        """运行完整演示"""
        phases = [
            ("初始化分布式系统", 10),
            ("载入预训练模型", 20),
            ("建立V2V通信网络", 35),
            ("配置6G网络切片", 50),
            ("运行安全性测试", 65),
            ("执行性能基准测试", 80),
            ("分析共识算法效果", 90),
            ("生成完整报告", 100)
        ]
        
        for phase_name, progress in phases:
            self.progress_queue.put(('progress', progress, phase_name))
            time.sleep(duration * 0.01)  # 加速演示
            
        # 生成随机但合理的实验数据
        self.experiment_data.update({
            'baseline_collision_rate': random.uniform(2.5, 4.0),
            'distributed_collision_rate': random.uniform(0.5, 1.5),
            'baseline_avg_speed': random.uniform(18, 28),
            'distributed_avg_speed': random.uniform(25, 35),
            'communication_delay': random.uniform(3, 8),
            'consensus_convergence': random.uniform(88, 98)
        })
        
    def update_progress(self):
        """更新进度显示"""
        try:
            while True:
                msg_type, data, *extra = self.progress_queue.get_nowait()
                
                if msg_type == 'progress':
                    progress, message = data, extra[0] if extra else ""
                    self.progress_bar['value'] = progress
                    self.progress_label.config(text=message)
                    self.log(f"📊 {message} ({progress}%)")
                    
                    # 实时更新指标
                    self.update_metrics_realtime(progress)
                    
                elif msg_type == 'error':
                    self.log(f"❌ 错误: {data}")
                    self.stop_experiment()
                    return
                    
                elif msg_type == 'complete':
                    self.log("✅ 实验完成!")
                    self.experiment_running = False
                    self.start_btn.config(state='normal')
                    self.stop_btn.config(state='disabled')
                    self.update_final_results()
                    return
                    
        except queue.Empty:
            pass
            
        if self.experiment_running:
            self.root.after(100, self.update_progress)
            
    def update_metrics_realtime(self, progress):
        """实时更新指标显示"""
        if progress > 50 and self.experiment_data['distributed_collision_rate'] > 0:
            # 碰撞率改善
            improvement = ((self.experiment_data['baseline_collision_rate'] - 
                          self.experiment_data['distributed_collision_rate']) / 
                         self.experiment_data['baseline_collision_rate'] * 100)
            self.collision_card.config(text=f"{improvement:.1f}% ↓")
            
            # 速度提升
            speed_improvement = ((self.experiment_data['distributed_avg_speed'] - 
                                self.experiment_data['baseline_avg_speed']) / 
                               self.experiment_data['baseline_avg_speed'] * 100)
            self.speed_card.config(text=f"{speed_improvement:.1f}% ↑")
            
        if progress > 75:
            # 通信延迟
            self.delay_card.config(text=f"{self.experiment_data['communication_delay']:.1f} ms")
            
            # 共识效率
            self.consensus_card.config(text=f"{self.experiment_data['consensus_convergence']:.1f}%")
            
    def update_final_results(self):
        """更新最终结果"""
        self.update_performance_table()
        self.update_network_status()
        
        # 显示结果摘要
        messagebox.showinfo("实验完成", 
                          f"实验成功完成!\n\n"
                          f"碰撞率降低: {((self.experiment_data['baseline_collision_rate'] - self.experiment_data['distributed_collision_rate']) / self.experiment_data['baseline_collision_rate'] * 100):.1f}%\n"
                          f"平均速度提升: {((self.experiment_data['distributed_avg_speed'] - self.experiment_data['baseline_avg_speed']) / self.experiment_data['baseline_avg_speed'] * 100):.1f}%\n"
                          f"共识收敛率: {self.experiment_data['consensus_convergence']:.1f}%")
        
    def update_performance_table(self, demo_mode=False):
        """更新性能对比表格"""
        # 清空现有数据
        for item in self.perf_tree.get_children():
            self.perf_tree.delete(item)
            
        if demo_mode:
            # 演示模式显示示例数据
            demo_data = [
                ("碰撞率 (%)", "2.8", "0.9", "67.9% ↓"),
                ("平均速度 (m/s)", "22.1", "28.4", "28.5% ↑"),
                ("燃料效率", "85.2%", "91.7%", "7.6% ↑"),
                ("通信延迟 (ms)", "15.3", "4.2", "72.5% ↓"),
                ("共识收敛率", "78.9%", "94.2%", "19.4% ↑")
            ]
        else:
            # 使用实际实验数据
            collision_improvement = ((self.experiment_data['baseline_collision_rate'] - 
                                    self.experiment_data['distributed_collision_rate']) / 
                                   self.experiment_data['baseline_collision_rate'] * 100)
            
            speed_improvement = ((self.experiment_data['distributed_avg_speed'] - 
                                self.experiment_data['baseline_avg_speed']) / 
                               self.experiment_data['baseline_avg_speed'] * 100)
            
            demo_data = [
                ("碰撞率 (%)", f"{self.experiment_data['baseline_collision_rate']:.1f}", 
                 f"{self.experiment_data['distributed_collision_rate']:.1f}", f"{collision_improvement:.1f}% ↓"),
                ("平均速度 (m/s)", f"{self.experiment_data['baseline_avg_speed']:.1f}", 
                 f"{self.experiment_data['distributed_avg_speed']:.1f}", f"{speed_improvement:.1f}% ↑"),
                ("通信延迟 (ms)", "12.8", f"{self.experiment_data['communication_delay']:.1f}", "68.4% ↓"),
                ("共识收敛率", "76.3%", f"{self.experiment_data['consensus_convergence']:.1f}%", "23.1% ↑")
            ]
        
        for data in demo_data:
            self.perf_tree.insert('', 'end', values=data)
            
    def update_network_status(self):
        """更新网络状态显示"""
        # 模拟网络状态更新
        self.urllc_latency.config(text=f"延迟: {self.experiment_data['communication_delay']:.1f}ms")
        self.urllc_reliability.config(text="可靠性: 99.999%")
        
        throughput = random.uniform(2.5, 3.2)
        bandwidth = random.uniform(70, 85)
        self.embb_throughput.config(text=f"吞吐量: {throughput:.1f} Gbps")
        self.embb_bandwidth.config(text=f"带宽利用率: {bandwidth:.0f}%")
        
    def stop_experiment(self):
        """停止实验"""
        self.experiment_running = False
        self.start_btn.config(state='normal')
        self.stop_btn.config(state='disabled')
        self.log("⏹️ 实验已停止")
        
    def reset_experiment(self):
        """重置实验"""
        self.stop_experiment()
        self.progress_bar['value'] = 0
        self.progress_label.config(text="等待开始")
        
        # 重置指标卡片
        self.collision_card.config(text="等待数据")
        self.speed_card.config(text="等待数据")
        self.delay_card.config(text="等待数据")
        self.consensus_card.config(text="等待数据")
        
        # 重置实验数据
        self.experiment_data = {k: 0 for k in self.experiment_data.keys()}
        
        self.log("🔄 实验已重置")
        
    def run(self):
        """运行仪表盘"""
        self.log("🌟 欢迎使用CP-DDRL实验仪表盘!")
        self.log("💡 这是演示版本，展示实验流程和界面")
        self.root.mainloop()

def main():
    """主函数"""
    print("🚀 启动CP-DDRL实验仪表盘(演示版)")
    
    # 检查依赖
    try:
        import tkinter
        print("✅ Tkinter 可用")
    except ImportError:
        print("❌ Tkinter 不可用，请安装 python3-tkinter")
        return
        
    try:
        dashboard = SimpleExperimentDashboard()
        dashboard.run()
    except Exception as e:
        print(f"❌ 启动失败: {e}")
        input("按Enter键退出...")

if __name__ == "__main__":
    main() 