#!/usr/bin/env python3
"""
Consensus-Protected Distributed Deep Reinforcement Learning (DDRL)
Implements Byzantine fault-tolerant learning with model update protection
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
import hashlib
import time
from collections import defaultdict

class AggregationMethod(Enum):
    TRIMMED_MEAN = "trimmed_mean"
    KRUM = "krum"
    BULYAN = "bulyan"
    COORDINATE_MEDIAN = "coordinate_median"

@dataclass
class ModelUpdate:
    """Structured model update with integrity protection"""
    agent_id: str
    gradients: Dict[str, torch.Tensor]
    loss_value: float
    timestamp: float
    signature: str  # Cryptographic integrity check
    trust_score: float = 1.0
    
class ByzantineDetector:
    """Byzantine attack detection and mitigation"""
    
    def __init__(self, threshold: float = 2.0, window_size: int = 10):
        self.threshold = threshold
        self.window_size = window_size
        self.agent_history = defaultdict(list)
        self.suspicion_scores = defaultdict(float)
        
    def detect_byzantine_behavior(self, updates: List[ModelUpdate]) -> List[str]:
        """Detect potentially Byzantine agents based on statistical analysis"""
        byzantine_agents = []
        
        if len(updates) < 3:
            return byzantine_agents
            
        # Calculate gradient norms for anomaly detection
        gradient_norms = []
        agent_ids = []
        
        for update in updates:
            total_norm = 0.0
            for param_name, grad in update.gradients.items():
                total_norm += torch.norm(grad).item() ** 2
            gradient_norms.append(np.sqrt(total_norm))
            agent_ids.append(update.agent_id)
            
        # Statistical outlier detection
        if len(gradient_norms) > 2:
            mean_norm = np.mean(gradient_norms)
            std_norm = np.std(gradient_norms)
            
            for i, (norm, agent_id) in enumerate(zip(gradient_norms, agent_ids)):
                z_score = abs(norm - mean_norm) / (std_norm + 1e-8)
                
                # Update suspicion score
                self.suspicion_scores[agent_id] = 0.9 * self.suspicion_scores[agent_id] + 0.1 * z_score
                
                # Mark as Byzantine if suspicion is high
                if self.suspicion_scores[agent_id] > self.threshold:
                    byzantine_agents.append(agent_id)
                    
        return byzantine_agents
        
    def update_trust_scores(self, updates: List[ModelUpdate], byzantine_agents: List[str]):
        """Update trust scores based on Byzantine detection"""
        for update in updates:
            if update.agent_id in byzantine_agents:
                update.trust_score = max(0.1, update.trust_score * 0.5)
            else:
                update.trust_score = min(1.0, update.trust_score * 1.1)

class SecureAggregator:
    """Byzantine-resilient aggregation algorithms"""
    
    def __init__(self, f_byzantine: int):
        self.f_byzantine = f_byzantine
        
    def trimmed_mean_aggregation(self, updates: List[ModelUpdate]) -> Dict[str, torch.Tensor]:
        """Coordinate-wise trimmed mean aggregation with graceful degradation"""
        if len(updates) == 0:
            raise ValueError("No updates available for aggregation")
            
        # 如果更新数量不足以进行拜占庭容错，则优雅降级
        if len(updates) <= 2 * self.f_byzantine:
            # 使用简单平均聚合而不是拜占庭容错
            print(f"Warning: Insufficient updates for Byzantine tolerance ({len(updates)} <= 2*{self.f_byzantine}), using simple averaging")
            return self._simple_averaging_fallback(updates)
            
        aggregated_params = {}
        
        # Get parameter names from first update
        param_names = list(updates[0].gradients.keys())
        
        for param_name in param_names:
            # Collect all gradients for this parameter
            param_updates = []
            weights = []
            
            for update in updates:
                if param_name in update.gradients:
                    param_updates.append(update.gradients[param_name])
                    weights.append(update.trust_score)
                    
            if not param_updates:
                continue
                
            # Stack tensors and flatten for coordinate-wise processing
            stacked_params = torch.stack(param_updates)  # [n_agents, param_shape]
            original_shape = stacked_params.shape[1:]
            flattened_params = stacked_params.flatten(1)  # [n_agents, n_coords]
            
            n_agents, n_coords = flattened_params.shape
            aggregated_coords = torch.zeros(n_coords, device=flattened_params.device)
            
            # Coordinate-wise trimmed mean
            for coord_idx in range(n_coords):
                coord_values = flattened_params[:, coord_idx]
                
                # Sort values and corresponding weights
                sorted_indices = torch.argsort(coord_values)
                sorted_values = coord_values[sorted_indices]
                sorted_weights = torch.tensor([weights[idx] for idx in sorted_indices], 
                                            device=coord_values.device)
                
                # Trim β smallest and β largest values
                if n_agents > 2 * self.f_byzantine:
                    trimmed_values = sorted_values[self.f_byzantine:-self.f_byzantine]
                    trimmed_weights = sorted_weights[self.f_byzantine:-self.f_byzantine]
                else:
                    trimmed_values = sorted_values
                    trimmed_weights = sorted_weights
                
                # Weighted average of trimmed values
                if len(trimmed_values) > 0:
                    weighted_sum = torch.sum(trimmed_values * trimmed_weights)
                    weight_sum = torch.sum(trimmed_weights)
                    aggregated_coords[coord_idx] = weighted_sum / (weight_sum + 1e-8)
                    
            # Reshape back to original parameter shape
            aggregated_params[param_name] = aggregated_coords.reshape(original_shape)
            
        return aggregated_params
    
    def _simple_averaging_fallback(self, updates: List[ModelUpdate]) -> Dict[str, torch.Tensor]:
        """Simple averaging fallback when Byzantine tolerance is not possible"""
        if not updates:
            return {}
            
        aggregated_params = {}
        param_names = list(updates[0].gradients.keys())
        
        for param_name in param_names:
            param_updates = []
            weights = []
            
            for update in updates:
                if param_name in update.gradients:
                    param_updates.append(update.gradients[param_name])
                    weights.append(update.trust_score)
            
            if param_updates:
                # Weighted average
                stacked_params = torch.stack(param_updates)
                weights_tensor = torch.tensor(weights, device=stacked_params.device)
                weights_tensor = weights_tensor / (weights_tensor.sum() + 1e-8)
                
                # Reshape weights for broadcasting
                while len(weights_tensor.shape) < len(stacked_params.shape):
                    weights_tensor = weights_tensor.unsqueeze(-1)
                
                aggregated_params[param_name] = torch.sum(stacked_params * weights_tensor, dim=0)
        
        return aggregated_params
        
    def krum_aggregation(self, updates: List[ModelUpdate], select_k: int = 1) -> Dict[str, torch.Tensor]:
        """Krum algorithm for Byzantine-resilient aggregation with graceful degradation"""
        n = len(updates)
        if n == 0:
            raise ValueError("No updates available for Krum aggregation")
            
        if n <= 2 * self.f_byzantine:
            print(f"Warning: Insufficient updates for Krum ({n} <= 2*{self.f_byzantine}), using simple selection")
            # Fallback: select update with highest trust score
            best_update = max(updates, key=lambda u: u.trust_score)
            return best_update.gradients
            
        # Calculate pairwise distances
        distances = torch.zeros(n, n)
        param_vectors = []
        
        # Flatten all parameters into vectors
        for update in updates:
            vector_parts = []
            for param_name in sorted(update.gradients.keys()):
                vector_parts.append(update.gradients[param_name].flatten())
            param_vectors.append(torch.cat(vector_parts))
            
        # Compute distance matrix
        for i in range(n):
            for j in range(i+1, n):
                dist = torch.norm(param_vectors[i] - param_vectors[j])
                distances[i, j] = dist
                distances[j, i] = dist
                
        # Find agent with minimum sum of distances to closest neighbors
        scores = torch.zeros(n)
        m = n - self.f_byzantine - 2  # Number of closest neighbors to consider
        
        for i in range(n):
            # Get distances to all other agents
            agent_distances = distances[i]
            # Sort and take m smallest distances (excluding self)
            sorted_distances, _ = torch.sort(agent_distances)
            scores[i] = torch.sum(sorted_distances[1:m+1])  # Exclude distance to self (0)
            
        # Select agent with minimum score
        selected_idx = torch.argmin(scores)
        selected_update = updates[selected_idx]
        
        return selected_update.gradients

class ConsensusProtectedDDRL:
    """Main consensus-protected DDRL coordinator"""
    
    def __init__(self, 
                 agent_id: str,
                 n_agents: int, 
                 f_byzantine: int,
                 aggregation_method: AggregationMethod = AggregationMethod.TRIMMED_MEAN,
                 learning_rate: float = 0.001):
        
        self.agent_id = agent_id
        self.n_agents = n_agents
        self.f_byzantine = f_byzantine
        self.aggregation_method = aggregation_method
        self.learning_rate = learning_rate
        
        # Validation
        if f_byzantine >= n_agents / 3:
            raise ValueError(f"Byzantine tolerance violated: f={f_byzantine} >= n/3={n_agents/3}")
            
        # Components
        self.byzantine_detector = ByzantineDetector()
        self.aggregator = SecureAggregator(f_byzantine)
        
        # Performance tracking
        self.consensus_rounds = 0
        self.byzantine_detected_count = 0
        self.consensus_success_rate = 0.0
        
        # Model state
        self.global_model = None
        self.local_model = None
        
    def create_model_update(self, local_gradients: Dict[str, torch.Tensor], 
                          loss_value: float) -> ModelUpdate:
        """Create a cryptographically signed model update"""
        
        # Create signature for integrity
        gradient_hash = self._compute_gradient_hash(local_gradients)
        signature = hashlib.sha256(
            f"{self.agent_id}_{gradient_hash}_{loss_value}_{time.time()}".encode()
        ).hexdigest()
        
        return ModelUpdate(
            agent_id=self.agent_id,
            gradients=local_gradients.copy(),
            loss_value=loss_value,
            timestamp=time.time(),
            signature=signature,
            trust_score=1.0
        )
        
    def _compute_gradient_hash(self, gradients: Dict[str, torch.Tensor]) -> str:
        """Compute hash of gradient tensors for integrity checking"""
        hash_input = ""
        for param_name in sorted(gradients.keys()):
            tensor_bytes = gradients[param_name].detach().cpu().numpy().tobytes()
            hash_input += f"{param_name}_{hashlib.md5(tensor_bytes).hexdigest()}"
        return hashlib.sha256(hash_input.encode()).hexdigest()
        
    def consensus_round(self, all_updates: List[ModelUpdate]) -> Tuple[Dict[str, torch.Tensor], Dict]:
        """Execute one round of consensus-protected learning"""
        
        self.consensus_rounds += 1
        round_start_time = time.time()
        
        # Step 1: Byzantine detection
        byzantine_agents = self.byzantine_detector.detect_byzantine_behavior(all_updates)
        self.byzantine_detected_count += len(byzantine_agents)
        
        # Step 2: Update trust scores
        self.byzantine_detector.update_trust_scores(all_updates, byzantine_agents)
        
        # Step 3: Filter out severely compromised updates
        filtered_updates = [
            update for update in all_updates 
            if update.trust_score > 0.2 and update.agent_id not in byzantine_agents
        ]
        
        # Step 4: Secure aggregation
        try:
            if self.aggregation_method == AggregationMethod.TRIMMED_MEAN:
                consensus_gradients = self.aggregator.trimmed_mean_aggregation(filtered_updates)
            elif self.aggregation_method == AggregationMethod.KRUM:
                consensus_gradients = self.aggregator.krum_aggregation(filtered_updates)
            else:
                # Fallback to simple averaging
                consensus_gradients = self._simple_averaging(filtered_updates)
                
            success = True
            
        except Exception as e:
            print(f"Consensus aggregation failed: {e}")
            # Fallback: use local update only
            consensus_gradients = all_updates[0].gradients if all_updates else {}
            success = False
            
        # Step 5: Update success rate
        if self.consensus_rounds > 0:
            self.consensus_success_rate = (
                (self.consensus_rounds - (self.byzantine_detected_count / max(1, len(byzantine_agents))))
                / self.consensus_rounds
            )
            
        # Performance metrics
        round_time = time.time() - round_start_time
        consensus_metrics = {
            'round_time': round_time,
            'byzantine_detected': len(byzantine_agents),
            'updates_used': len(filtered_updates),
            'total_updates': len(all_updates),
            'success': success,
            'trust_scores': {update.agent_id: update.trust_score for update in all_updates}
        }
        
        return consensus_gradients, consensus_metrics
        
    def _simple_averaging(self, updates: List[ModelUpdate]) -> Dict[str, torch.Tensor]:
        """Fallback simple averaging for consensus"""
        if not updates:
            return {}
            
        aggregated_params = {}
        param_names = list(updates[0].gradients.keys())
        
        for param_name in param_names:
            param_sum = None
            count = 0
            
            for update in updates:
                if param_name in update.gradients:
                    if param_sum is None:
                        param_sum = update.gradients[param_name].clone()
                    else:
                        param_sum += update.gradients[param_name]
                    count += 1
                    
            if count > 0:
                aggregated_params[param_name] = param_sum / count
                
        return aggregated_params
        
    def get_consensus_metrics(self) -> Dict[str, Any]:
        """Get performance metrics for consensus learning"""
        
        return {
            'consensus_rounds': self.consensus_rounds,
            'byzantine_detected_total': self.byzantine_detected_count,
            'success_rate': self.consensus_success_rate,
            'trust_scores': dict(self.byzantine_detector.suspicion_scores),
            'active_agents': self.n_agents,
            'byzantine_tolerance': self.f_byzantine
        }
        
    def reset_metrics(self):
        """Reset performance tracking metrics"""
        self.consensus_rounds = 0
        self.byzantine_detected_count = 0
        self.consensus_success_rate = 0.0
        self.byzantine_detector.suspicion_scores.clear() 