class ConsensusManager:
    """
    Enhanced Consensus Manager with rigorous mathematical formulations
    Implements the consensus algorithms described in the paper
    """
    
    def __init__(self, agent_id, n_agents, f_byzantine):
        self.agent_id = agent_id
        self.n_agents = n_agents
        self.f_byzantine = f_byzantine
        
        # Mathematical parameters for consensus convergence
        self.alpha = 0.1  # Consensus step size
        self.epsilon = 1e-6  # Convergence threshold
        self.max_iterations = 100
        
        # Byzantine fault tolerance check
        assert f_byzantine < n_agents / 3, f"Byzantine tolerance violated: f={f_byzantine} >= n/3={n_agents/3}"
        
    def trimmed_mean_consensus(self, local_values, all_agent_values):
        """
        Implement Coordinate-wise Trimmed Mean consensus algorithm
        
        Mathematical formulation from paper:
        ΔW*_j = (1/(m-2β)) * Σ(i=β+1 to m-β) Δw_i,j^sorted
        
        Where:
        - β = f_byzantine (number of Byzantine agents to trim)
        - m = n_agents (total number of agents)
        - Δw_i,j^sorted = sorted parameter updates for coordinate j
        
        Args:
            local_values: Local agent parameter updates
            all_agent_values: All agents' parameter updates [n_agents, param_dim]
            
        Returns:
            consensus_values: Byzantine-resilient consensus result
        """
        n_agents, param_dim = all_agent_values.shape
        beta = self.f_byzantine
        consensus_values = np.zeros(param_dim)
        
        for j in range(param_dim):
            # Get all values for parameter coordinate j
            coord_values = all_agent_values[:, j]
            
            # Sort values for trimmed mean
            sorted_values = np.sort(coord_values)
            
            # Trim β smallest and β largest values (remove Byzantine extremes)
            trimmed_values = sorted_values[beta:n_agents-beta]
            
            # Calculate consensus as mean of remaining values
            consensus_values[j] = np.mean(trimmed_values)
            
        return consensus_values
    
    def consensus_convergence_analysis(self, iteration_values):
        """
        Analyze convergence properties of consensus algorithm
        
        Theoretical bound from paper:
        ||x_i^(k) - x*|| ≤ ρ^k * ||x_i^(0) - x*||
        
        Where:
        - ρ < 1 is the convergence rate
        - x* is the true consensus value
        - k is the iteration number
        """
        convergence_rates = []
        
        for k in range(1, len(iteration_values)):
            # Calculate convergence rate ρ
            current_error = np.linalg.norm(iteration_values[k] - iteration_values[-1])
            previous_error = np.linalg.norm(iteration_values[k-1] - iteration_values[-1])
            
            if previous_error > 0:
                rho = current_error / previous_error
                convergence_rates.append(rho)
        
        return {
            'average_convergence_rate': np.mean(convergence_rates),
            'theoretical_bound_satisfied': np.mean(convergence_rates) < 1.0,
            'convergence_iterations': len(iteration_values)
        } 