#!/usr/bin/env python3
"""
Advanced 6G Network Modeling for CTLC Framework
Implements realistic 6G network characteristics including uRLLC and eMBB
"""

import numpy as np
import torch
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
from enum import Enum

class NetworkSlice(Enum):
    """6G Network Slice Types"""
    URLLC = "ultra_reliable_low_latency"
    EMBB = "enhanced_mobile_broadband"
    MMTC = "massive_machine_type_communication"

@dataclass
class NetworkQoS:
    """6G Quality of Service Parameters"""
    latency_ms: float
    bandwidth_mbps: float
    reliability: float  # 0-1
    jitter_ms: float
    packet_loss_rate: float
    energy_efficiency: float  # bits/joule

class SixGNetworkModel:
    """
    Realistic 6G Network Model with Dynamic Characteristics
    """
    
    def __init__(self):
        self.current_time = 0.0
        self.network_load = 0.5  # 0-1
        self.interference_level = 0.1  # 0-1
        
        # 6G Specification Parameters (based on ITU-R standards)
        self.urllc_specs = {
            'base_latency': 0.1,      # 0.1ms
            'max_latency': 1.0,       # 1ms
            'base_bandwidth': 100,     # 100 Mbps
            'max_bandwidth': 500,      # 500 Mbps
            'reliability': 0.99999,    # 99.999%
            'jitter': 0.01,           # 0.01ms
            'packet_loss': 1e-6       # 10^-6
        }
        
        self.embb_specs = {
            'base_latency': 1.0,      # 1ms
            'max_latency': 5.0,       # 5ms
            'base_bandwidth': 1000,    # 1 Gbps
            'max_bandwidth': 10000,    # 10 Gbps
            'reliability': 0.999,      # 99.9%
            'jitter': 0.1,            # 0.1ms
            'packet_loss': 1e-5       # 10^-5
        }
        
        # Channel state modeling
        self.channel_state = self._initialize_channel_state()
        
        # Traffic modeling
        self.traffic_patterns = {
            'v2v_control': {'priority': 1, 'slice': NetworkSlice.URLLC},
            'v2v_perception': {'priority': 2, 'slice': NetworkSlice.EMBB},
            'v2i_sync': {'priority': 1, 'slice': NetworkSlice.URLLC},
            'consensus_data': {'priority': 1, 'slice': NetworkSlice.URLLC}
        }

    def _initialize_channel_state(self) -> Dict:
        """Initialize realistic 6G channel state"""
        return {
            'sinr_db': np.random.normal(20, 5),  # Signal-to-Interference-plus-Noise Ratio
            'path_loss': np.random.exponential(80),  # dB
            'fading': np.random.rayleigh(1.0),
            'doppler_shift': np.random.normal(0, 50),  # Hz
            'beamforming_gain': np.random.uniform(10, 25)  # dB
        }

    def update_network_conditions(self, vehicles_count: int, rsu_count: int, 
                                traffic_density: float) -> None:
        """Update dynamic network conditions based on environment"""
        self.current_time += 0.001  # 1ms step
        
        # Dynamic network load based on vehicle density
        base_load = min(vehicles_count / 50.0, 1.0)  # Normalize to max 50 vehicles
        traffic_factor = 1.0 + 0.5 * traffic_density
        self.network_load = min(base_load * traffic_factor, 1.0)
        
        # Dynamic interference (time-varying)
        interference_variation = 0.1 * np.sin(0.1 * self.current_time) + \
                               0.05 * np.random.normal()
        self.interference_level = np.clip(0.05 + interference_variation, 0, 0.5)
        
        # Update channel state with mobility effects
        self._update_channel_state(vehicles_count)

    def _update_channel_state(self, vehicles_count: int) -> None:
        """Update channel state considering vehicle mobility"""
        # Doppler effect from vehicle movement
        velocity_factor = min(vehicles_count * 2.0, 120.0)  # km/h
        self.channel_state['doppler_shift'] = velocity_factor * 5.56 * 28e9 / 3e8  # Hz
        
        # Path loss variation
        distance_variation = np.random.normal(0, 10)
        self.channel_state['path_loss'] += distance_variation * 0.1
        self.channel_state['path_loss'] = np.clip(self.channel_state['path_loss'], 60, 120)
        
        # Fading updates
        self.channel_state['fading'] = 0.9 * self.channel_state['fading'] + \
                                     0.1 * np.random.rayleigh(1.0)
        
        # SINR calculation
        signal_power = 30 - self.channel_state['path_loss'] + \
                      self.channel_state['beamforming_gain']
        noise_power = -174 + 10 * np.log10(100e6) + 7  # dBm
        interference_power = noise_power + 10 * np.log10(self.interference_level * 10)
        
        self.channel_state['sinr_db'] = signal_power - 10 * np.log10(
            10**(noise_power/10) + 10**(interference_power/10)
        )

    def get_qos_parameters(self, slice_type: NetworkSlice, 
                          data_size_mb: float = 1.0) -> NetworkQoS:
        """Get realistic QoS parameters for specific network slice"""
        
        if slice_type == NetworkSlice.URLLC:
            specs = self.urllc_specs
        else:  # eMBB
            specs = self.embb_specs
        
        # Calculate dynamic parameters based on network conditions
        load_factor = 1.0 + self.network_load * 0.5
        interference_factor = 1.0 + self.interference_level * 0.3
        channel_quality = max(0.1, (self.channel_state['sinr_db'] - 5) / 20)
        
        # Dynamic latency calculation
        base_latency = specs['base_latency']
        processing_delay = 0.1 * load_factor  # Processing delay
        queuing_delay = base_latency * load_factor * interference_factor
        propagation_delay = 0.01  # ~3km at light speed
        
        total_latency = (base_latency + processing_delay + 
                        queuing_delay + propagation_delay) / channel_quality
        total_latency = min(total_latency, specs['max_latency'])
        
        # Dynamic bandwidth calculation
        max_bandwidth = specs['max_bandwidth'] * channel_quality
        contention_factor = 1.0 / (1.0 + self.network_load * 2)
        available_bandwidth = max_bandwidth * contention_factor
        available_bandwidth = max(available_bandwidth, specs['base_bandwidth'])
        
        # Dynamic reliability
        base_reliability = specs['reliability']
        channel_reliability = 1.0 - (1.0 - base_reliability) * (2.0 - channel_quality)
        network_reliability = channel_reliability * (1.0 - self.interference_level * 0.1)
        
        # Jitter calculation
        base_jitter = specs['jitter']
        dynamic_jitter = base_jitter * (1.0 + self.network_load * 0.5)
        
        # Packet loss calculation
        base_loss = specs['packet_loss']
        dynamic_loss = base_loss * (1.0 + self.interference_level * 10)
        
        # Energy efficiency (simplified model)
        energy_efficiency = (available_bandwidth / 1000) / (0.1 + self.network_load * 0.5)
        
        return NetworkQoS(
            latency_ms=total_latency,
            bandwidth_mbps=available_bandwidth,
            reliability=network_reliability,
            jitter_ms=dynamic_jitter,
            packet_loss_rate=dynamic_loss,
            energy_efficiency=energy_efficiency
        )

    def simulate_transmission(self, data_size_mb: float, slice_type: NetworkSlice,
                            priority: int = 1) -> Tuple[float, bool, Dict]:
        """Simulate realistic data transmission over 6G"""
        qos = self.get_qos_parameters(slice_type, data_size_mb)
        
        # Calculate transmission time
        transmission_time = (data_size_mb * 8) / qos.bandwidth_mbps  # seconds
        total_time = transmission_time + qos.latency_ms / 1000.0
        
        # Determine success based on reliability
        success = np.random.random() < qos.reliability
        
        # Add realistic delays and variations
        actual_latency = qos.latency_ms + np.random.exponential(qos.jitter_ms)
        
        # Packet loss simulation
        packet_loss_occurred = np.random.random() < qos.packet_loss_rate
        
        transmission_stats = {
            'actual_latency_ms': actual_latency,
            'actual_bandwidth_mbps': qos.bandwidth_mbps,
            'packets_lost': packet_loss_occurred,
            'transmission_time_s': transmission_time,
            'total_time_s': total_time,
            'energy_consumed_j': data_size_mb * 8 / qos.energy_efficiency,
            'channel_sinr_db': self.channel_state['sinr_db'],
            'network_load': self.network_load
        }
        
        return total_time, success and not packet_loss_occurred, transmission_stats

    def get_adaptive_weights(self) -> Tuple[float, float]:
        """Calculate adaptive weights based on current 6G conditions"""
        urllc_qos = self.get_qos_parameters(NetworkSlice.URLLC)
        embb_qos = self.get_qos_parameters(NetworkSlice.EMBB)
        
        # Normalize latency (lower is better for uRLLC)
        latency_score_urllc = max(0, 1.0 - urllc_qos.latency_ms / self.urllc_specs['max_latency'])
        
        # Normalize bandwidth (higher is better for eMBB)
        bandwidth_score_embb = min(1.0, embb_qos.bandwidth_mbps / self.embb_specs['max_bandwidth'])
        
        # Calculate reliability-weighted scores
        urllc_weight = latency_score_urllc * urllc_qos.reliability
        embb_weight = bandwidth_score_embb * embb_qos.reliability
        
        # Normalize weights
        total_weight = urllc_weight + embb_weight
        if total_weight > 0:
            urllc_weight /= total_weight
            embb_weight /= total_weight
        else:
            urllc_weight = embb_weight = 0.5
        
        return urllc_weight, embb_weight

    def get_network_status_display(self) -> Dict:
        """Get comprehensive network status for UI display"""
        urllc_qos = self.get_qos_parameters(NetworkSlice.URLLC)
        embb_qos = self.get_qos_parameters(NetworkSlice.EMBB)
        
        return {
            'urllc': {
                'latency_ms': urllc_qos.latency_ms,
                'bandwidth_mbps': urllc_qos.bandwidth_mbps,
                'reliability_percent': urllc_qos.reliability * 100,
                'status': 'excellent' if urllc_qos.latency_ms < 0.5 else 
                         'good' if urllc_qos.latency_ms < 1.0 else 'degraded'
            },
            'embb': {
                'latency_ms': embb_qos.latency_ms,
                'bandwidth_gbps': embb_qos.bandwidth_mbps / 1000.0,
                'reliability_percent': embb_qos.reliability * 100,
                'status': 'excellent' if embb_qos.bandwidth_mbps > 5000 else
                         'good' if embb_qos.bandwidth_mbps > 1000 else 'degraded'
            },
            'network_load_percent': self.network_load * 100,
            'interference_level_percent': self.interference_level * 100,
            'channel_quality': {
                'sinr_db': self.channel_state['sinr_db'],
                'quality': 'excellent' if self.channel_state['sinr_db'] > 15 else
                          'good' if self.channel_state['sinr_db'] > 10 else 'poor'
            }
        }

class NetworkDelaySimulator:
    """Simulate realistic network delays for different message types"""
    
    def __init__(self, network_model: SixGNetworkModel):
        self.network = network_model
        self.message_queue = []
        
    def send_message(self, sender_id: str, receiver_id: str, message_type: str,
                    data_size_mb: float, timestamp: float) -> float:
        """Send message with realistic 6G delay simulation"""
        
        # Determine network slice based on message type
        if message_type in ['consensus_sync', 'safety_critical', 'emergency']:
            slice_type = NetworkSlice.URLLC
            priority = 1
        elif message_type in ['perception_data', 'model_update', 'cooperative_sensing']:
            slice_type = NetworkSlice.EMBB
            priority = 2
        else:
            slice_type = NetworkSlice.URLLC
            priority = 3
        
        # Simulate transmission
        transmission_time, success, stats = self.network.simulate_transmission(
            data_size_mb, slice_type, priority
        )
        
        arrival_time = timestamp + transmission_time
        
        # Add to message queue (for analysis)
        self.message_queue.append({
            'sender': sender_id,
            'receiver': receiver_id,
            'type': message_type,
            'send_time': timestamp,
            'arrival_time': arrival_time,
            'success': success,
            'stats': stats
        })
        
        return arrival_time if success else float('inf')

    def get_network_metrics(self) -> Dict:
        """Calculate network performance metrics"""
        if not self.message_queue:
            return {}
        
        recent_messages = [msg for msg in self.message_queue[-100:]]  # Last 100 messages
        
        latencies = [msg['arrival_time'] - msg['send_time'] 
                    for msg in recent_messages if msg['success']]
        success_rate = sum(1 for msg in recent_messages if msg['success']) / len(recent_messages)
        
        return {
            'average_latency_ms': np.mean(latencies) * 1000 if latencies else 0,
            'max_latency_ms': np.max(latencies) * 1000 if latencies else 0,
            'success_rate_percent': success_rate * 100,
            'total_messages': len(self.message_queue),
            'recent_throughput': len(recent_messages) / max(1, len(recent_messages) * 0.1)
        } 