import pygame
import torch

class Config:
    """
    A centralized static class for holding all configuration parameters.
    This makes it easy to tune and manage experimental setups.
    """
    # General Simulation Settings
    WIDTH, HEIGHT = 1900, 1000  # Perfect fit for most screen displays
    FPS = 30
    TICK_RATE = 1.0 / FPS  # Simulation time per frame

    # Pygame Initialization
    pygame.font.init()

    # Colors
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    GRAY = (120, 120, 120)
    ROAD_COLOR = (50, 50, 50)
    RED = (220, 50, 50)
    GREEN = (50, 220, 50)
    BLUE = (50, 50, 220)
    PURPLE = (150, 50, 220)
    BROWN = (139, 69, 19)

    # Fonts
    try:
        # Use a font that is commonly available and supports CJK characters
        FONT_LG = pygame.font.SysFont("notosanscjk", 32)
        FONT_MD = pygame.font.SysFont("notosanscjk", 24)
        FONT_SM = pygame.font.SysFont("notosanscjk", 18)
    except pygame.error:
        print("Default font 'notosanscjk' not found, falling back to system default.")
        FONT_LG = pygame.font.SysFont(None, 48)
        FONT_MD = pygame.font.SysFont(None, 32)
        FONT_SM = pygame.font.SysFont(None, 24)


    # Physics and Vehicle Parameters  
    MAX_SPEED = 0.25  # m/s (slow but natural on longer road)
    MIN_SPEED = 0.05  # m/s (low minimum speed)
    MAX_ACCELERATION = 0.08  # m/s^2 (gentle acceleration)
    MAX_STEERING_ANGLE = 30.0 # degrees

    # Communication and Perception
    COMM_RANGE = 400  # V2X communication range for GNN graph construction
    LIDAR_RANGE = 180 # LiDAR sensor scan radius
    FPV_RANGE = 220   # FPV sensor range
    FPV_FOV = 120     # FPV sensor Field of View (degrees)

    # Safety Layer (HOCBF) Parameters
    MIN_SAFE_DIST = 80 # HOCBF safety distance threshold
    EMERGENCY_BRAKE_ACCEL = -5.0 # m/s^2

    # --- AI and Learning Parameters ---
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # ST-GNN Architecture Parameters (Updated naming for consistency)
    NODE_FEATURE_SIZE = 16          # Size of input node features
    STGNN_HIDDEN_DIM = 32          # Hidden dimension for ST-GNN
    STGNN_OUTPUT_DIM = 16          # Output dimension for ST-GNN embeddings
    STGNN_LAYERS = 2               # Number of ST-GNN layers
    
    # Legacy naming for backward compatibility
    GNN_FEATURE_SIZE = NODE_FEATURE_SIZE
    GNN_HIDDEN_SIZE = STGNN_HIDDEN_DIM
    GNN_OUTPUT_SIZE = STGNN_OUTPUT_DIM

    # SAC Agent
    STATE_DIM = GNN_OUTPUT_SIZE # The state for the RL agent is the output of the GNN
    ACTION_DIM = 2  # [acceleration, steering]
    HIDDEN_DIM = 256 # Hidden layer size for Actor/Critic networks
    ALPHA = 0.2  # Entropy regularization coefficient
    LEARNING_RATE = 3e-4
    
    # Training frequency control (to prevent overtraining in real-time simulation)
    LEARNING_UPDATE_FREQUENCY = 5  # Update SAC networks every N steps instead of every step
    STGNN_UPDATE_FREQUENCY = 10     # Update ST-GNN every N steps (less frequent than SAC)
    
    # Training
    REPLAY_BUFFER_SIZE = 1_000_000
    BATCH_SIZE = 256
    GAMMA = 0.99  # Discount factor
    TAU = 0.005  # Soft update coefficient for target networks
    
    # Consensus-Driven DDRL
    CONSENSUS_ROUNDS = 50 # Number of steps between consensus model updates
    TRIMMED_MEAN_BETA = 0.1 # Percentage of updates to trim from each side
    
    # Scenario Settings
    NUM_VEHICLES = 10
    NUM_POTHOLES = 15  # Increased pothole count from 5 to 15
    NUM_RSUS = 1
    
    # Plotting
    PLOT_UPDATE_FREQ = 100 # Update plots every N training steps
