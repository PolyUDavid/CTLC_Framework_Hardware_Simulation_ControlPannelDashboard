#!/usr/bin/env python3
"""
Advanced Multi-Modal Sensor Fusion for CTLC Framework
Integrates Vision (ViT), LiDAR (PointNet), and Radar data with attention mechanisms
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
import math

class SensorModality(Enum):
    """Sensor modality types"""
    CAMERA_RGB = "camera_rgb"
    CAMERA_DEPTH = "camera_depth"
    LIDAR_POINT_CLOUD = "lidar_pointcloud"
    RADAR_DOPPLER = "radar_doppler"
    IMU_ACCEL = "imu_acceleration"
    GPS_POSITION = "gps_position"

@dataclass
class SensorData:
    """Structured sensor data container"""
    modality: SensorModality
    data: torch.Tensor
    timestamp: float
    confidence: float  # 0-1 reliability score
    spatial_resolution: Tuple[float, float]  # (x_res, y_res) in meters
    sensor_id: str
    calibration_matrix: Optional[torch.Tensor] = None

class PositionalEncoding(nn.Module):
    """3D positional encoding for spatial sensor data"""
    
    def __init__(self, d_model: int, max_len: int = 5000):
        super().__init__()
        
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * 
                           (-math.log(10000.0) / d_model))
        
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        self.register_buffer('pe', pe.unsqueeze(0).transpose(0, 1))
    
    def forward(self, x):
        return x + self.pe[:x.size(0), :]

class VisionTransformerEncoder(nn.Module):
    """Vision Transformer for RGB/Depth camera data"""
    
    def __init__(self, 
                 input_channels: int = 3,
                 patch_size: int = 8,  # 减小patch size以适应小尺寸图像
                 img_size: int = 64,   # 默认使用64x64尺寸
                 embed_dim: int = 256, # 减小嵌入维度
                 num_heads: int = 8,   # 减少注意力头数
                 num_layers: int = 4,  # 减少transformer层数
                 mlp_ratio: int = 4):
        super().__init__()
        
        self.patch_size = patch_size
        self.img_size = img_size
        self.num_patches = (img_size // patch_size) ** 2
        
        # Patch embedding
        self.patch_embed = nn.Conv2d(input_channels, embed_dim, 
                                   kernel_size=patch_size, stride=patch_size)
        
        # Positional embedding
        self.pos_embed = nn.Parameter(torch.zeros(1, self.num_patches + 1, embed_dim))
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        
        # Transformer layers
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embed_dim,
            nhead=num_heads,
            dim_feedforward=embed_dim * mlp_ratio,
            dropout=0.1,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers)
        
        # Output projection
        self.output_proj = nn.Linear(embed_dim, 256)
        
        self._init_weights()
    
    def _init_weights(self):
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        nn.init.trunc_normal_(self.cls_token, std=0.02)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, H, W = x.shape
        
        # 动态调整patch embedding以适应不同输入尺寸
        if H != self.img_size or W != self.img_size:
            # 使用自适应平均池化将输入调整到期望尺寸
            x = F.adaptive_avg_pool2d(x, (self.img_size, self.img_size))
        
        # Patch embedding
        x = self.patch_embed(x)  # (B, embed_dim, H//patch_size, W//patch_size)
        x = x.flatten(2).transpose(1, 2)  # (B, num_patches, embed_dim)
        
        # 动态调整位置编码
        actual_num_patches = x.shape[1]
        if actual_num_patches != self.num_patches:
            # 如果patch数量不匹配，使用插值调整位置编码
            pos_embed_resized = F.interpolate(
                self.pos_embed[:, 1:, :].transpose(1, 2).view(1, -1, int(self.num_patches**0.5), int(self.num_patches**0.5)),
                size=(int(actual_num_patches**0.5), int(actual_num_patches**0.5)),
                mode='bilinear',
                align_corners=False
            ).view(1, -1, actual_num_patches).transpose(1, 2)
            pos_embed = torch.cat([self.pos_embed[:, :1, :], pos_embed_resized], dim=1)
        else:
            pos_embed = self.pos_embed
        
        # Add class token
        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat([cls_tokens, x], dim=1)
        
        # Add positional embedding
        x = x + pos_embed[:, :x.shape[1], :]
        
        # Transformer encoding
        x = self.transformer(x)
        
        # Use class token for global representation
        global_features = self.output_proj(x[:, 0])  # (B, 256)
        
        return global_features

class PointNetEncoder(nn.Module):
    """PointNet-based encoder for LiDAR point cloud data"""
    
    def __init__(self, 
                 input_dim: int = 3,  # x, y, z coordinates
                 feature_dim: int = 256,
                 max_points: int = 4096):
        super().__init__()
        
        self.max_points = max_points
        
        # Point-wise feature extraction
        self.conv1 = nn.Conv1d(input_dim, 64, 1)
        self.conv2 = nn.Conv1d(64, 128, 1)
        self.conv3 = nn.Conv1d(128, 256, 1)
        
        self.bn1 = nn.BatchNorm1d(64)
        self.bn2 = nn.BatchNorm1d(128)
        self.bn3 = nn.BatchNorm1d(256)
        
        # Global feature extraction
        self.global_conv1 = nn.Conv1d(256, 512, 1)
        self.global_conv2 = nn.Conv1d(512, 1024, 1)
        
        self.global_bn1 = nn.BatchNorm1d(512)
        self.global_bn2 = nn.BatchNorm1d(1024)
        
        # Final projection
        self.fc = nn.Linear(1024, feature_dim)
        self.dropout = nn.Dropout(0.3)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (B, N, 3) where N is number of points
        B, N, _ = x.shape
        
        # Pad or sample to max_points
        if N > self.max_points:
            # Random sampling
            indices = torch.randperm(N)[:self.max_points]
            x = x[:, indices, :]
        elif N < self.max_points:
            # Padding with zeros
            padding = torch.zeros(B, self.max_points - N, x.size(2), device=x.device)
            x = torch.cat([x, padding], dim=1)
        
        # Transpose for conv1d: (B, 3, max_points)
        x = x.transpose(1, 2)
        
        # Point-wise feature extraction
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x)))
        
        # Global feature extraction
        x = F.relu(self.global_bn1(self.global_conv1(x)))
        x = F.relu(self.global_bn2(self.global_conv2(x)))
        
        # Global max pooling
        x = torch.max(x, 2)[0]  # (B, 1024)
        
        # Final projection
        x = self.dropout(x)
        x = self.fc(x)  # (B, feature_dim)
        
        return x

class RadarDopplerEncoder(nn.Module):
    """Encoder for Radar Doppler velocity maps"""
    
    def __init__(self, 
                 input_channels: int = 1,  # Doppler velocity
                 feature_dim: int = 256):
        super().__init__()
        
        # CNN backbone for Doppler maps
        self.conv_layers = nn.Sequential(
            nn.Conv2d(input_channels, 32, 3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),
            
            nn.Conv2d(32, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),
            
            nn.Conv2d(64, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(2),
            
            nn.Conv2d(128, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((4, 4))
        )
        
        self.fc = nn.Linear(256 * 4 * 4, feature_dim)
        self.dropout = nn.Dropout(0.2)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (B, 1, H, W) - Doppler velocity map
        x = self.conv_layers(x)
        x = x.view(x.size(0), -1)  # Flatten
        x = self.dropout(x)
        x = self.fc(x)
        return x

class CrossModalAttention(nn.Module):
    """Cross-modal attention mechanism for sensor fusion"""
    
    def __init__(self, feature_dim: int = 256, num_heads: int = 8):
        super().__init__()
        
        self.feature_dim = feature_dim
        self.num_heads = num_heads
        self.head_dim = feature_dim // num_heads
        
        # Attention components
        self.query_proj = nn.Linear(feature_dim, feature_dim)
        self.key_proj = nn.Linear(feature_dim, feature_dim)
        self.value_proj = nn.Linear(feature_dim, feature_dim)
        
        self.output_proj = nn.Linear(feature_dim, feature_dim)
        self.dropout = nn.Dropout(0.1)
        
        # Positional encoding for different modalities
        self.modality_embedding = nn.Embedding(6, feature_dim)  # 6 sensor types
        
    def forward(self, 
               features: Dict[SensorModality, torch.Tensor],
               attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        
        # Prepare features and modality embeddings
        feature_list = []
        modality_ids = []
        
        modality_to_id = {
            SensorModality.CAMERA_RGB: 0,
            SensorModality.CAMERA_DEPTH: 1,
            SensorModality.LIDAR_POINT_CLOUD: 2,
            SensorModality.RADAR_DOPPLER: 3,
            SensorModality.IMU_ACCEL: 4,
            SensorModality.GPS_POSITION: 5
        }
        
        for modality, feature in features.items():
            feature_list.append(feature)
            modality_ids.append(modality_to_id[modality])
        
        if not feature_list:
            return torch.zeros(1, self.feature_dim)
        
        # Stack features: (B, num_modalities, feature_dim)
        stacked_features = torch.stack(feature_list, dim=1)
        B, M, D = stacked_features.shape
        
        # Add modality embeddings
        modality_emb = self.modality_embedding(torch.tensor(modality_ids, device=stacked_features.device))
        stacked_features = stacked_features + modality_emb.unsqueeze(0)
        
        # Multi-head attention
        Q = self.query_proj(stacked_features)  # (B, M, D)
        K = self.key_proj(stacked_features)    # (B, M, D)
        V = self.value_proj(stacked_features)  # (B, M, D)
        
        # Reshape for multi-head attention
        Q = Q.view(B, M, self.num_heads, self.head_dim).transpose(1, 2)  # (B, H, M, D/H)
        K = K.view(B, M, self.num_heads, self.head_dim).transpose(1, 2)  # (B, H, M, D/H)
        V = V.view(B, M, self.num_heads, self.head_dim).transpose(1, 2)  # (B, H, M, D/H)
        
        # Attention computation
        attention_scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.head_dim)
        
        if attention_mask is not None:
            attention_scores = attention_scores.masked_fill(attention_mask == 0, -1e9)
        
        attention_weights = F.softmax(attention_scores, dim=-1)
        attention_weights = self.dropout(attention_weights)
        
        # Apply attention
        attended_features = torch.matmul(attention_weights, V)  # (B, H, M, D/H)
        
        # Concatenate heads
        attended_features = attended_features.transpose(1, 2).contiguous().view(B, M, D)
        
        # Output projection
        output = self.output_proj(attended_features)
        
        # Global pooling across modalities 
        # Use mean attention across all heads and queries for each modality
        modality_weights = torch.mean(torch.mean(attention_weights, dim=1), dim=-1)  # (B, M)
        modality_weights = torch.softmax(modality_weights, dim=-1)  # Normalize
        
        # Weighted average of modalities
        fused_features = torch.sum(output * modality_weights.unsqueeze(-1), dim=1)  # (B, D)
        
        return fused_features

class TemporalFusionModule(nn.Module):
    """Temporal fusion of multi-modal features over time"""
    
    def __init__(self, feature_dim: int = 256, seq_length: int = 10):
        super().__init__()
        
        self.feature_dim = feature_dim
        self.seq_length = seq_length
        
        # LSTM for temporal modeling
        self.lstm = nn.LSTM(
            input_size=feature_dim,
            hidden_size=feature_dim,
            num_layers=2,
            batch_first=True,
            dropout=0.1,
            bidirectional=False
        )
        
        # Attention over time steps
        self.temporal_attention = nn.MultiheadAttention(
            embed_dim=feature_dim,
            num_heads=8,
            dropout=0.1,
            batch_first=True
        )
        
        self.output_proj = nn.Linear(feature_dim, feature_dim)
        
    def forward(self, temporal_features: torch.Tensor) -> torch.Tensor:
        # temporal_features shape: (B, seq_length, feature_dim)
        
        # LSTM processing
        lstm_out, (h_n, c_n) = self.lstm(temporal_features)
        
        # Self-attention over time steps
        attended_features, _ = self.temporal_attention(lstm_out, lstm_out, lstm_out)
        
        # Use the last time step
        final_features = self.output_proj(attended_features[:, -1, :])
        
        return final_features

class MultiModalFusionNetwork(nn.Module):
    """Complete multi-modal sensor fusion network"""
    
    def __init__(self, 
                 output_dim: int = 512,
                 seq_length: int = 10,
                 use_temporal: bool = True):
        super().__init__()
        
        self.output_dim = output_dim
        self.seq_length = seq_length
        self.use_temporal = use_temporal
        
        # Modality-specific encoders
        self.vision_encoder = VisionTransformerEncoder(input_channels=3)
        self.depth_encoder = VisionTransformerEncoder(input_channels=1)
        self.lidar_encoder = PointNetEncoder()
        self.radar_encoder = RadarDopplerEncoder()
        
        # Simple encoders for IMU and GPS
        self.imu_encoder = nn.Sequential(
            nn.Linear(6, 128),  # 3 accel + 3 gyro
            nn.ReLU(),
            nn.Linear(128, 256)
        )
        
        self.gps_encoder = nn.Sequential(
            nn.Linear(4, 128),  # lat, lon, alt, heading
            nn.ReLU(),
            nn.Linear(128, 256)
        )
        
        # Cross-modal attention
        self.cross_modal_attention = CrossModalAttention(feature_dim=256)
        
        # Temporal fusion (optional)
        if use_temporal:
            self.temporal_fusion = TemporalFusionModule(feature_dim=256, seq_length=seq_length)
        
        # Final output layers
        self.final_layers = nn.Sequential(
            nn.Linear(256, 512),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(512, output_dim)
        )
        
        # Feature buffer for temporal processing
        self.feature_buffer = []
        
    def encode_modality(self, sensor_data: SensorData) -> torch.Tensor:
        """Encode individual sensor modality"""
        
        data = sensor_data.data
        
        if sensor_data.modality == SensorModality.CAMERA_RGB:
            return self.vision_encoder(data)
        elif sensor_data.modality == SensorModality.CAMERA_DEPTH:
            return self.depth_encoder(data)
        elif sensor_data.modality == SensorModality.LIDAR_POINT_CLOUD:
            return self.lidar_encoder(data)
        elif sensor_data.modality == SensorModality.RADAR_DOPPLER:
            return self.radar_encoder(data)
        elif sensor_data.modality == SensorModality.IMU_ACCEL:
            return self.imu_encoder(data)
        elif sensor_data.modality == SensorModality.GPS_POSITION:
            return self.gps_encoder(data)
        else:
            raise ValueError(f"Unknown modality: {sensor_data.modality}")
    
    def forward(self, sensor_inputs: List[SensorData]) -> Tuple[torch.Tensor, Dict]:
        """Forward pass with multi-modal sensor data"""
        
        # Encode each modality
        modality_features = {}
        confidence_scores = {}
        
        for sensor_data in sensor_inputs:
            if sensor_data.confidence > 0.1:  # Filter low-confidence data
                try:
                    features = self.encode_modality(sensor_data)
                    modality_features[sensor_data.modality] = features
                    confidence_scores[sensor_data.modality] = sensor_data.confidence
                except Exception as e:
                    print(f"Warning: Failed to encode {sensor_data.modality}: {e}")
                    continue
        
        if not modality_features:
            # No valid sensor data - return zero features
            return torch.zeros(1, self.output_dim), {'fusion_quality': 0.0}
        
        # Cross-modal attention fusion
        fused_features = self.cross_modal_attention(modality_features)
        
        # Add to temporal buffer
        if self.use_temporal:
            self.feature_buffer.append(fused_features)
            if len(self.feature_buffer) > self.seq_length:
                self.feature_buffer.pop(0)
            
            # Temporal fusion if enough history
            if len(self.feature_buffer) >= 3:
                # Stack temporal features: each element is (B, D), stack to (B, T, D)
                temporal_features = []
                for feat in self.feature_buffer:
                    # Ensure each feature is 2D (B, D)
                    if feat.dim() > 2:
                        feat = feat.view(feat.size(0), -1)  # Flatten to (B, D)
                    temporal_features.append(feat)
                
                temporal_stack = torch.stack(temporal_features, dim=1)  # (B, T, D)
                fused_features = self.temporal_fusion(temporal_stack)
            else:
                # Not enough history, use current features
                if fused_features.dim() > 2:
                    fused_features = fused_features.view(fused_features.size(0), -1)
        
        # Final processing
        output_features = self.final_layers(fused_features)
        
        # Calculate fusion quality metrics
        fusion_metrics = {
            'fusion_quality': np.mean(list(confidence_scores.values())),
            'active_modalities': len(modality_features),
            'modality_weights': {str(k): v for k, v in confidence_scores.items()},
            'temporal_depth': len(self.feature_buffer) if self.use_temporal else 1
        }
        
        return output_features, fusion_metrics
    
    def reset_temporal_buffer(self):
        """Reset temporal feature buffer"""
        self.feature_buffer = []
    
    def get_attention_weights(self) -> Dict:
        """Get attention weights for analysis"""
        # This would require storing attention weights during forward pass
        # Implementation depends on specific analysis needs
        return {}

class SensorSimulator:
    """Simulate different sensor modalities for testing"""
    
    @staticmethod
    def generate_camera_data(batch_size: int = 1, 
                           img_size: int = 224,
                           device: str = 'cpu') -> SensorData:
        """Generate simulated camera RGB data"""
        data = torch.randn(batch_size, 3, img_size, img_size, device=device)
        return SensorData(
            modality=SensorModality.CAMERA_RGB,
            data=data,
            timestamp=0.0,
            confidence=0.9,
            spatial_resolution=(0.1, 0.1),
            sensor_id="camera_front"
        )
    
    @staticmethod
    def generate_lidar_data(batch_size: int = 1,
                          num_points: int = 2048,
                          device: str = 'cpu') -> SensorData:
        """Generate simulated LiDAR point cloud data"""
        data = torch.randn(batch_size, num_points, 3, device=device) * 10  # Scale points
        return SensorData(
            modality=SensorModality.LIDAR_POINT_CLOUD,
            data=data,
            timestamp=0.0,
            confidence=0.95,
            spatial_resolution=(0.05, 0.05),
            sensor_id="lidar_velodyne"
        )
    
    @staticmethod
    def generate_radar_data(batch_size: int = 1,
                          map_size: int = 64,
                          device: str = 'cpu') -> SensorData:
        """Generate simulated Radar Doppler data"""
        data = torch.randn(batch_size, 1, map_size, map_size, device=device)
        return SensorData(
            modality=SensorModality.RADAR_DOPPLER,
            data=data,
            timestamp=0.0,
            confidence=0.8,
            spatial_resolution=(0.5, 0.5),
            sensor_id="radar_front"
        ) 