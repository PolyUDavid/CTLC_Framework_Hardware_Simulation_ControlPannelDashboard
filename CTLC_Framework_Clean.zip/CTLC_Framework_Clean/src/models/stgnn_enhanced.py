#!/usr/bin/env python3
"""
Enhanced Heterogeneous Adaptive Spatio-Temporal Graph Neural Network (ST-GNN)
Implements the advanced ST-GNN architecture described in the paper with 6G network awareness
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
import math

class NodeType(Enum):
    """Heterogeneous node types in the vehicular network"""
    VEHICLE = "vehicle"
    RSU = "rsu"
    EDGE_SERVER = "edge_server"

@dataclass
class NetworkCondition:
    """6G network condition state"""
    latency_ms: float
    bandwidth_mbps: float
    reliability: float
    load_factor: float
    slice_type: str  # "uRLLC" or "eMBB"

class MultiHeadSpatialAttention(nn.Module):
    """Multi-head spatial attention mechanism for dynamic message weighting"""
    
    def __init__(self, feature_dim: int, num_heads: int = 8):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = feature_dim // num_heads
        assert feature_dim % num_heads == 0
        
        self.W_query = nn.Linear(feature_dim, feature_dim)
        self.W_key = nn.Linear(feature_dim, feature_dim)
        self.W_value = nn.Linear(feature_dim, feature_dim)
        self.W_output = nn.Linear(feature_dim, feature_dim)
        
        self.dropout = nn.Dropout(0.1)
        self.layer_norm = nn.LayerNorm(feature_dim)
        
    def forward(self, node_features: torch.Tensor, 
                edge_index: torch.Tensor,
                attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Multi-head spatial attention computation
        
        Mathematical formulation:
        m_ji = ATTENTION(h_j, h_i) · TRANSFORM(h_j)
        ATTENTION(h_j, h_i) = softmax(W_a[h_j; h_i] / sqrt(d_k))
        """
        batch_size, num_nodes, feature_dim = node_features.shape
        
        # Linear transformations
        Q = self.W_query(node_features)  # [B, N, F]
        K = self.W_key(node_features)    # [B, N, F]
        V = self.W_value(node_features)  # [B, N, F]
        
        # Reshape for multi-head attention
        Q = Q.view(batch_size, num_nodes, self.num_heads, self.head_dim).transpose(1, 2)
        K = K.view(batch_size, num_nodes, self.num_heads, self.head_dim).transpose(1, 2)
        V = V.view(batch_size, num_nodes, self.num_heads, self.head_dim).transpose(1, 2)
        
        # Scaled dot-product attention
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.head_dim)
        
        # Apply attention mask for graph structure
        if attention_mask is not None:
            scores = scores.masked_fill(attention_mask == 0, -1e9)
            
        attention_weights = F.softmax(scores, dim=-1)
        attention_weights = self.dropout(attention_weights)
        
        # Apply attention to values
        attended_values = torch.matmul(attention_weights, V)
        
        # Concatenate heads and project
        attended_values = attended_values.transpose(1, 2).contiguous().view(
            batch_size, num_nodes, feature_dim
        )
        
        output = self.W_output(attended_values)
        
        # Residual connection and layer norm
        output = self.layer_norm(output + node_features)
        
        return output

class MultiScaleGraphConvLayer(nn.Module):
    """Multi-scale graph convolution for different interaction ranges"""
    
    def __init__(self, input_dim: int, output_dim: int, num_scales: int = 3):
        super().__init__()
        self.num_scales = num_scales
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Multi-scale convolution layers
        self.conv_layers = nn.ModuleList([
            nn.Linear(input_dim, output_dim // num_scales)
            for _ in range(num_scales)
        ])
        
        # Scale-specific edge processors
        self.edge_processors = nn.ModuleList([
            nn.Sequential(
                nn.Linear(2, 16),
                nn.ReLU(),
                nn.Linear(16, 1),
                nn.Sigmoid()
            ) for _ in range(num_scales)
        ])
        
        self.output_proj = nn.Linear(output_dim, output_dim)
        self.layer_norm = nn.LayerNorm(output_dim)
        
    def forward(self, node_features: torch.Tensor, 
                edge_index: torch.Tensor, 
                edge_attr: torch.Tensor) -> torch.Tensor:
        """
        Multi-scale graph convolution with different interaction ranges
        
        Scales:
        - Local (direct neighbors): collision avoidance, immediate coordination
        - Medium (2-hop neighbors): lane coordination, intersection management  
        - Global (all connected): traffic flow optimization, route planning
        """
        batch_size, num_nodes, feature_dim = node_features.shape
        
        scale_outputs = []
        
        for scale_idx in range(self.num_scales):
            # Scale-specific feature transformation
            scale_features = self.conv_layers[scale_idx](node_features)
            
            # Edge weight computation based on distance and scale
            edge_weights = self.edge_processors[scale_idx](edge_attr)
            
            # Scale-dependent aggregation
            scale_range = (scale_idx + 1) * 50.0  # 50m, 100m, 150m ranges
            
            # Message passing for this scale
            aggregated_features = self._scale_message_passing(
                scale_features, edge_index, edge_weights, scale_range
            )
            
            scale_outputs.append(aggregated_features)
            
        # Concatenate multi-scale features
        combined_features = torch.cat(scale_outputs, dim=-1)
        
        # Final projection and normalization
        output = self.output_proj(combined_features)
        output = self.layer_norm(output + node_features)
        
        return output
        
    def _scale_message_passing(self, features: torch.Tensor, 
                             edge_index: torch.Tensor,
                             edge_weights: torch.Tensor,
                             scale_range: float) -> torch.Tensor:
        """Perform message passing for specific scale"""
        
        batch_size, num_nodes, feature_dim = features.shape
        
        # Initialize aggregated features
        aggregated = torch.zeros_like(features)
        
        # Simplified message passing (in practice, use PyG functions)
        for batch_idx in range(batch_size):
            for edge_idx in range(edge_index.shape[1]):
                src, dst = edge_index[0, edge_idx], edge_index[1, edge_idx]
                weight = edge_weights[edge_idx, 0]
                
                # Distance-based filtering for scale
                if weight > 0.1:  # Edge exists and within scale range
                    message = features[batch_idx, src] * weight
                    aggregated[batch_idx, dst] += message
                    
        return aggregated

class TemporalAttentionLayer(nn.Module):
    """Temporal attention mechanism for time-series processing"""
    
    def __init__(self, feature_dim: int, seq_length: int):
        super().__init__()
        self.feature_dim = feature_dim
        self.seq_length = seq_length
        
        # Temporal self-attention
        self.temporal_attention = nn.MultiheadAttention(
            embed_dim=feature_dim,
            num_heads=8,
            dropout=0.1,
            batch_first=True
        )
        
        # Position encoding for temporal sequences
        self.position_encoding = self._create_position_encoding()
        
        # Temporal convolution for local patterns
        self.temporal_conv = nn.Conv1d(
            in_channels=feature_dim,
            out_channels=feature_dim,
            kernel_size=3,
            padding=1
        )
        
        self.layer_norm = nn.LayerNorm(feature_dim)
        
    def _create_position_encoding(self) -> torch.Tensor:
        """Create sinusoidal position encoding for temporal sequences"""
        pe = torch.zeros(self.seq_length, self.feature_dim)
        position = torch.arange(0, self.seq_length, dtype=torch.float).unsqueeze(1)
        
        div_term = torch.exp(torch.arange(0, self.feature_dim, 2).float() * 
                           -(math.log(10000.0) / self.feature_dim))
        
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        return pe.unsqueeze(0)  # [1, seq_len, feature_dim]
        
    def forward(self, temporal_features: torch.Tensor) -> torch.Tensor:
        """
        Temporal attention processing
        
        Args:
            temporal_features: [batch_size, seq_length, num_nodes, feature_dim]
        """
        batch_size, seq_length, num_nodes, feature_dim = temporal_features.shape
        
        # Reshape for temporal processing: [batch_size * num_nodes, seq_length, feature_dim]
        temporal_input = temporal_features.view(batch_size * num_nodes, seq_length, feature_dim)
        
        # Add position encoding
        position_enc = self.position_encoding[:, :seq_length, :].to(temporal_input.device)
        temporal_input = temporal_input + position_enc
        
        # Self-attention over temporal dimension
        attended_output, attention_weights = self.temporal_attention(
            temporal_input, temporal_input, temporal_input
        )
        
        # Temporal convolution for local patterns
        conv_input = attended_output.transpose(1, 2)  # [B*N, F, T]
        conv_output = self.temporal_conv(conv_input)
        conv_output = conv_output.transpose(1, 2)    # [B*N, T, F]
        
        # Residual connection and normalization
        output = self.layer_norm(conv_output + attended_output)
        
        # Reshape back: [batch_size, seq_length, num_nodes, feature_dim]
        output = output.view(batch_size, seq_length, num_nodes, feature_dim)
        
        return output

class NetworkConditionEncoder(nn.Module):
    """Encoder for 6G network conditions to influence graph processing"""
    
    def __init__(self, condition_dim: int = 32, hidden_dim: int = 64):
        super().__init__()
        
        self.latency_encoder = nn.Sequential(
            nn.Linear(1, hidden_dim // 4),
            nn.ReLU(),
            nn.Linear(hidden_dim // 4, hidden_dim // 4)
        )
        
        self.bandwidth_encoder = nn.Sequential(
            nn.Linear(1, hidden_dim // 4),
            nn.ReLU(),
            nn.Linear(hidden_dim // 4, hidden_dim // 4)
        )
        
        self.reliability_encoder = nn.Sequential(
            nn.Linear(1, hidden_dim // 4),
            nn.ReLU(),
            nn.Linear(hidden_dim // 4, hidden_dim // 4)
        )
        
        self.load_encoder = nn.Sequential(
            nn.Linear(1, hidden_dim // 4),
            nn.ReLU(),
            nn.Linear(hidden_dim // 4, hidden_dim // 4)
        )
        
        self.condition_fusion = nn.Sequential(
            nn.Linear(hidden_dim, condition_dim),
            nn.ReLU(),
            nn.Linear(condition_dim, condition_dim)
        )
        
    def forward(self, network_condition: NetworkCondition) -> torch.Tensor:
        """Encode network conditions into embedding vector"""
        
        # Normalize inputs
        latency_norm = torch.tensor([network_condition.latency_ms / 10.0])  # Normalize by 10ms
        bandwidth_norm = torch.tensor([network_condition.bandwidth_mbps / 1000.0])  # Normalize by 1Gbps
        reliability_norm = torch.tensor([network_condition.reliability])
        load_norm = torch.tensor([network_condition.load_factor])
        
        # Encode each condition component
        lat_emb = self.latency_encoder(latency_norm.unsqueeze(0))
        bw_emb = self.bandwidth_encoder(bandwidth_norm.unsqueeze(0))
        rel_emb = self.reliability_encoder(reliability_norm.unsqueeze(0))
        load_emb = self.load_encoder(load_norm.unsqueeze(0))
        
        # Fuse condition embeddings
        combined = torch.cat([lat_emb, bw_emb, rel_emb, load_emb], dim=-1)
        condition_embedding = self.condition_fusion(combined)
        
        return condition_embedding.squeeze(0)

class HeterogeneousNodeEncoder(nn.Module):
    """Encoder for heterogeneous node types (vehicles, RSUs, edge servers)"""
    
    def __init__(self, base_feature_dim: int, node_type_dim: int = 16):
        super().__init__()
        self.base_feature_dim = base_feature_dim
        self.node_type_dim = node_type_dim
        
        # Node type embeddings
        self.node_type_embeddings = nn.Embedding(
            num_embeddings=len(NodeType),
            embedding_dim=node_type_dim
        )
        
        # Type-specific feature processors
        self.vehicle_processor = nn.Sequential(
            nn.Linear(base_feature_dim, base_feature_dim),
            nn.ReLU(),
            nn.Linear(base_feature_dim, base_feature_dim)
        )
        
        self.rsu_processor = nn.Sequential(
            nn.Linear(base_feature_dim, base_feature_dim),
            nn.ReLU(), 
            nn.Linear(base_feature_dim, base_feature_dim)
        )
        
        self.edge_server_processor = nn.Sequential(
            nn.Linear(base_feature_dim, base_feature_dim),
            nn.ReLU(),
            nn.Linear(base_feature_dim, base_feature_dim)
        )
        
        self.feature_fusion = nn.Linear(base_feature_dim + node_type_dim, base_feature_dim)
        
    def forward(self, node_features: torch.Tensor, 
                node_types: torch.Tensor) -> torch.Tensor:
        """Process heterogeneous node features"""
        
        batch_size, num_nodes, feature_dim = node_features.shape
        
        # Get node type embeddings
        type_embeddings = self.node_type_embeddings(node_types)  # [B, N, type_dim]
        
        # Process features based on node type
        processed_features = torch.zeros_like(node_features)
        
        for batch_idx in range(batch_size):
            for node_idx in range(num_nodes):
                node_type = node_types[batch_idx, node_idx].item()
                features = node_features[batch_idx, node_idx]
                
                if node_type == NodeType.VEHICLE.value:
                    processed_features[batch_idx, node_idx] = self.vehicle_processor(features)
                elif node_type == NodeType.RSU.value:
                    processed_features[batch_idx, node_idx] = self.rsu_processor(features)
                elif node_type == NodeType.EDGE_SERVER.value:
                    processed_features[batch_idx, node_idx] = self.edge_server_processor(features)
                    
        # Fuse with type embeddings
        combined_features = torch.cat([processed_features, type_embeddings], dim=-1)
        output_features = self.feature_fusion(combined_features)
        
        return output_features

class EnhancedSTGNN(nn.Module):
    """
    Enhanced Heterogeneous Adaptive Spatio-Temporal Graph Neural Network
    
    Key innovations:
    1. Multi-scale spatial convolutions for different interaction ranges
    2. Temporal attention mechanism for sequence modeling
    3. 6G network condition awareness
    4. Heterogeneous node type processing
    5. Dynamic policy adaptation based on network states
    """
    
    def __init__(self, 
                 input_dim: int = 64,
                 hidden_dim: int = 128,
                 output_dim: int = 64,
                 num_layers: int = 4,
                 seq_length: int = 10,
                 num_heads: int = 8):
        super().__init__()
        
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.num_layers = num_layers
        self.seq_length = seq_length
        
        # Input projection
        self.input_projection = nn.Linear(input_dim, hidden_dim)
        
        # Heterogeneous node encoder
        self.node_encoder = HeterogeneousNodeEncoder(hidden_dim)
        
        # 6G network condition encoder
        self.network_encoder = NetworkConditionEncoder(condition_dim=32)
        
        # Multi-scale spatial layers
        self.spatial_layers = nn.ModuleList([
            MultiScaleGraphConvLayer(hidden_dim, hidden_dim)
            for _ in range(num_layers)
        ])
        
        # Spatial attention layers
        self.spatial_attention_layers = nn.ModuleList([
            MultiHeadSpatialAttention(hidden_dim, num_heads)
            for _ in range(num_layers)
        ])
        
        # Temporal processing
        self.temporal_attention = TemporalAttentionLayer(hidden_dim, seq_length)
        
        # Network-aware policy adaptation
        self.policy_adapter = nn.Sequential(
            nn.Linear(hidden_dim + 32, hidden_dim),  # +32 for network condition
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)
        )
        
        # Output projection
        self.output_projection = nn.Linear(hidden_dim, output_dim)
        
        # Dropout for regularization
        self.dropout = nn.Dropout(0.1)
        
    def forward(self, 
                node_features: torch.Tensor,
                edge_index: torch.Tensor,
                edge_attr: torch.Tensor,
                node_types: torch.Tensor,
                network_condition: NetworkCondition,
                temporal_history: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Forward pass of Enhanced ST-GNN
        
        Args:
            node_features: [batch_size, num_nodes, input_dim]
            edge_index: [2, num_edges] - graph connectivity
            edge_attr: [num_edges, edge_feature_dim] - edge attributes (distance, etc.)
            node_types: [batch_size, num_nodes] - node type indices
            network_condition: Current 6G network conditions
            temporal_history: [batch_size, seq_length, num_nodes, input_dim] - optional temporal history
            
        Returns:
            output_features: [batch_size, num_nodes, output_dim]
            attention_weights: Dictionary of attention weights for analysis
        """
        
        # Input projection
        x = self.input_projection(node_features)
        batch_size, num_nodes, _ = x.shape
        
        # Heterogeneous node encoding
        x = self.node_encoder(x, node_types)
        
        # Encode 6G network conditions
        network_embedding = self.network_encoder(network_condition)
        network_embedding = network_embedding.unsqueeze(0).unsqueeze(0).expand(
            batch_size, num_nodes, -1
        )
        
        attention_weights = {}
        
        # Multi-layer spatial processing with attention
        for layer_idx, (spatial_layer, attention_layer) in enumerate(
            zip(self.spatial_layers, self.spatial_attention_layers)
        ):
            # Multi-scale spatial convolution
            x = spatial_layer(x, edge_index, edge_attr)
            x = self.dropout(x)
            
            # Spatial attention
            x = attention_layer(x, edge_index)
            
            # Store attention weights for analysis
            attention_weights[f'spatial_layer_{layer_idx}'] = x.clone().detach()
            
        # Temporal processing if history is available
        if temporal_history is not None:
            # Combine current features with temporal history
            current_expanded = x.unsqueeze(1)  # [B, 1, N, F]
            temporal_input = torch.cat([temporal_history, current_expanded], dim=1)
            
            # Apply temporal attention
            temporal_output = self.temporal_attention(temporal_input)
            
            # Use the latest temporal state
            x = temporal_output[:, -1, :, :]  # [B, N, F]
            
            attention_weights['temporal'] = temporal_output.clone().detach()
            
        # Network-aware policy adaptation
        x_with_network = torch.cat([x, network_embedding], dim=-1)
        adapted_features = self.policy_adapter(x_with_network)
        
        # Final output projection
        output = self.output_projection(x)
        
        return output, attention_weights
        
    def get_emergent_coordination_policy(self, 
                                       graph_state: torch.Tensor,
                                       network_condition: NetworkCondition) -> torch.Tensor:
        """
        Generate emergent coordination policy based on current graph state and network conditions
        
        This implements the paper's concept of "emergent, efficient coordination policies 
        that dynamically adjust to 6G network conditions"
        """
        
        # Encode current network state
        network_emb = self.network_encoder(network_condition)
        
        # Policy adaptation based on network conditions
        if network_condition.slice_type == "uRLLC":
            # Ultra-reliable low-latency: prioritize safety and immediate response
            policy_weights = torch.tensor([1.0, 0.3, 0.8])  # [safety, efficiency, coordination]
        else:  # eMBB
            # Enhanced mobile broadband: prioritize throughput and coordination
            policy_weights = torch.tensor([0.7, 1.0, 1.0])  # [safety, efficiency, coordination]
            
        # Adjust policy based on network load
        load_factor = network_condition.load_factor
        if load_factor > 0.8:  # High load
            policy_weights[1] *= 0.5  # Reduce efficiency focus
            policy_weights[0] *= 1.5  # Increase safety focus
            
        # Generate adaptive policy
        policy_input = torch.cat([
            graph_state.mean(dim=1),  # Global graph state
            network_emb.unsqueeze(0)
        ], dim=-1)
        
        adaptive_policy = self.policy_adapter(policy_input)
        
        # Apply policy weights
        weighted_policy = adaptive_policy * policy_weights.unsqueeze(0)
        
        return weighted_policy
        
    def initialize_hidden_state(self, batch_size: int, num_nodes: int, device: str = 'cpu') -> torch.Tensor:
        """Initialize hidden state for temporal processing"""
        return torch.zeros(
            batch_size, self.seq_length, num_nodes, self.hidden_dim,
            device=device
        ) 