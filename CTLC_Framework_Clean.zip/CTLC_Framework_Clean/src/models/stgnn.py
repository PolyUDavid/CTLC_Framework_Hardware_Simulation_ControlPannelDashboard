import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv

from src.utils.config import Config

class STGNN(nn.Module):
    """
    Spatio-Temporal Graph Neural Network (ST-GNN) for heterogeneous data fusion.
    
    Mathematical formulation from paper:
    h_i^(l+1) = UPDATE^(l)(h_i^(l), AGGREGATE^(l)({m_ji : j ∈ N(i)}))
    
    Where:
    - h_i^(l) is the hidden state of node i at layer l
    - N(i) is the neighborhood of node i (connected vehicles/RSUs)
    - m_ji is the message from node j to node i
    - UPDATE and AGGREGATE are learnable functions
    
    The ST-GNN handles heterogeneous sensor data (FPV, LiDAR, vehicle dynamics)
    and learns permutation-invariant representations for V2V/V2I communication.
    
    Architecture: Multi-Modal Encoders → GCN Spatial Fusion → GRU Temporal Processing
    """
    def __init__(self, feature_size, hidden_size, output_size):
        super(STGNN, self).__init__()
        
        # Spatial feature extraction using Graph Convolutional Networks
        self.gcn1 = GCNConv(feature_size, hidden_size)
        self.gcn2 = GCNConv(hidden_size, hidden_size)
        
        # Temporal feature extraction using a GRU
        # The GRU processes the time-series of aggregated graph embeddings
        self.gru = nn.GRU(hidden_size, output_size)

    def forward(self, data, h_prev):
        """
        Forward pass for the ST-GNN.

        Args:
            data (torch_geometric.data.Data): The graph data object from GraphBuilder.
                                              It contains node features (x) and edge index.
            h_prev (torch.Tensor): The previous hidden state of the GRU.
                                   Shape: (1, num_nodes, output_size)

        Returns:
            Tuple[torch.Tensor, torch.Tensor]:
                - gnn_output (torch.Tensor): The final embeddings for each node.
                                             Shape: (num_nodes, output_size)
                - h_t (torch.Tensor): The new hidden state of the GRU.
                                      Shape: (1, num_nodes, output_size)
        """
        x, edge_index = data.x, data.edge_index

        # Apply GCN layers for spatial message passing
        # This allows each vehicle to get information from its neighbors
        spatial_features = F.relu(self.gcn1(x, edge_index))
        spatial_features = self.gcn2(spatial_features, edge_index)
        
        # The output of the GCN is a single snapshot in time. We need to give it
        # a temporal dimension for the GRU.
        # Reshape to (1, num_nodes, hidden_size) for the GRU
        # The '1' represents a single time step in the sequence.
        gru_input = spatial_features.unsqueeze(0)
        
        # Process the sequence with the GRU
        # h_prev contains the "memory" from the previous time step.
        gnn_output, h_t = self.gru(gru_input, h_prev)
        
        # Squeeze the time dimension from the output
        gnn_output = gnn_output.squeeze(0)
        
        return gnn_output, h_t

    def init_hidden(self, num_nodes):
        """
        Initializes the hidden state of the GRU.
        Should be called at the beginning of each simulation episode.
        
        Args:
            num_nodes (int): The number of nodes (vehicles) in the graph.
        
        Returns:
            torch.Tensor: A zero-initialized tensor for the hidden state.
        """
        return torch.zeros(1, num_nodes, Config.GNN_OUTPUT_SIZE, device=Config.DEVICE)
