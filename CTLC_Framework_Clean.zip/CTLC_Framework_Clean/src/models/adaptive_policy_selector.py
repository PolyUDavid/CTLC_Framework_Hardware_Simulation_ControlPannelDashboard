import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from src.utils.config import Config

class AdaptivePolicySelector(nn.Module):
    """
    6G-Aware Adaptive Policy Selector with mathematical formulation.
    
    Mathematical formulation from paper:
    
    Input: Network conditions [L_m, B_m] (measured latency and bandwidth)
    Output: Adaptive weights [λ_uRLLC, λ_eMBB] ∈ [0,1]²
    
    uRLLC-Dominant Reward:
    R_uRLLC = R_base + λ_uRLLC · R_sync - (1-λ_uRLLC) · C_buffer
    
    eMBB-Dominant Reward:
    R_eMBB = R_base + λ_eMBB · R_explore - (1-λ_eMBB) · C_solo
    
    Where:
    - R_sync: bonus for synchronized maneuvers (low-latency coordination)
    - R_explore: bonus for cooperative perception improvement
    - C_buffer: cost for buffering/delays
    - C_solo: cost for non-cooperative behavior
    
    The selector learns to recognize network states and adapt policy behavior accordingly.
    """
    def __init__(self, input_dim=2, hidden_dim=32, output_dim=2):
        super(AdaptivePolicySelector, self).__init__()
        
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
            nn.Softmax(dim=-1)  # Ensures weights sum to 1
        )
        
    def forward(self, network_conditions):
        """
        Args:
            network_conditions (torch.Tensor): [latency_normalized, bandwidth_normalized]
        
        Returns:
            torch.Tensor: [λ_uRLLC, λ_eMBB] weights in range [0,1]
        """
        return self.network(network_conditions)

class NetworkConditionSimulator:
    """
    Simulates 6G network conditions (uRLLC and eMBB characteristics).
    This provides realistic latency and bandwidth variations that the 
    Adaptive Policy Selector can respond to.
    """
    def __init__(self):
        self.time_step = 0
        self.mode_duration = 0
        self.current_mode = 'mixed'  # 'uRLLC', 'eMBB', or 'mixed'
        self.mode_counter = 0
        
        # 6G Network Parameters (as per 3GPP specifications)
        self.uRLLC_latency_range = (0.1, 1.0)    # 0.1-1ms (6G ultra-low latency)
        self.eMBB_latency_range = (1.0, 5.0)     # 1-5ms (6G enhanced)
        self.uRLLC_bandwidth_range = (100, 500)   # 100-500 Mbps
        self.eMBB_bandwidth_range = (1000, 10000) # 1-10 Gbps (6G target)
        
    def get_current_conditions(self):
        """
        Returns current network conditions based on simulated 6G dynamics.
        
        Returns:
            dict: {'latency': float, 'bandwidth': float, 'mode': str}
        """
        self.time_step += 1
        
        # Change network mode periodically to simulate realistic 6G scenarios
        if self.time_step % 200 == 0:  # Change mode every 200 steps
            modes = ['uRLLC', 'eMBB', 'mixed']
            self.current_mode = np.random.choice(modes, p=[0.3, 0.3, 0.4])
            
        if self.current_mode == 'uRLLC':
            # Ultra-reliable Low Latency Communication
            latency = np.random.uniform(*self.uRLLC_latency_range)
            bandwidth = np.random.uniform(*self.uRLLC_bandwidth_range)
        elif self.current_mode == 'eMBB':
            # Enhanced Mobile Broadband
            latency = np.random.uniform(*self.eMBB_latency_range)
            bandwidth = np.random.uniform(*self.eMBB_bandwidth_range)
        else:  # mixed
            # Mixed conditions
            latency = np.random.uniform(2.0, 15.0)
            bandwidth = np.random.uniform(50, 200)
            
        return {
            'latency': latency,
            'bandwidth': bandwidth,
            'mode': self.current_mode
        }
    
    def normalize_conditions(self, conditions):
        """
        Normalizes network conditions to [0,1] range for neural network input.
        
        Args:
            conditions (dict): Raw network conditions
            
        Returns:
            np.ndarray: [normalized_latency, normalized_bandwidth]
        """
        # Normalize latency (lower is better, so we invert)
        max_latency = 20.0  # ms
        norm_latency = 1.0 - min(conditions['latency'] / max_latency, 1.0)
        
        # Normalize bandwidth (higher is better)
        max_bandwidth = 1000.0  # Mbps
        norm_bandwidth = min(conditions['bandwidth'] / max_bandwidth, 1.0)
        
        return np.array([norm_latency, norm_bandwidth], dtype=np.float32)

class AdaptiveRewardCalculator:
    """
    Calculates adaptive reward functions based on network conditions.
    Implements the uRLLC and eMBB reward formulations from the paper.
    """
    def __init__(self):
        self.network_simulator = NetworkConditionSimulator()
        self.policy_selector = AdaptivePolicySelector().to(Config.DEVICE)
        
    def calculate_adaptive_reward(self, vehicle, action, base_reward):
        """
        Calculates the final reward using adaptive weights from the policy selector.
        
        Args:
            vehicle: The vehicle instance
            action: The action taken
            base_reward: The base reward from normal calculations
            
        Returns:
            float: The final adaptive reward
        """
        # Get current network conditions
        conditions = self.network_simulator.get_current_conditions()
        norm_conditions = self.network_simulator.normalize_conditions(conditions)
        
        # Get adaptive weights from policy selector
        conditions_tensor = torch.FloatTensor(norm_conditions).unsqueeze(0).to(Config.DEVICE)
        with torch.no_grad():
            weights = self.policy_selector(conditions_tensor)
            lambda_uRLLC, lambda_eMBB = weights[0].cpu().numpy()
        
        # Calculate mode-specific reward components
        r_sync = self._calculate_sync_reward(vehicle)
        r_explore = self._calculate_explore_reward(vehicle)
        c_buffer = self._calculate_buffer_cost(vehicle)
        c_solo = self._calculate_solo_cost(vehicle)
        
        # Apply adaptive reward formulation from the paper
        if conditions['mode'] == 'uRLLC' or lambda_uRLLC > 0.6:
            # uRLLC-Dominant Mode: R_uRLLC = R_base + λ_uRLLC * R_sync - (1-λ_uRLLC) * C_buffer
            adaptive_reward = base_reward + lambda_uRLLC * r_sync - (1 - lambda_uRLLC) * c_buffer
        else:
            # eMBB-Dominant Mode: R_eMBB = R_base + λ_eMBB * R_explore - (1-λ_eMBB) * C_solo
            adaptive_reward = base_reward + lambda_eMBB * r_explore - (1 - lambda_eMBB) * c_solo
            
        return adaptive_reward, conditions, (lambda_uRLLC, lambda_eMBB)
    
    def _calculate_sync_reward(self, vehicle):
        """R_sync: Bonus for synchronized maneuvers (uRLLC mode)"""
        # Reward for maintaining consistent speed with nearby vehicles
        nearby_vehicles = self._get_nearby_vehicles(vehicle)
        if not nearby_vehicles:
            return 0.0
            
        speed_variance = np.var([v.speed for v in nearby_vehicles + [vehicle]])
        sync_reward = max(0, 1.0 - speed_variance / 2.0)  # Lower variance = higher reward
        return sync_reward
    
    def _calculate_explore_reward(self, vehicle):
        """R_explore: Bonus for cooperative perception improvement (eMBB mode)"""
        # Reward for actions that improve collective situational awareness
        if not hasattr(vehicle, 'sensor_config'):
            return 0.0
            
        explore_reward = 0.0
        if vehicle.sensor_config.get('fpv', False):
            explore_reward += 0.3  # Contributes visual data
        if vehicle.sensor_config.get('lidar', False):
            explore_reward += 0.4  # Contributes geometric data
            
        # Bonus for being in a position that helps others (e.g., not occluding)
        nearby_vehicles = self._get_nearby_vehicles(vehicle)
        if len(nearby_vehicles) > 0:
            explore_reward += 0.2
            
        return explore_reward
    
    def _calculate_buffer_cost(self, vehicle):
        """C_buffer: Cost for buffering/delays (uRLLC penalty)"""
        # Penalty for actions that might cause delays
        buffer_cost = abs(vehicle.acceleration) * 0.1  # Penalize sudden changes
        return buffer_cost
    
    def _calculate_solo_cost(self, vehicle):
        """C_solo: Cost for non-cooperative behavior (eMBB penalty)"""
        # Penalty for not utilizing cooperative opportunities
        nearby_vehicles = self._get_nearby_vehicles(vehicle)
        if len(nearby_vehicles) == 0:
            return 0.5  # High penalty for isolation when cooperation is available
        return 0.0
    
    def _get_nearby_vehicles(self, vehicle):
        """Helper to find vehicles within communication range"""
        if not hasattr(vehicle, '_sim_manager_ref'):
            return []
            
        nearby = []
        for entity in vehicle._sim_manager_ref.entities:
            if (entity.type == 'vehicle' and entity.id != vehicle.id and 
                np.linalg.norm(vehicle.pos - entity.pos) < Config.COMM_RANGE):
                nearby.append(entity)
        return nearby 