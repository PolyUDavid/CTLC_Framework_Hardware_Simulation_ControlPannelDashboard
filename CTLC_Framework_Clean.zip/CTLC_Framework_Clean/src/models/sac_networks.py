import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal

from src.utils.config import Config

LOG_SIG_MAX = 2
LOG_SIG_MIN = -20
epsilon = 1e-6

class Actor(nn.Module):
    """
    The policy network (Actor) for SAC algorithm.
    
    Mathematical formulation from paper:
    J(θ) = Σ_t E[(s_t,a_t)~ρ_π][r(s_t,a_t) + α H(π_θ(·|s_t))]
    
    Where:
    - π_θ(a|s) is the stochastic policy parameterized by θ
    - α is the temperature parameter controlling exploration
    - H(π_θ(·|s_t)) = -log π_θ(a_t|s_t) is the policy entropy
    
    This corresponds to the "Actor Head" in the paper's heterogeneous backbone.
    """
    def __init__(self, state_dim, action_dim, hidden_dim):
        super(Actor, self).__init__()
        self.linear1 = nn.Linear(state_dim, hidden_dim)
        self.linear2 = nn.Linear(hidden_dim, hidden_dim)
        
        self.mean_linear = nn.Linear(hidden_dim, action_dim)
        self.log_std_linear = nn.Linear(hidden_dim, action_dim)

    def forward(self, state):
        x = F.relu(self.linear1(state))
        x = F.relu(self.linear2(x))
        
        mean = self.mean_linear(x)
        log_std = self.log_std_linear(x)
        log_std = torch.clamp(log_std, min=LOG_SIG_MIN, max=LOG_SIG_MAX)
        
        return mean, log_std

    def sample(self, state):
        """
        Samples an action from the policy distribution and computes the log probability.
        """
        mean, log_std = self.forward(state)
        std = log_std.exp()
        normal = Normal(mean, std)
        
        # Sample action and apply Tanh squashing function for bounded action space
        x_t = normal.rsample()  # for reparameterization trick (enables backprop)
        y_t = torch.tanh(x_t)
        action = y_t
        
        # Compute log probability
        log_prob = normal.log_prob(x_t)
        # Enforcing Action Bound
        log_prob -= torch.log((1 - y_t.pow(2)) + epsilon)
        log_prob = log_prob.sum(1, keepdim=True)
        
        return action, log_prob, torch.tanh(mean)


class Critic(nn.Module):
    """
    The Q-value network (Critic).
    Takes a state and an action and outputs the predicted Q-value.
    This corresponds to the "Critic Head" in the paper's architecture.
    It implements the Double Q-Learning trick with two separate Q-networks.
    """
    def __init__(self, state_dim, action_dim, hidden_dim):
        super(Critic, self).__init__()
        
        # Q1 architecture
        self.linear1_q1 = nn.Linear(state_dim + action_dim, hidden_dim)
        self.linear2_q1 = nn.Linear(hidden_dim, hidden_dim)
        self.linear3_q1 = nn.Linear(hidden_dim, 1)
        
        # Q2 architecture
        self.linear1_q2 = nn.Linear(state_dim + action_dim, hidden_dim)
        self.linear2_q2 = nn.Linear(hidden_dim, hidden_dim)
        self.linear3_q2 = nn.Linear(hidden_dim, 1)

    def forward(self, state, action):
        # Concatenate state and action for input
        xu = torch.cat([state, action], 1)
        
        # Forward pass for Q1
        x1 = F.relu(self.linear1_q1(xu))
        x1 = F.relu(self.linear2_q1(x1))
        q1 = self.linear3_q1(x1)
        
        # Forward pass for Q2
        x2 = F.relu(self.linear1_q2(xu))
        x2 = F.relu(self.linear2_q2(x2))
        q2 = self.linear3_q2(x2)
        
        return q1, q2
