import numpy as np
import math
import torch
from torch_geometric.data import Data

from src.utils.config import Config
from src.simulation.entities import Vehicle, RSU, Pothole

class GraphBuilderAPI:
    """
    API for converting the state of the simulated world into a graph structure
    suitable for input into a Spatio-Temporal Graph Neural Network (ST-GNN).
    This acts as the bridge between the physical simulation and the AI model.
    """
    def __init__(self):
        self.entities = []

    def build_graph_from_state(self, entities):
        """
        Constructs a graph from the current list of entities in the world.

        Args:
            entities (list): A list of all BaseEntity objects in the simulation.

        Returns:
            torch_geometric.data.Data: A PyG Data object representing the state graph,
                                      or None if no vehicles are present.
        """
        self.entities = entities
        vehicles = [e for e in self.entities if isinstance(e, Vehicle)]
        
        if not vehicles:
            return None

        # --- 1. Node Features ---
        # Each node (vehicle) has a feature vector. This is where heterogeneous
        # data is fused, as described in the paper's ST-GNN backbone.
        node_features = [self._get_vehicle_features(v) for v in vehicles]
        x = torch.tensor(node_features, dtype=torch.float32)

        # --- 2. Edge Index and Edge Attributes ---
        # Edges represent the V2V communication network. An edge exists if
        # two vehicles are within communication range.
        edge_indices = []
        vehicle_map = {v.id: i for i, v in enumerate(vehicles)}

        for i, v_i in enumerate(vehicles):
            for j, v_j in enumerate(vehicles):
                if i == j:
                    continue
                dist = np.linalg.norm(v_i.position - v_j.position)
                if dist < Config.COMM_RANGE:
                    edge_indices.append([vehicle_map[v_i.id], vehicle_map[v_j.id]])
        
        if edge_indices:
            edge_index = torch.tensor(edge_indices, dtype=torch.long).t().contiguous()
        else:
            # Correctly handle the case with no edges
            edge_index = torch.empty((2, 0), dtype=torch.long)

        # Create the PyTorch Geometric data object
        graph_data = Data(x=x, edge_index=edge_index)
        
        # Store a mapping from graph index back to vehicle ID for later use
        graph_data.vehicle_ids = [v.id for v in vehicles]
        
        return graph_data

    def _get_vehicle_features(self, vehicle):
        """
        Generates a feature vector for a single vehicle.
        This vector is the input to the ST-GNN for that node.
        """
        # --- Self-State Features ---
        # Normalizing features is crucial for stable NN training
        speed = np.linalg.norm(vehicle.velocity)
        norm_speed = speed / Config.MAX_SPEED
        norm_angle = vehicle.steering_angle / (2 * np.pi) # Normalize angle to [-0.5, 0.5]

        # --- Sensor-based Features (FPV, LiDAR) ---
        # This simulates the "Encoders" part of the paper's model architecture table.
        # A real implementation would have a ViT or PointNet here. We simulate their output.
        
        # FPV-based pothole detection
        fpv_pothole_detected = 0.0
        if vehicle.sensors['camera_fpv']['available']:
            if self._is_pothole_in_fpv(vehicle):
                fpv_pothole_detected = 1.0

        # LiDAR-based nearby vehicle detection
        lidar_front_vehicle_dist = 1.0 # Default to max distance
        if vehicle.sensors['lidar']['available']:
            lidar_front_vehicle_dist = self._get_lidar_distance(vehicle) / Config.LIDAR_RANGE
            
        # --- V2I Features (from RSUs) ---
        rsu_pothole_warning = 0.0
        rsus = [e for e in self.entities if isinstance(e, RSU)]
        if rsus:
            # Assume one RSU for simplicity
            rsu = rsus[0]
            potholes = [e for e in self.entities if isinstance(e, Pothole)]
            # Check if RSU is broadcasting about any pothole this vehicle should know about
            if any(np.linalg.norm(rsu.position - p.position) < 500 for p in potholes): # RSU perception range
                 if np.linalg.norm(vehicle.position - rsu.position) < Config.COMM_RANGE:
                     rsu_pothole_warning = 1.0

        # Assemble the final feature vector
        # The size of this vector MUST match Config.GNN_FEATURE_SIZE
        feature_vector = np.array([
            norm_speed,
            norm_angle,
            vehicle.velocity[0] / Config.MAX_SPEED,  # x velocity
            vehicle.velocity[1] / Config.MAX_SPEED,  # y velocity
            fpv_pothole_detected,
            lidar_front_vehicle_dist,
            rsu_pothole_warning,
            vehicle.position[0] / Config.WIDTH,      # normalized x position
            vehicle.position[1] / Config.HEIGHT,     # normalized y position
            # Pad with zeros to reach GNN_FEATURE_SIZE
            *([0.0] * (Config.GNN_FEATURE_SIZE - 9))
        ])
        
        return feature_vector

    def _is_pothole_in_fpv(self, vehicle):
        """Helper to check if any pothole is within the vehicle's FPV cone."""
        # Use velocity direction as view direction
        if np.linalg.norm(vehicle.velocity) > 0.1:
            vehicle_dir = vehicle.velocity / np.linalg.norm(vehicle.velocity)
        else:
            vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
            
        for entity in self.entities:
            if isinstance(entity, Pothole):
                vec_to_pothole = entity.position - vehicle.position
                dist = np.linalg.norm(vec_to_pothole)
                if 0 < dist < Config.FPV_RANGE:
                    # Check if within FOV
                    dot_product = np.dot(vehicle_dir, vec_to_pothole / dist)
                    if dot_product > math.cos(math.radians(Config.FPV_FOV / 2)):
                        return True
        return False

    def _get_lidar_distance(self, vehicle):
        """Helper to get distance to the nearest vehicle in front using LiDAR."""
        min_dist = Config.LIDAR_RANGE
        
        # Use velocity direction as view direction
        if np.linalg.norm(vehicle.velocity) > 0.1:
            vehicle_dir = vehicle.velocity / np.linalg.norm(vehicle.velocity)
        else:
            vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
            
        for entity in self.entities:
            if isinstance(entity, Vehicle) and entity.id != vehicle.id:
                vec_to_other = entity.position - vehicle.position
                dist = np.linalg.norm(vec_to_other)
                if 0 < dist < min_dist:
                    # Check if the other vehicle is roughly in front
                    if np.dot(vehicle_dir, vec_to_other / dist) > 0.85: # Cosine similarity > 0.85 (approx 30 deg cone)
                        min_dist = dist
        return min_dist

    def _get_lidar_distance(self, vehicle):
        """Helper to get distance to the nearest vehicle in front using LiDAR."""
        min_dist = Config.LIDAR_RANGE
        
        # Use velocity direction as view direction
        if np.linalg.norm(vehicle.velocity) > 0.1:
            vehicle_dir = vehicle.velocity / np.linalg.norm(vehicle.velocity)
        else:
            vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
            
        for entity in self.entities:
            if isinstance(entity, Vehicle) and entity.id != vehicle.id:
                vec_to_other = entity.position - vehicle.position
                dist = np.linalg.norm(vec_to_other)
                if 0 < dist < min_dist:
                    # Check if the other vehicle is roughly in front
                    if np.dot(vehicle_dir, vec_to_other / dist) > 0.85: # Cosine similarity > 0.85 (approx 30 deg cone)
                        min_dist = dist
        return min_dist

    def _get_lidar_distance(self, vehicle):
        """Helper to get distance to the nearest vehicle in front using LiDAR."""
        min_dist = Config.LIDAR_RANGE
        
        # Use velocity direction as view direction
        if np.linalg.norm(vehicle.velocity) > 0.1:
            vehicle_dir = vehicle.velocity / np.linalg.norm(vehicle.velocity)
        else:
            vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
            
        for entity in self.entities:
            if isinstance(entity, Vehicle) and entity.id != vehicle.id:
                vec_to_other = entity.position - vehicle.position
                dist = np.linalg.norm(vec_to_other)
                if 0 < dist < min_dist:
                    # Check if the other vehicle is roughly in front
                    if np.dot(vehicle_dir, vec_to_other / dist) > 0.85: # Cosine similarity > 0.85 (approx 30 deg cone)
                        min_dist = dist
        return min_dist

    def _get_lidar_distance(self, vehicle):
        """Helper to get distance to the nearest vehicle in front using LiDAR."""
        min_dist = Config.LIDAR_RANGE
        
        # Use velocity direction as view direction
        if np.linalg.norm(vehicle.velocity) > 0.1:
            vehicle_dir = vehicle.velocity / np.linalg.norm(vehicle.velocity)
        else:
            vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
            
        for entity in self.entities:
            if isinstance(entity, Vehicle) and entity.id != vehicle.id:
                vec_to_other = entity.position - vehicle.position
                dist = np.linalg.norm(vec_to_other)
                if 0 < dist < min_dist:
                    # Check if the other vehicle is roughly in front
                    if np.dot(vehicle_dir, vec_to_other / dist) > 0.85: # Cosine similarity > 0.85 (approx 30 deg cone)
                        min_dist = dist
        return min_dist

    def _get_lidar_distance(self, vehicle):
        """Helper to get distance to the nearest vehicle in front using LiDAR."""
        min_dist = Config.LIDAR_RANGE
        
        # Use velocity direction as view direction
        if np.linalg.norm(vehicle.velocity) > 0.1:
            vehicle_dir = vehicle.velocity / np.linalg.norm(vehicle.velocity)
        else:
            vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
            
        for entity in self.entities:
            if isinstance(entity, Vehicle) and entity.id != vehicle.id:
                vec_to_other = entity.position - vehicle.position
                dist = np.linalg.norm(vec_to_other)
                if 0 < dist < min_dist:
                    # Check if the other vehicle is roughly in front
                    if np.dot(vehicle_dir, vec_to_other / dist) > 0.85: # Cosine similarity > 0.85 (approx 30 deg cone)
                        min_dist = dist
        return min_dist

    def _get_lidar_distance(self, vehicle):
        """Helper to get distance to the nearest vehicle in front using LiDAR."""
        min_dist = Config.LIDAR_RANGE
        
        # Use velocity direction as view direction
        if np.linalg.norm(vehicle.velocity) > 0.1:
            vehicle_dir = vehicle.velocity / np.linalg.norm(vehicle.velocity)
        else:
            vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
            
        for entity in self.entities:
            if isinstance(entity, Vehicle) and entity.id != vehicle.id:
                vec_to_other = entity.position - vehicle.position
                dist = np.linalg.norm(vec_to_other)
                if 0 < dist < min_dist:
                    # Check if the other vehicle is roughly in front
                    if np.dot(vehicle_dir, vec_to_other / dist) > 0.85: # Cosine similarity > 0.85 (approx 30 deg cone)
                        min_dist = dist
        return min_dist

    def _get_lidar_distance(self, vehicle):
        """Helper to get distance to the nearest vehicle in front using LiDAR."""
        min_dist = Config.LIDAR_RANGE
        
        # Use velocity direction as view direction
        if np.linalg.norm(vehicle.velocity) > 0.1:
            vehicle_dir = vehicle.velocity / np.linalg.norm(vehicle.velocity)
        else:
            vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
            
        for entity in self.entities:
            if isinstance(entity, Vehicle) and entity.id != vehicle.id:
                vec_to_other = entity.position - vehicle.position
                dist = np.linalg.norm(vec_to_other)
                if 0 < dist < min_dist:
                    # Check if the other vehicle is roughly in front
                    if np.dot(vehicle_dir, vec_to_other / dist) > 0.85: # Cosine similarity > 0.85 (approx 30 deg cone)
                        min_dist = dist
        return min_dist

    def _get_lidar_distance(self, vehicle):
        """Helper to get distance to the nearest vehicle in front using LiDAR."""
        min_dist = Config.LIDAR_RANGE
        
        # Use velocity direction as view direction
        if np.linalg.norm(vehicle.velocity) > 0.1:
            vehicle_dir = vehicle.velocity / np.linalg.norm(vehicle.velocity)
        else:
            vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
            
        for entity in self.entities:
            if isinstance(entity, Vehicle) and entity.id != vehicle.id:
                vec_to_other = entity.position - vehicle.position
                dist = np.linalg.norm(vec_to_other)
                if 0 < dist < min_dist:
                    # Check if the other vehicle is roughly in front
                    if np.dot(vehicle_dir, vec_to_other / dist) > 0.85: # Cosine similarity > 0.85 (approx 30 deg cone)
                        min_dist = dist
        return min_dist
