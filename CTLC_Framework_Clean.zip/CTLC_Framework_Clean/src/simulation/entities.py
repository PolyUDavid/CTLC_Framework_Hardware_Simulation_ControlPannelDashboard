import pygame
import numpy as np
import math
import random
from typing import List, Dict, Any, Optional
import uuid

from src.utils.config import Config

class BaseEntity:
    """Base class for all simulation entities."""
    def __init__(self, x: float, y: float):
        self.id = str(uuid.uuid4())[:8]
        self.position = np.array([x, y], dtype=float)
        self.active = True

class Pothole(BaseEntity):
    """Static road hazard that vehicles must avoid."""
    def __init__(self, x: float, y: float, radius: float = 15):
        super().__init__(x, y)
        self.radius = radius
        self.danger_level = random.uniform(0.3, 1.0)

class RSU(BaseEntity):
    """Roadside Unit for V2I communication and infrastructure services."""
    def __init__(self, x: float, y: float, coverage_radius: float = 150):
        super().__init__(x, y)
        self.coverage_radius = coverage_radius
        self.connected_vehicles = set()
        self.data_rate = random.uniform(50, 200)  # Mbps
        self.processing_load = 0.0
        
    def can_communicate_with(self, vehicle_pos: np.ndarray) -> bool:
        """Check if a vehicle is within communication range."""
        distance = np.linalg.norm(self.position - vehicle_pos)
        return distance <= self.coverage_radius
        
    def update_connections(self, vehicles: List['Vehicle']):
        """Update the list of connected vehicles."""
        self.connected_vehicles.clear()
        for vehicle in vehicles:
            if self.can_communicate_with(vehicle.position):
                self.connected_vehicles.add(vehicle.id)
        
        # Simulate processing load based on connected vehicles
        self.processing_load = len(self.connected_vehicles) / 10.0

class Vehicle(BaseEntity):
    """Connected and Automated Vehicle with AI agent and safety systems."""
    
    def __init__(self, x: float, y: float, agent_controller, safety_layer):
        super().__init__(x, y)
        
        # Movement properties - FIXED: Now vehicles move horizontally like normal traffic
        self.velocity = np.array([random.uniform(20, 40), random.uniform(-2, 2)], dtype=float)  # [vx, vy] in pixels/step
        self.max_speed = random.uniform(45, 60)
        self.min_speed = 15
        
        # Direction and lane behavior
        self.target_lane = random.choice([Config.HEIGHT // 3, 2 * Config.HEIGHT // 3])
        self.lane_change_cooldown = 0
        
        # AI and Safety Systems
        self.agent_controller = agent_controller
        self.safety_layer = safety_layer
        
        # Sensor configuration (heterogeneous setup)
        self.sensors = self._configure_sensors()
        
        # Vehicle state
        self.steering_angle = 0.0
        self.acceleration = 0.0
        self.last_action = np.zeros(2)
        
        # Communication
        self.connected_rsus = set()
        self.v2v_neighbors = set()
        
        # Performance tracking
        self.collision_detected = False
        self.emergency_brake_active = False
        
    def _configure_sensors(self) -> Dict[str, Dict[str, Any]]:
        """Configure heterogeneous sensor setup for this vehicle."""
        # Each vehicle gets a random combination of sensors
        sensor_configs = {
            'camera_fpv': {
                'available': random.choice([True, True, False]),  # 66% have FPV camera
                'resolution': random.choice(['720p', '1080p', '4K']),
                'fov': random.uniform(60, 120)  # Field of view in degrees
            },
            'lidar': {
                'available': random.choice([True, False]),  # 50% have LiDAR
                'range': random.uniform(100, 200),  # Detection range in meters
                'points_per_scan': random.choice([64, 128, 256])
            },
            'radar': {
                'available': True,  # All vehicles have basic radar
                'range': random.uniform(150, 250),
                'angular_resolution': random.uniform(1, 3)
            },
            'v2v_comm': {
                'available': True,  # All vehicles have V2V
                'range': Config.COMM_RANGE,
                'data_rate': random.uniform(10, 50)  # Mbps
            }
        }
        return sensor_configs
        
    def update_motion(self, action: np.ndarray, dt: float = 1.0):
        """Update vehicle motion based on agent action - FIXED: Proper horizontal movement with pothole avoidance."""
        if action is not None and len(action) >= 2:
            # Extract acceleration and steering from action
            target_acceleration = action[0] * 5.0  # Scale to reasonable range
            target_steering = action[1] * 0.3      # Steering angle in radians
            
            # Smooth steering and acceleration changes
            self.acceleration = 0.8 * self.acceleration + 0.2 * target_acceleration
            self.steering_angle = 0.7 * self.steering_angle + 0.3 * target_steering
            
            # Update velocity based on acceleration
            self.velocity[0] += self.acceleration * dt
            self.velocity[0] = np.clip(self.velocity[0], self.min_speed, self.max_speed)
            
            # Apply steering (affects lateral velocity)
            self.velocity[1] += self.steering_angle * 2.0
            self.velocity[1] = np.clip(self.velocity[1], -10, 10)  # Limit lateral movement
            
            # Enhanced pothole avoidance logic
            self._apply_pothole_avoidance(dt)
            
            # Lane-keeping behavior (reduced priority when avoiding potholes)
            if not hasattr(self, '_avoiding_pothole') or not self._avoiding_pothole:
                current_y = self.position[1]
                lane_center_distance = abs(current_y - self.target_lane)
                
                if lane_center_distance > 30:  # Too far from lane center
                    lane_correction = (self.target_lane - current_y) * 0.1
                    self.velocity[1] += lane_correction
            
            self.last_action = action.copy()
        
        # Update position - FIXED: Now moves primarily horizontally
        self.position += self.velocity * dt
        
        # Handle screen wrapping - vehicles loop around horizontally
        if self.position[0] > Config.WIDTH + 50:
            self.position[0] = -50
            # Randomize some properties when wrapping
            self.target_lane = random.choice([Config.HEIGHT // 3, 2 * Config.HEIGHT // 3])
            
        # Keep vehicles within vertical bounds
        self.position[1] = np.clip(self.position[1], 50, Config.HEIGHT - 50)
        
        # Reduce steering angle over time for stability
        self.steering_angle *= 0.95
        
    def _apply_pothole_avoidance(self, dt: float):
        """Enhanced pothole avoidance with active steering."""
        from src.simulation.entities import Pothole  # Import here to avoid circular import
        
        # Get all entities from parent simulation (we'll need to pass this info)
        # For now, we'll use a simple detection approach
        self._avoiding_pothole = False
        
        # This method will be enhanced by the safety layer, but we add basic logic here
        # The main avoidance logic will be handled by the safety layer and HOCBF
        
        # Add some defensive lateral movement when emergency braking
        if self.emergency_brake_active:
            # Slight lateral movement to avoid obstacles
            lateral_avoidance = random.choice([-1, 1]) * 3.0  # Random left/right avoidance
            self.velocity[1] += lateral_avoidance * dt
            self._avoiding_pothole = True
        
    def get_sensor_data(self, other_entities: List[BaseEntity]) -> Dict[str, Any]:
        """Collect sensor data from available sensors."""
        sensor_data = {}
        
        # Camera FPV data
        if self.sensors['camera_fpv']['available']:
            # Simulate visual perception of nearby objects
            nearby_objects = []
            for entity in other_entities:
                if entity.id != self.id:
                    distance = np.linalg.norm(entity.position - self.position)
                    if distance < 100:  # Within visual range
                        relative_pos = entity.position - self.position
                        nearby_objects.append({
                            'type': type(entity).__name__,
                            'relative_position': relative_pos.tolist(),
                            'distance': distance
                        })
            sensor_data['camera_fpv'] = nearby_objects
            
        # LiDAR data
        if self.sensors['lidar']['available']:
            # Simulate point cloud detection
            lidar_points = []
            detection_range = self.sensors['lidar']['range']
            for entity in other_entities:
                if entity.id != self.id:
                    distance = np.linalg.norm(entity.position - self.position)
                    if distance < detection_range:
                        # Add some noise to simulate real LiDAR
                        noisy_pos = entity.position + np.random.normal(0, 2, 2)
                        lidar_points.append(noisy_pos.tolist())
            sensor_data['lidar'] = lidar_points
            
        # Vehicle dynamics
        sensor_data['vehicle_dynamics'] = {
            'velocity': self.velocity.tolist(),
            'acceleration': self.acceleration,
            'steering_angle': self.steering_angle,
            'position': self.position.tolist()
        }
        
        return sensor_data
        
    def detect_collision(self, other_entities: List[BaseEntity]) -> bool:
        """Detect potential collisions with other entities."""
        collision_radius = 25  # Vehicle collision radius
        
        for entity in other_entities:
            if entity.id == self.id:
                continue
                
            distance = np.linalg.norm(entity.position - self.position)
            
            if isinstance(entity, Vehicle):
                if distance < collision_radius * 2:
                    self.collision_detected = True
                    return True
            elif isinstance(entity, Pothole):
                if distance < collision_radius + entity.radius:
                    return True
                    
        self.collision_detected = False
        return False
        
    def update_connections(self, rsus: List[RSU], vehicles: List['Vehicle']):
        """Update V2I and V2V connections."""
        # Update RSU connections
        self.connected_rsus.clear()
        for rsu in rsus:
            if rsu.can_communicate_with(self.position):
                self.connected_rsus.add(rsu.id)
                
        # Update V2V connections
        self.v2v_neighbors.clear()
        comm_range = self.sensors['v2v_comm']['range']
        for vehicle in vehicles:
            if vehicle.id != self.id:
                distance = np.linalg.norm(vehicle.position - self.position)
                if distance < comm_range:
                    self.v2v_neighbors.add(vehicle.id)
                    
    def get_communication_info(self) -> Dict[str, Any]:
        """Get current communication status."""
        return {
            'connected_rsus': list(self.connected_rsus),
            'v2v_neighbors': list(self.v2v_neighbors),
            'v2v_range': self.sensors['v2v_comm']['range'],
            'sensor_config': {k: v['available'] for k, v in self.sensors.items()}
        }
