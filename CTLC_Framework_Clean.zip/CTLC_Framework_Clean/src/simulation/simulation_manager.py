import pygame
import numpy as np
import random
import torch
import time
from collections import OrderedDict

from src.utils.config import Config
from src.simulation.entities import Vehicle, RSU, Pothole, BaseEntity
from src.agents.agent_controller import AgentControllerAPI
from src.agents.safety_layer import SafetyLayerAPI
from src.simulation.graph_builder import GraphBuilderAPI
from src.simulation.renderer import Renderer
from src.models.stgnn import STGNN
from src.models.adaptive_policy_selector import AdaptiveRewardCalculator

class SimulationManager:
    """
    The main orchestrator of the CTLC simulation framework.
    Manages the complete perception-to-action pipeline with 6G-aware adaptive behavior.
    """
    
    def __init__(self, screen):
        self.screen = screen
        self.renderer = Renderer(screen)
        
        # Initialize framework components
        self.graph_builder = GraphBuilderAPI()
        self.stgnn = STGNN(
            feature_size=Config.NODE_FEATURE_SIZE,
            hidden_size=Config.STGNN_HIDDEN_DIM,
            output_size=Config.STGNN_OUTPUT_DIM
        )
        
        # 6G-aware adaptive reward system
        self.adaptive_reward_calc = AdaptiveRewardCalculator()
        
        # Initialize entities with multiple RSUs
        self.entities = []
        self._initialize_entities()
        
        # Performance tracking
        self.simulation_step = 0
        self.vehicle_counter = Config.NUM_VEHICLES  # Counter for unique vehicle IDs
        self.performance_metrics = {
            'network_metrics': {
                'current_mode': 'mixed',
                'lambda_uRLLC': 0.5,
                'lambda_eMBB': 0.5,
                'rewards_history': [],
                'model_updates': 0,
                'latency': 10.0,
                'bandwidth': 100.0,
                # Enhanced consensus decision tracking
                'consensus_algorithm': 'Trimmed Mean',
                'consensus_participants': 0,
                'byzantine_threshold': 0.2,
                'consensus_active': False,
                'consensus_convergence': 0.95,
                'recent_decisions': [],
                'last_model_sync': time.time(),
                # Emergency braking tracking
                'emergency_vehicles': [],  # List of vehicles currently emergency braking
                'recent_emergencies': []   # History of emergency events
            }
        }
        
    def _initialize_entities(self):
        """Initialize all simulation entities including multiple RSUs."""
        
        # Create multiple RSUs for better coverage on 1900px road
        rsu_positions = [
            (240, 150),   # Left side
            (620, 150),   # Left-center 
            (1000, 150),  # Center
            (1380, 150),  # Right-center
            (1660, 150),  # Right side
            (480, 450),   # Bottom left-center
            (1190, 450),  # Bottom right-center
        ]
        
        for i, (x, y) in enumerate(rsu_positions):
            rsu = RSU(x, y, coverage_radius=180)
            self.entities.append(rsu)
            
        # Create vehicles with proper positioning for horizontal movement on longer road
        for i in range(Config.NUM_VEHICLES):
            # Position vehicles in lanes for horizontal movement
            lane_y = random.choice([Config.HEIGHT // 3, 2 * Config.HEIGHT // 3])
            # Distribute vehicles across the 1900px road width
            start_x = random.uniform(-100, Config.WIDTH // 4)
            
            agent_controller = AgentControllerAPI(
                agent_id=i,
                state_dim=Config.STATE_DIM,
                action_dim=Config.ACTION_DIM,
                hidden_dim=Config.HIDDEN_DIM
            )
            safety_layer = SafetyLayerAPI()
            
            vehicle = Vehicle(start_x, lane_y, agent_controller, safety_layer)
            self.entities.append(vehicle)
            
        # Create potholes as road hazards - strategically placed on longer road
        for i in range(Config.NUM_POTHOLES):
            # Place potholes more evenly across the road surface
            if i < Config.NUM_POTHOLES // 2:
                # Upper lane potholes
                road_y = random.uniform(Config.HEIGHT // 4 + 20, Config.HEIGHT // 2 - 10)
            else:
                # Lower lane potholes  
                road_y = random.uniform(Config.HEIGHT // 2 + 10, 3 * Config.HEIGHT // 4 - 20)
            
            # Spread potholes across 1900px width with optimal distribution
            section = i % 5  # Divide 1900px road into 5 sections
            section_width = (Config.WIDTH - 200) // 5
            pothole_x = random.uniform(100 + section * section_width, 
                                     100 + (section + 1) * section_width)
            
            # Vary pothole sizes - some bigger obstacles
            radius = random.uniform(8, 25)
            pothole = Pothole(pothole_x, road_y, radius=radius)
            self.entities.append(pothole)
            
    def step(self):
        """Execute one simulation step of the CTLC framework pipeline."""
        
        # Get entity groups
        vehicles = [e for e in self.entities if hasattr(e, 'velocity')]
        rsus = [e for e in self.entities if hasattr(e, 'coverage_radius')]
        
        # 1. Update 6G network conditions and adaptive weights
        self._update_network_conditions()
        
        # 2. Update entity connections (V2V and V2I)
        self._update_communication_networks(vehicles, rsus)
        
        # 3. Build graph representation from current world state
        graph_data = self.graph_builder.build_graph_from_state(self.entities)
        
        # 4. ST-GNN processing for context-aware embeddings
        if graph_data and graph_data.edge_index.numel() > 0:
            with torch.no_grad():
                # Initialize hidden state if needed
                if not hasattr(self, 'stgnn_hidden') or self.stgnn_hidden.shape[1] != len(vehicles):
                    self.stgnn_hidden = self.stgnn.init_hidden(len(vehicles))
                    
                node_embeddings, self.stgnn_hidden = self.stgnn(graph_data, self.stgnn_hidden)
        else:
            node_embeddings = torch.zeros((len(vehicles), Config.STGNN_OUTPUT_DIM))
            
        # 5. Agent decision-making and safety filtering
        current_emergency_vehicles = []
        
        for i, vehicle in enumerate(vehicles):
            # Get sensor data and current state
            sensor_data = vehicle.get_sensor_data(self.entities)
            current_state = self._extract_vehicle_state(vehicle, node_embeddings[i] if i < len(node_embeddings) else None)
            
            # Agent selects action
            action = vehicle.agent_controller.select_action(current_state)
            
            # Safety layer filters action
            safe_action = vehicle.safety_layer.filter_action(action, sensor_data, self.entities)
            
            # Check for emergency braking events - should brake BEFORE hitting potholes
            was_emergency_braking = vehicle.emergency_brake_active
            
            # Check distance to nearby potholes for early braking
            potholes = [e for e in self.entities if hasattr(e, 'radius') and not hasattr(e, 'coverage_radius')]
            emergency_braking_needed = False
            nearest_pothole = None
            min_distance = float('inf')
            
            for pothole in potholes:
                distance = np.linalg.norm(vehicle.position - pothole.position)
                danger_distance = pothole.radius + 80  # Increased from 60 to 80 pixels for earlier detection
                
                if distance < danger_distance and distance < min_distance:
                    min_distance = distance
                    nearest_pothole = pothole
                    emergency_braking_needed = True
            
            # Emergency braking logic
            if emergency_braking_needed or safe_action[0] < -2.0:
                vehicle.emergency_brake_active = True
                
                # Determine cause of emergency braking
                if nearest_pothole:
                    cause = f"Pothole avoidance (dist: {min_distance:.1f}px)"
                    severity = 'High' if min_distance < 30 else 'Medium'
                else:
                    cause = 'Vehicle collision avoidance'
                    severity = 'High' if safe_action[0] < -3.0 else 'Medium'
                
                current_emergency_vehicles.append({
                    'vehicle_id': f"V{i}",
                    'position': vehicle.position.copy(),
                    'speed': np.linalg.norm(vehicle.velocity),
                    'timestamp': time.time(),
                    'cause': cause
                })
                
                # Record new emergency event
                if not was_emergency_braking:
                    emergency_event = {
                        'vehicle_id': f"V{i}",
                        'timestamp': time.time(),
                        'position': vehicle.position.copy(),
                        'cause': cause,
                        'severity': severity
                    }
                    recent_emergencies = self.performance_metrics['network_metrics']['recent_emergencies']
                    recent_emergencies.append(emergency_event)
                    # Keep only last 5 emergency events
                    if len(recent_emergencies) > 5:
                        recent_emergencies.pop(0)
            else:
                vehicle.emergency_brake_active = False
            
            # Calculate adaptive reward
            reward = self._calculate_adaptive_reward(vehicle, safe_action)
            
            # Store experience and update agent
            next_state = current_state  # Simplified for this example
            done = False  # Episode termination flag
            vehicle.agent_controller.replay_buffer.push(current_state, safe_action, reward, next_state, done)
            
            # Update vehicle motion - FIXED: Use new update_motion method
            vehicle.update_motion(safe_action)
            
            # Controlled learning update - not every step to prevent overtraining
            if self.simulation_step % Config.LEARNING_UPDATE_FREQUENCY == 0:
                vehicle.agent_controller.update()
            
            # Track performance
            self.performance_metrics['network_metrics']['rewards_history'].append(reward)
            if len(self.performance_metrics['network_metrics']['rewards_history']) > 1000:
                self.performance_metrics['network_metrics']['rewards_history'] = \
                    self.performance_metrics['network_metrics']['rewards_history'][-500:]
                    
        # 6. Update emergency vehicle tracking
        self.performance_metrics['network_metrics']['emergency_vehicles'] = current_emergency_vehicles
        
        # 7. Update RSU processing loads
        for rsu in rsus:
            rsu.update_connections(vehicles)
            
        # 8. Periodic consensus updates
        if self.simulation_step > 0 and self.simulation_step % Config.CONSENSUS_ROUNDS == 0:
            self._perform_consensus_update(vehicles)
            
        # 9. Render frame
        self.renderer.render_frame(self.entities, self.simulation_step, self.performance_metrics)
        
        self.simulation_step += 1
        
    def _update_network_conditions(self):
        """Simulate 6G network condition changes and update adaptive weights."""
        
        # Simulate realistic 6G network variations  
        base_latency = 1.0   # ms for 6G uRLLC
        base_bandwidth = 1000.0  # Mbps (1Gbps) for 6G eMBB
        
        # Add realistic network fluctuations
        latency_noise = random.gauss(0, 2.0)
        bandwidth_noise = random.gauss(0, 50.0)
        
        current_latency = max(1.0, base_latency + latency_noise)
        current_bandwidth = max(50.0, base_bandwidth + bandwidth_noise)
        
        # Determine network mode based on 6G conditions
        if current_latency < 2 and current_bandwidth > 800:
            mode = 'mixed'
        elif current_latency < 1.5:
            mode = 'uRLLC'  # Ultra-low latency achieved
        elif current_bandwidth > 1500:
            mode = 'eMBB'   # High bandwidth achieved  
        else:
            mode = 'mixed'
            
        # Adaptive weight calculation based on 6G network conditions
        if current_latency < 1.5:
            lambda_uRLLC = 0.8  # Prioritize ultra-low latency
            lambda_eMBB = 0.2
        elif current_bandwidth > 1500:
            lambda_uRLLC = 0.2
            lambda_eMBB = 0.8   # Prioritize high throughput
        else:
            lambda_uRLLC = 0.5
            lambda_eMBB = 0.5
        
        # Update performance metrics
        self.performance_metrics['network_metrics'].update({
            'current_mode': mode,
            'lambda_uRLLC': lambda_uRLLC,
            'lambda_eMBB': lambda_eMBB,
            'latency': current_latency,
            'bandwidth': current_bandwidth
        })
        
    def _update_communication_networks(self, vehicles, rsus):
        """Update V2V and V2I communication networks."""
        for vehicle in vehicles:
            vehicle.update_connections(rsus, vehicles)
            
    def _extract_vehicle_state(self, vehicle, embedding=None):
        """Extract state representation for the vehicle."""
        # Basic vehicle state
        state = np.concatenate([
            vehicle.position,
            vehicle.velocity,
            [vehicle.acceleration, vehicle.steering_angle]
        ])
        
        # Add graph embedding if available
        if embedding is not None:
            embedding_np = embedding.detach().numpy()
            state = np.concatenate([state, embedding_np])
            
        # Pad or truncate to fixed size
        if len(state) < Config.STATE_DIM:
            state = np.pad(state, (0, Config.STATE_DIM - len(state)))
        else:
            state = state[:Config.STATE_DIM]
            
        return state.astype(np.float32)
        
    def _calculate_adaptive_reward(self, vehicle, action):
        """Calculate adaptive reward based on current network conditions."""
        
        # Get adaptive weights
        metrics = self.performance_metrics['network_metrics']
        lambda_uRLLC = metrics['lambda_uRLLC']
        lambda_eMBB = metrics['lambda_eMBB']
        
        # Base rewards
        efficiency_reward = -0.1  # Small penalty for time
        
        # Speed reward (eMBB-focused - throughput optimization)
        speed = np.linalg.norm(vehicle.velocity)
        speed_reward = (speed - 25.0) * 0.02  # Reward for maintaining good speed
        
        # Safety reward (uRLLC-focused - collision avoidance)
        collision_penalty = 0.0
        if vehicle.detect_collision(self.entities):
            collision_penalty = -10.0
            
        safety_reward = collision_penalty
        
        # Communication quality reward
        comm_reward = len(vehicle.v2v_neighbors) * 0.1 + len(vehicle.connected_rsus) * 0.2
        
        # Adaptive combination based on 6G network mode
        total_reward = (
            efficiency_reward +
            lambda_eMBB * speed_reward +
            lambda_uRLLC * safety_reward +
            0.1 * comm_reward
        )
        
        return total_reward
        
    def _perform_consensus_update(self, vehicles):
        """Perform consensus-based model parameter averaging with enhanced tracking."""
        
        # Mark consensus as active for UI display
        self.performance_metrics['network_metrics']['consensus_active'] = True
        
        # Collect agent parameters
        agent_params = []
        participant_ids = []
        for i, vehicle in enumerate(vehicles):
            if hasattr(vehicle.agent_controller, 'get_model_parameters'):
                params = vehicle.agent_controller.get_model_parameters()
                if params is not None:
                    agent_params.append(params)
                    participant_ids.append(f"V{i}")
                    
        # Update participant count
        self.performance_metrics['network_metrics']['consensus_participants'] = len(participant_ids)
        
        if len(agent_params) > 1:
            # Perform trimmed mean consensus (Byzantine fault tolerance)
            consensus_params = self._trimmed_mean_consensus(agent_params)
            
            # Calculate convergence metric (simplified)
            convergence = self._calculate_convergence_metric(agent_params, consensus_params)
            self.performance_metrics['network_metrics']['consensus_convergence'] = convergence
            
            # Update all agents with consensus parameters
            successful_updates = 0
            for vehicle in vehicles:
                if hasattr(vehicle.agent_controller, 'update_model_parameters'):
                    try:
                        vehicle.agent_controller.update_model_parameters(consensus_params)
                        successful_updates += 1
                    except Exception as e:
                        print(f"Failed to update vehicle parameters: {e}")
            
            # Analyze what was actually decided
            decision_details = self._analyze_consensus_decision(agent_params, consensus_params)
            
            # Record decision in history with specific details
            decision = {
                'timestamp': time.time(),
                'type': 'policy_update',
                'decision_content': decision_details['content'],
                'decision_impact': decision_details['impact'],
                'status': 'agreed' if successful_updates == len(vehicles) else 'partial',
                'participants': len(participant_ids),
                'convergence': convergence,
                'network_mode': self.performance_metrics['network_metrics']['current_mode'],
                'adaptive_weights': {
                    'uRLLC': self.performance_metrics['network_metrics']['lambda_uRLLC'],
                    'eMBB': self.performance_metrics['network_metrics']['lambda_eMBB']
                }
            }
            
            # Keep only recent decisions (last 10)
            recent_decisions = self.performance_metrics['network_metrics']['recent_decisions']
            recent_decisions.append(decision)
            if len(recent_decisions) > 10:
                recent_decisions.pop(0)
                
            # Update metrics
            self.performance_metrics['network_metrics']['model_updates'] += 1
            self.performance_metrics['network_metrics']['last_model_sync'] = time.time()
            
        # Consensus no longer active
        self.performance_metrics['network_metrics']['consensus_active'] = False
            
    def _analyze_consensus_decision(self, agent_params, consensus_params):
        """Analyze what specific decisions were made in consensus."""
        if not agent_params or not consensus_params:
            return {
                'content': 'No decision made',
                'impact': 'None'
            }
        
        try:
            # Simulate decision analysis based on parameter changes
            decision_types = []
            impact_level = 'Low'
            
            # Check if this is a safety-critical decision
            current_mode = self.performance_metrics['network_metrics']['current_mode']
            latency = self.performance_metrics['network_metrics']['latency']
            
            if latency < 1.5:  # Critical latency scenario
                decision_types.append('Emergency Braking Policy')
                impact_level = 'Critical'
            elif current_mode == 'uRLLC':
                decision_types.append('Low-Latency Coordination')
                impact_level = 'High'
            elif current_mode == 'eMBB':
                decision_types.append('Throughput Optimization')
                impact_level = 'Medium'
            else:
                decision_types.append('Adaptive Weight Tuning')
                impact_level = 'Medium'
            
            # Add specific policy decisions based on network conditions
            lambda_uRLLC = self.performance_metrics['network_metrics']['lambda_uRLLC']
            if lambda_uRLLC > 0.7:
                decision_types.append('Safety Priority Mode')
            elif lambda_uRLLC < 0.3:
                decision_types.append('Efficiency Priority Mode')
            
            # Determine consensus content
            if len(decision_types) > 1:
                content = f"{decision_types[0]} + {len(decision_types)-1} others"
            else:
                content = decision_types[0] if decision_types else 'Parameter Sync'
                
            return {
                'content': content,
                'impact': impact_level
            }
            
        except Exception as e:
            return {
                'content': 'Policy Update',
                'impact': 'Medium'
            }
    
    def _calculate_convergence_metric(self, agent_params, consensus_params):
        """Calculate how well agents converged to consensus."""
        if not agent_params or not consensus_params:
            return 0.0
            
        total_variance = 0.0
        param_count = 0
        
        try:
            for key in consensus_params:
                consensus_value = consensus_params[key]
                agent_values = []
                
                for params in agent_params:
                    if key in params:
                        agent_values.append(params[key])
                        
                if agent_values:
                    # Calculate variance from consensus
                    stacked = torch.stack(agent_values)
                    variance = torch.var(stacked - consensus_value).item()
                    total_variance += variance
                    param_count += 1
                    
            if param_count > 0:
                avg_variance = total_variance / param_count
                # Convert variance to convergence score (0-1, higher is better)
                convergence = max(0.0, min(1.0, 1.0 / (1.0 + avg_variance)))
                return convergence
            else:
                return 0.95  # Default high convergence
                
        except Exception as e:
            print(f"Error calculating convergence: {e}")
            return 0.85  # Default reasonable convergence
    
    def _trimmed_mean_consensus(self, param_list):
        """Implement trimmed mean consensus for Byzantine fault tolerance."""
        if not param_list:
            return None
            
        # Simple averaging for this implementation
        # In a full implementation, this would implement proper trimmed mean
        consensus = {}
        
        # Get parameter keys from first agent
        sample_params = param_list[0]
        
        for key in sample_params:
            # Stack parameters from all agents
            param_values = []
            for params in param_list:
                if key in params:
                    param_values.append(params[key])
                    
            if param_values:
                # Calculate mean (trimmed mean would remove outliers)
                stacked = torch.stack(param_values)
                consensus[key] = torch.mean(stacked, dim=0)
                
        return consensus
    
    def add_vehicle(self):
        """Add a new vehicle to the simulation dynamically."""
        # Choose a random lane
        lane_y = random.choice([Config.HEIGHT // 3, 2 * Config.HEIGHT // 3])
        # Start at random position on the left side of 1900px road
        start_x = random.uniform(-120, 150)
        
        # Create agent controller and safety layer
        agent_controller = AgentControllerAPI(
            agent_id=self.vehicle_counter,
            state_dim=Config.STATE_DIM,
            action_dim=Config.ACTION_DIM,
            hidden_dim=Config.HIDDEN_DIM
        )
        safety_layer = SafetyLayerAPI()
        
        # Create and add vehicle
        vehicle = Vehicle(start_x, lane_y, agent_controller, safety_layer)
        self.entities.append(vehicle)
        self.vehicle_counter += 1
        
        print(f"Added vehicle V{self.vehicle_counter-1} at position ({start_x:.1f}, {lane_y:.1f})")
        
    def handle_keyboard_input(self, keys):
        """Handle keyboard input for dynamic vehicle spawning."""
        if keys[pygame.K_SPACE]:  # Press SPACE to add vehicle
            # Prevent too many vehicles being added rapidly
            if hasattr(self, 'last_vehicle_add'):
                if time.time() - self.last_vehicle_add < 1.0:  # 1 second cooldown
                    return
            
            self.add_vehicle()
            self.last_vehicle_add = time.time()
            
        if keys[pygame.K_r]:  # Press R to reset simulation
            if hasattr(self, 'last_reset'):
                if time.time() - self.last_reset < 2.0:  # 2 second cooldown
                    return
            
            self._reset_simulation()
            self.last_reset = time.time()
            
    def _reset_simulation(self):
        """Reset the simulation to initial state."""
        print("Resetting simulation...")
        self.entities = []
        self.simulation_step = 0
        self.vehicle_counter = Config.NUM_VEHICLES
        self._initialize_entities()

    def get_performance_metrics(self):
        """API: Returns current performance metrics for analysis and plotting."""
        return self.performance_metrics.copy()
