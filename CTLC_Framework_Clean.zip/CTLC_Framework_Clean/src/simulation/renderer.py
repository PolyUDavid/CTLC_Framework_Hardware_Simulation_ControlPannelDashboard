import pygame
import numpy as np
import math
from typing import List, Dict, Any

from src.utils.config import Config

class Renderer:
    """Enhanced renderer with beautiful backgrounds and comprehensive API status display."""
    
    def __init__(self, screen):
        self.screen = screen
        self.font_large = pygame.font.Font(None, 32)
        self.font_medium = pygame.font.Font(None, 24)
        self.font_small = pygame.font.Font(None, 18)
        
        # Colors
        self.colors = {
            'grass': (34, 139, 34),         # Forest green
            'road': (64, 64, 64),           # Dark gray
            'road_line': (255, 255, 255),   # White
            'vehicle': (30, 144, 255),      # Dodger blue
            'rsu': (138, 43, 226),          # Blue violet
            'pothole': (139, 69, 19),       # Saddle brown
            'ui_bg': (0, 0, 0, 180),        # Semi-transparent black
            'text': (255, 255, 255),        # White
            'success': (0, 255, 0),         # Green
            'warning': (255, 165, 0),       # Orange
            'error': (255, 0, 0),           # Red
            'sky': (135, 206, 235),         # Sky blue
        }
        
        # UI panels
        self.left_panel_width = 250
        self.right_panel_width = 300
        
    def render_frame(self, entities: List, simulation_step: int, performance_metrics: Dict[str, Any]):
        """Render the complete simulation frame with beautiful environment and API status."""
        
        # 1. Draw beautiful background environment
        self._draw_environment()
        
        # 2. Draw road infrastructure
        self._draw_road_system()
        
        # 3. Draw simulation entities
        self._draw_entities(entities)
        
        # 4. Draw communication networks
        self._draw_communication_networks(entities)
        
        # 5. Draw left panel - API status
        self._draw_left_api_panel(performance_metrics)
        
        # 6. Draw right panel - training and system status
        self._draw_right_training_panel(simulation_step, performance_metrics)
        
        # 7. Draw main title
        self._draw_main_title()
        
        pygame.display.flip()
        
    def _draw_environment(self):
        """Draw beautiful environmental background with sky and grass."""
        # Sky background
        self.screen.fill(self.colors['sky'])
        
        # Grass areas on both sides of the road
        grass_height = Config.HEIGHT // 4
        
        # Top grass area
        pygame.draw.rect(self.screen, self.colors['grass'], 
                        (0, 0, Config.WIDTH, grass_height))
        
        # Bottom grass area  
        pygame.draw.rect(self.screen, self.colors['grass'], 
                        (0, Config.HEIGHT - grass_height, 
                         Config.WIDTH, grass_height))
        
        # Add some texture to grass with random dots
        for _ in range(50):
            x = np.random.randint(0, Config.WIDTH)
            y1 = np.random.randint(0, grass_height)
            y2 = np.random.randint(Config.HEIGHT - grass_height, Config.HEIGHT)
            
            # Top grass texture
            pygame.draw.circle(self.screen, (20, 120, 20), (x, y1), 2)
            # Bottom grass texture
            pygame.draw.circle(self.screen, (20, 120, 20), (x, y2), 2)
            
    def _draw_road_system(self):
        """Draw the road system with lanes and markings."""
        road_start_y = Config.HEIGHT // 4
        road_height = Config.HEIGHT // 2
        
        # Main road surface
        pygame.draw.rect(self.screen, self.colors['road'], 
                        (0, road_start_y, Config.WIDTH, road_height))
        
        # Lane dividers
        lane_height = road_height // 2
        center_y = road_start_y + lane_height
        
        # Center lane divider (dashed white line)
        dash_length = 30
        dash_gap = 20
        x = 0
        while x < Config.WIDTH:
            pygame.draw.rect(self.screen, self.colors['road_line'], 
                           (x, center_y - 2, dash_length, 4))
            x += dash_length + dash_gap
            
        # Road edges
        pygame.draw.rect(self.screen, self.colors['road_line'], 
                        (0, road_start_y, Config.WIDTH, 3))
        pygame.draw.rect(self.screen, self.colors['road_line'], 
                        (0, road_start_y + road_height - 3, Config.WIDTH, 3))
        
    def _draw_entities(self, entities: List):
        """Draw all simulation entities with improved visuals."""
        vehicles = [e for e in entities if hasattr(e, 'velocity')]
        rsus = [e for e in entities if hasattr(e, 'coverage_radius')]
        potholes = [e for e in entities if hasattr(e, 'radius') and not hasattr(e, 'coverage_radius')]
        
        # Draw RSUs first (background)
        for rsu in rsus:
            self._draw_rsu(rsu, vehicles)
            
        # Draw potholes
        for pothole in potholes:
            self._draw_pothole(pothole)
            
        # Draw vehicles (foreground)
        for vehicle in vehicles:
            self._draw_vehicle(vehicle)
            
    def _draw_vehicle(self, vehicle):
        """Draw a realistic vehicle with enhanced 3D appearance and status indicators."""
        x, y = vehicle.position.astype(int)
        
        # Enhanced vehicle dimensions
        vehicle_width = 50
        vehicle_height = 24
        
        # Vehicle color based on status with more variety
        if vehicle.collision_detected:
            base_color = (220, 50, 50)   # Red for collision
        elif vehicle.emergency_brake_active:
            # Flashing red for emergency braking
            import time
            flash = int(time.time() * 8) % 2  # Flash every 0.125 seconds
            if flash:
                base_color = (255, 50, 50)   # Bright red flash
            else:
                base_color = (255, 140, 0)   # Orange base
        else:
            # Different colors for different vehicles
            vehicle_colors = [
                (30, 144, 255),   # Dodger blue
                (50, 205, 50),    # Lime green  
                (255, 20, 147),   # Deep pink
                (255, 215, 0),    # Gold
                (138, 43, 226),   # Blue violet
                (255, 69, 0),     # Red orange
                (0, 191, 255),    # Deep sky blue
                (50, 255, 50),    # Bright green
                (255, 105, 180),  # Hot pink
                (32, 178, 170)    # Light sea green
            ]
            base_color = vehicle_colors[hash(str(vehicle.id)) % len(vehicle_colors)]
        
        # Main vehicle body with gradient effect
        main_rect = pygame.Rect(x - vehicle_width//2, y - vehicle_height//2, 
                               vehicle_width, vehicle_height)
        
        # Body gradient (simulate 3D effect)
        for i in range(vehicle_height):
            shade_factor = 0.7 + 0.3 * (i / vehicle_height)
            shaded_color = tuple(int(c * shade_factor) for c in base_color)
            body_line = pygame.Rect(x - vehicle_width//2, y - vehicle_height//2 + i, vehicle_width, 1)
            pygame.draw.rect(self.screen, shaded_color, body_line)
        
        # Vehicle outline
        pygame.draw.rect(self.screen, (40, 40, 40), main_rect, 2, border_radius=6)
        
        # Windshield (more realistic)
        windshield_width = vehicle_width // 3
        windshield_height = vehicle_height // 2
        windshield_rect = pygame.Rect(x + vehicle_width//3, y - windshield_height//2,
                                    windshield_width, windshield_height)
        # Gradient windshield
        for i in range(windshield_height):
            alpha = 150 + int(50 * (i / windshield_height))
            windshield_color = (120, 160, 255, alpha)
            pygame.draw.rect(self.screen, windshield_color[:3], 
                           pygame.Rect(x + vehicle_width//3, y - windshield_height//2 + i, windshield_width, 1))
        
        # Side windows
        side_window_rect = pygame.Rect(x - vehicle_width//6, y - vehicle_height//3,
                                     vehicle_width//3, vehicle_height//2)
        pygame.draw.rect(self.screen, (140, 180, 255), side_window_rect, border_radius=2)
        
        # Wheels (more realistic)
        wheel_radius = 6
        wheel_color = (60, 60, 60)
        tire_color = (30, 30, 30)
        
        # Front wheel
        front_wheel_x = x + vehicle_width//2 - 8
        front_wheel_y_top = y - vehicle_height//2 + 2
        front_wheel_y_bottom = y + vehicle_height//2 - 2
        
        pygame.draw.circle(self.screen, tire_color, (front_wheel_x, front_wheel_y_top), wheel_radius)
        pygame.draw.circle(self.screen, wheel_color, (front_wheel_x, front_wheel_y_top), wheel_radius-2)
        pygame.draw.circle(self.screen, tire_color, (front_wheel_x, front_wheel_y_bottom), wheel_radius)
        pygame.draw.circle(self.screen, wheel_color, (front_wheel_x, front_wheel_y_bottom), wheel_radius-2)
        
        # Rear wheel
        rear_wheel_x = x - vehicle_width//2 + 8
        pygame.draw.circle(self.screen, tire_color, (rear_wheel_x, front_wheel_y_top), wheel_radius)
        pygame.draw.circle(self.screen, wheel_color, (rear_wheel_x, front_wheel_y_top), wheel_radius-2)
        pygame.draw.circle(self.screen, tire_color, (rear_wheel_x, front_wheel_y_bottom), wheel_radius)
        pygame.draw.circle(self.screen, wheel_color, (rear_wheel_x, front_wheel_y_bottom), wheel_radius-2)
        
        # Headlights
        headlight_color = (255, 255, 200)
        pygame.draw.circle(self.screen, headlight_color, (x + vehicle_width//2 - 2, y - 6), 3)
        pygame.draw.circle(self.screen, headlight_color, (x + vehicle_width//2 - 2, y + 6), 3)
        
        # Tail lights
        taillight_color = (255, 50, 50)
        pygame.draw.circle(self.screen, taillight_color, (x - vehicle_width//2 + 2, y - 6), 2)
        pygame.draw.circle(self.screen, taillight_color, (x - vehicle_width//2 + 2, y + 6), 2)
        
        # Vehicle ID with better styling
        id_background = pygame.Surface((30, 15), pygame.SRCALPHA)
        pygame.draw.rect(id_background, (0, 0, 0, 180), id_background.get_rect(), border_radius=3)
        self.screen.blit(id_background, (x - 15, y - 40))
        id_text = self.font_small.render(f"V{vehicle.id[:2]}", True, (255, 255, 255))
        self.screen.blit(id_text, (x - 12, y - 38))
        
        # Emergency braking indicator
        if vehicle.emergency_brake_active:
            emergency_bg = pygame.Surface((60, 15), pygame.SRCALPHA)
            pygame.draw.rect(emergency_bg, (255, 0, 0, 200), emergency_bg.get_rect(), border_radius=3)
            self.screen.blit(emergency_bg, (x - 30, y - 60))
            emergency_text = self.font_small.render("[!] EMERGENCY", True, (255, 255, 255))
            self.screen.blit(emergency_text, (x - 28, y - 58))
        
        # Speed indicator with background
        speed = np.linalg.norm(vehicle.velocity)
        speed_bg = pygame.Surface((25, 12), pygame.SRCALPHA)
        pygame.draw.rect(speed_bg, (0, 0, 0, 150), speed_bg.get_rect(), border_radius=2)
        self.screen.blit(speed_bg, (x - 12, y + 28))
        speed_text = self.font_small.render(f"{speed:.0f}", True, (255, 255, 255))
        self.screen.blit(speed_text, (x - 8, y + 30))
        
        # Enhanced sensor indicators with glow effect
        sensor_y_offset = -12
        if vehicle.sensors['camera_fpv']['available']:
            # Camera indicator with glow
            pygame.draw.circle(self.screen, (0, 255, 0, 100), (x - 20, y + sensor_y_offset), 5)
            pygame.draw.circle(self.screen, (0, 255, 0), (x - 20, y + sensor_y_offset), 3)
        if vehicle.sensors['lidar']['available']:
            # LiDAR indicator
            pygame.draw.circle(self.screen, (255, 255, 0, 100), (x - 10, y + sensor_y_offset), 5)
            pygame.draw.circle(self.screen, (255, 255, 0), (x - 10, y + sensor_y_offset), 3)
        if vehicle.sensors['radar']['available']:
            # Radar indicator
            pygame.draw.circle(self.screen, (255, 100, 100, 100), (x, y + sensor_y_offset), 5)
            pygame.draw.circle(self.screen, (255, 100, 100), (x, y + sensor_y_offset), 3)
            
    def _draw_rsu(self, rsu, vehicles):
        """Draw RSU with coverage area and connection indicators."""
        x, y = rsu.position.astype(int)
        
        # Coverage area (semi-transparent)
        coverage_surface = pygame.Surface((rsu.coverage_radius * 2, rsu.coverage_radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(coverage_surface, (*self.colors['rsu'][:3], 30), 
                         (rsu.coverage_radius, rsu.coverage_radius), rsu.coverage_radius)
        self.screen.blit(coverage_surface, (x - rsu.coverage_radius, y - rsu.coverage_radius))
        
        # RSU tower
        tower_width = 25
        tower_height = 40
        tower_rect = pygame.Rect(x - tower_width//2, y - tower_height//2, tower_width, tower_height)
        pygame.draw.rect(self.screen, self.colors['rsu'], tower_rect, border_radius=3)
        
        # Antenna
        pygame.draw.rect(self.screen, self.colors['text'], 
                        (x - 2, y - tower_height//2 - 10, 4, 10))
        
        # RSU ID and status
        id_text = self.font_small.render(f"RSU-{rsu.id[:3]}", True, self.colors['text'])
        self.screen.blit(id_text, (x - 25, y + 25))
        
        load_text = self.font_small.render(f"Load:{rsu.processing_load:.1f}", True, self.colors['text'])
        self.screen.blit(load_text, (x - 30, y + 40))
        
        # Draw connections to vehicles
        for vehicle in vehicles:
            if rsu.can_communicate_with(vehicle.position):
                pygame.draw.line(self.screen, (*self.colors['rsu'][:3], 100), 
                               rsu.position.astype(int), vehicle.position.astype(int), 2)
                
    def _draw_pothole(self, pothole):
        """Draw pothole with enhanced 3D depth effect."""
        x, y = pothole.position.astype(int)
        radius = int(pothole.radius)
        
        # Draw shadow/depth rings for 3D effect
        for i in range(radius, 0, -2):
            depth_factor = (radius - i) / radius
            shadow_color = (
                int(139 * (0.3 + 0.7 * depth_factor)),  # Brown gradient
                int(69 * (0.3 + 0.7 * depth_factor)),
                int(19 * (0.3 + 0.7 * depth_factor))
            )
            pygame.draw.circle(self.screen, shadow_color, (x, y), i)
        
        # Add darker center for depth
        center_radius = max(2, radius // 3)
        pygame.draw.circle(self.screen, (60, 30, 10), (x, y), center_radius)
        
        # Add some texture with small dots for larger potholes
        if radius > 12:
            import random
            for _ in range(3):
                dot_x = x + random.randint(-radius//2, radius//2)
                dot_y = y + random.randint(-radius//2, radius//2)
                pygame.draw.circle(self.screen, (80, 40, 15), (dot_x, dot_y), 1)
        
    def _draw_communication_networks(self, entities):
        """Draw V2V communication networks."""
        vehicles = [e for e in entities if hasattr(e, 'velocity')]
        
        for vehicle in vehicles:
            for neighbor_id in vehicle.v2v_neighbors:
                neighbor = next((v for v in vehicles if v.id == neighbor_id), None)
                if neighbor:
                    # Draw thin line for V2V communication
                    pygame.draw.line(self.screen, (0, 255, 255, 50), 
                                   vehicle.position.astype(int), 
                                   neighbor.position.astype(int), 1)
                    
    def _draw_left_api_panel(self, performance_metrics):
        """Draw enhanced left panel with real-time Adaptive Policy Selector display."""
        panel_rect = pygame.Rect(10, 10, self.left_panel_width, Config.HEIGHT - 20)
        
        # Enhanced semi-transparent background with gradient
        panel_surface = pygame.Surface((self.left_panel_width, Config.HEIGHT - 20), pygame.SRCALPHA)
        # Gradient background effect
        for i in range(self.left_panel_width):
            alpha = int(220 - (i * 50 / self.left_panel_width))
            color = (15 + i//10, 20 + i//10, 35 + i//8, alpha)
            pygame.draw.line(panel_surface, color, (i, 0), (i, Config.HEIGHT - 20))
        
        # Border with glow effect
        pygame.draw.rect(panel_surface, (60, 80, 120, 150), panel_surface.get_rect(), 3, border_radius=12)
        pygame.draw.rect(panel_surface, (100, 140, 200, 100), panel_surface.get_rect(), 1, border_radius=12)
        self.screen.blit(panel_surface, panel_rect.topleft)
        
        y_offset = 25
        
        # Enhanced title with animated glow
        import time
        glow_intensity = int(100 + 50 * abs(np.sin(time.time() * 2)))
        title_color = (100 + glow_intensity//3, 180 + glow_intensity//5, 255)
        
        title = self.font_medium.render("[*] CTLC Framework", True, title_color)
        title_shadow = self.font_medium.render("[*] CTLC Framework", True, (20, 20, 40))
        self.screen.blit(title_shadow, (22, y_offset + 2))
        self.screen.blit(title, (20, y_offset))
        
        # Subtitle with framework info
        subtitle = self.font_small.render("6G-IoT Vehicular Coordination", True, (150, 180, 220))
        self.screen.blit(subtitle, (20, y_offset + 25))
        y_offset += 55
        
        # Real-time system status with animated indicators
        status_title = self.font_medium.render("[>] System Status", True, (200, 220, 255))
        self.screen.blit(status_title, (20, y_offset))
        y_offset += 35
        
        # Enhanced API Components with real-time indicators
        current_time = time.time()
        api_components = [
            ("FDL-GNN Framework", "[>]", self._get_animated_status(current_time, 0.8), (0, 255, 150)),
            ("DDRL Engine", "[+]", self._get_animated_status(current_time, 1.2), (255, 200, 0)),
            ("Safety Layer", "[!]", self._get_animated_status(current_time, 0.6), (255, 100, 100)),
            ("Consensus Proto", "[=]", self._get_animated_status(current_time, 2.0), (150, 255, 150)),
            ("Policy Selector", "[*]", self._get_animated_status(current_time, 1.5), (255, 150, 255)),
            ("Graph Builder", "[#]", self._get_animated_status(current_time, 1.0), (100, 255, 255)),
        ]
        
        for name, icon, status, color in api_components:
            # Component name with icon
            component_text = f"{icon} {name}"
            text_surface = self.font_small.render(component_text, True, self.colors['text'])
            self.screen.blit(text_surface, (20, y_offset))
            
            # Animated status indicator
            status_surface = self.font_small.render(status, True, color)
            self.screen.blit(status_surface, (22, y_offset + 15))
            y_offset += 38
            
        # Adaptive Policy Selector Real-time Display
        y_offset += 15
        if 'network_metrics' in performance_metrics:
            net_metrics = performance_metrics['network_metrics']
            
            # Section header with special styling
            aps_title = self.font_medium.render("[*] Adaptive Policy Selector", True, (255, 180, 255))
            aps_bg = pygame.Surface((self.left_panel_width - 20, 25), pygame.SRCALPHA)
            pygame.draw.rect(aps_bg, (60, 20, 60, 100), aps_bg.get_rect(), border_radius=5)
            self.screen.blit(aps_bg, (15, y_offset - 5))
            self.screen.blit(aps_title, (20, y_offset))
            y_offset += 35
            
            # Current 6G mode with enhanced visualization  
            current_mode = net_metrics.get('current_mode', 'Unknown')
            mode_colors = {
                'uRLLC': (0, 255, 200),   # Cyan for ultra-low latency
                'eMBB': (255, 180, 0),    # Orange for enhanced broadband
                'mixed': (200, 200, 255)  # Light blue for mixed mode
            }
            mode_color = mode_colors.get(current_mode, self.colors['text'])
            
            # Mode display with pulsing effect
            pulse_alpha = int(200 + 55 * np.sin(current_time * 4))
            mode_bg = pygame.Surface((120, 20), pygame.SRCALPHA)
            pygame.draw.rect(mode_bg, (*mode_color[:3], pulse_alpha//4), mode_bg.get_rect(), border_radius=10)
            self.screen.blit(mode_bg, (25, y_offset))
            
            mode_text = f"Mode: {current_mode.upper()}"
            mode_surface = self.font_small.render(mode_text, True, mode_color)
            self.screen.blit(mode_surface, (30, y_offset + 3))
            y_offset += 30
            
            # Real-time adaptive weights with progress visualization
            lambda_uRLLC = net_metrics.get('lambda_uRLLC', 0.5)
            lambda_eMBB = net_metrics.get('lambda_eMBB', 0.5)
            
            # uRLLC weight with progress bar
            weight_text = f"λ_uRLLC: {lambda_uRLLC:.3f}"
            weight_surface = self.font_small.render(weight_text, True, (200, 255, 255))
            self.screen.blit(weight_surface, (25, y_offset))
            
            # Animated progress bar for uRLLC
            bar_x, bar_y = 25, y_offset + 18
            bar_width, bar_height = 140, 10
            
            # Background bar
            pygame.draw.rect(self.screen, (50, 50, 50), (bar_x, bar_y, bar_width, bar_height), border_radius=5)
            
            # Filled portion with gradient effect
            filled_width = int(bar_width * lambda_uRLLC)
            if filled_width > 0:
                for i in range(filled_width):
                    intensity = int(255 * (i / bar_width))
                    color = (0, intensity, 255 - intensity//2)
                    pygame.draw.line(self.screen, color, (bar_x + i, bar_y), (bar_x + i, bar_y + bar_height))
                    
            y_offset += 35
            
            # eMBB weight with progress bar
            weight_text = f"λ_eMBB: {lambda_eMBB:.3f}"
            weight_surface = self.font_small.render(weight_text, True, (255, 200, 100))
            self.screen.blit(weight_surface, (25, y_offset))
            
            # Animated progress bar for eMBB
            bar_y = y_offset + 18
            pygame.draw.rect(self.screen, (50, 50, 50), (bar_x, bar_y, bar_width, bar_height), border_radius=5)
            
            filled_width = int(bar_width * lambda_eMBB)
            if filled_width > 0:
                for i in range(filled_width):
                    intensity = int(255 * (i / bar_width))
                    color = (255 - intensity//3, intensity, 0)
                    pygame.draw.line(self.screen, color, (bar_x + i, bar_y), (bar_x + i, bar_y + bar_height))
                    
            y_offset += 40
            
            # 6G Network Performance Metrics
            net_title = self.font_medium.render("[+] 6G Network Status", True, (100, 255, 200))
            self.screen.blit(net_title, (20, y_offset))
            y_offset += 30
            
            # Latency with real-time color coding
            latency = net_metrics.get('latency', 0)
            latency_color = (0, 255, 0) if latency < 1.0 else (255, 255, 0) if latency < 2.0 else (255, 0, 0)
            latency_text = f"[*] Latency: {latency:.2f}ms"
            latency_surface = self.font_small.render(latency_text, True, latency_color)
            self.screen.blit(latency_surface, (25, y_offset))
            y_offset += 22
            
            # Bandwidth with enhanced display
            bandwidth = net_metrics.get('bandwidth', 0)
            if bandwidth >= 1000:
                bandwidth_display = f"{bandwidth/1000:.1f}Gbps"
                bandwidth_color = (0, 255, 100)  # Green for Gbps
            else:
                bandwidth_display = f"{bandwidth:.0f}Mbps"
                bandwidth_color = (255, 255, 0) if bandwidth > 500 else (255, 100, 0)
                
            bandwidth_text = f"📶 Bandwidth: {bandwidth_display}"
            bandwidth_surface = self.font_small.render(bandwidth_text, True, bandwidth_color)
            self.screen.blit(bandwidth_surface, (25, y_offset))
            y_offset += 22
            
            # Enhanced Consensus Decision Display
            y_offset += 35
            consensus_title = self.font_medium.render("[=] Consensus Decisions", True, (150, 255, 150))
            consensus_bg = pygame.Surface((self.left_panel_width - 20, 25), pygame.SRCALPHA)
            pygame.draw.rect(consensus_bg, (20, 60, 20, 100), consensus_bg.get_rect(), border_radius=5)
            self.screen.blit(consensus_bg, (15, y_offset - 5))
            self.screen.blit(consensus_title, (20, y_offset))
            y_offset += 35
            
            # Consensus algorithm status
            consensus_algo = net_metrics.get('consensus_algorithm', 'Trimmed Mean')
            algo_text = f"[+] Algorithm: {consensus_algo}"
            algo_surface = self.font_small.render(algo_text, True, (200, 255, 200))
            self.screen.blit(algo_surface, (25, y_offset))
            y_offset += 22
            
            # Active participants visualization
            participants = net_metrics.get('consensus_participants', 3)
            byzantine_threshold = net_metrics.get('byzantine_threshold', 0.2)
            max_byzantine = int(participants * byzantine_threshold)
            
            participant_text = f"👥 Participants: {participants}"
            participant_surface = self.font_small.render(participant_text, True, (180, 255, 180))
            self.screen.blit(participant_surface, (25, y_offset))
            y_offset += 18
            
            # Visual representation of participant status
            participant_x = 30
            participant_y = y_offset
            for i in range(min(participants, 8)):  # Show up to 8 participants
                # Participant circle with status color
                if i < participants - max_byzantine:
                    color = (0, 255, 0)  # Green for honest
                    status = "●"
                elif i < participants:
                    color = (255, 255, 0)  # Yellow for potential byzantine
                    status = "●"
                else:
                    color = (100, 100, 100)  # Gray for inactive
                    status = "○"
                
                # Add animation for active consensus
                if net_metrics.get('consensus_active', False):
                    pulse = int(50 + 30 * np.sin(current_time * 6 + i * 0.5))
                    color = tuple(min(255, c + pulse) for c in color)
                
                participant_surface = self.font_small.render(status, True, color)
                self.screen.blit(participant_surface, (participant_x + i * 15, participant_y))
            
            y_offset += 25
            
            # Consensus convergence metrics
            convergence = net_metrics.get('consensus_convergence', 0.95)
            conv_color = (0, 255, 0) if convergence > 0.9 else (255, 255, 0) if convergence > 0.7 else (255, 100, 0)
            conv_text = f"📈 Convergence: {convergence:.3f}"
            conv_surface = self.font_small.render(conv_text, True, conv_color)
            self.screen.blit(conv_surface, (25, y_offset))
            y_offset += 22
            
            # Enhanced Decision timeline with specific content
            decisions = net_metrics.get('recent_decisions', [])
            if decisions:
                decision_text = "🕒 Recent Consensus Decisions:"
                decision_surface = self.font_small.render(decision_text, True, (255, 255, 150))
                self.screen.blit(decision_surface, (25, y_offset))
                y_offset += 20
                
                # Show last 3 decisions with details
                for i, decision in enumerate(decisions[-3:]):
                    if y_offset > Config.HEIGHT - 120:  # Prevent overflow
                        break
                    
                    decision_time = decision.get('timestamp', 0)
                    decision_content = decision.get('decision_content', 'Unknown')
                    decision_impact = decision.get('impact', 'Medium')
                    decision_status = decision.get('status', 'agreed')
                    network_mode = decision.get('network_mode', 'mixed')
                    
                    # Time since decision
                    time_diff = current_time - decision_time
                    if time_diff < 60:
                        time_str = f"{time_diff:.0f}s"
                    else:
                        time_str = f"{time_diff/60:.0f}m"
                    
                    # Impact-based color coding
                    if decision_impact == 'Critical':
                        impact_color = (255, 100, 100)  # Red
                        impact_icon = "[!]"
                    elif decision_impact == 'High':
                        impact_color = (255, 200, 0)    # Orange
                        impact_icon = "[^]"
                    elif decision_impact == 'Medium':
                        impact_color = (100, 255, 100)  # Green
                        impact_icon = "[+]"
                    else:
                        impact_color = (200, 200, 200)  # Gray
                        impact_icon = "[i]"
                    
                    # Status icon
                    status_icon = "✅" if decision_status == 'agreed' else "⚠️"
                    
                    # Decision content display
                    decision_display = f"  {time_str}: {impact_icon} {decision_content[:20]}..."
                    decision_surf = self.font_small.render(decision_display, True, impact_color)
                    self.screen.blit(decision_surf, (25, y_offset))
                    y_offset += 16
                    
                    # Network mode and status
                    mode_display = f"    Mode: {network_mode} {status_icon}"
                    mode_surf = self.font_small.render(mode_display, True, (180, 180, 180))
                    self.screen.blit(mode_surf, (25, y_offset))
                    y_offset += 18
            
            # Model synchronization status
            last_sync = net_metrics.get('last_model_sync', current_time)
            sync_diff = current_time - last_sync
            sync_color = (0, 255, 0) if sync_diff < 10 else (255, 255, 0) if sync_diff < 30 else (255, 100, 0)
            
            if sync_diff < 60:
                sync_text = f"[<>] Last Sync: {sync_diff:.0f}s ago"
            else:
                sync_text = f"[<>] Last Sync: {sync_diff/60:.1f}m ago"
                
            sync_surface = self.font_small.render(sync_text, True, sync_color)
            self.screen.blit(sync_surface, (25, y_offset))
            y_offset += 25
            
            # Emergency Braking Status
            emergency_vehicles = net_metrics.get('emergency_vehicles', [])
            recent_emergencies = net_metrics.get('recent_emergencies', [])
            
            if emergency_vehicles or recent_emergencies:
                y_offset += 10
                emergency_title = self.font_medium.render("[!] Emergency Braking", True, (255, 100, 100))
                emergency_bg = pygame.Surface((self.left_panel_width - 20, 25), pygame.SRCALPHA)
                pygame.draw.rect(emergency_bg, (60, 20, 20, 100), emergency_bg.get_rect(), border_radius=5)
                self.screen.blit(emergency_bg, (15, y_offset - 5))
                self.screen.blit(emergency_title, (20, y_offset))
                y_offset += 35
                
                # Current emergency vehicles
                if emergency_vehicles:
                    current_text = f"[!] Active: {len(emergency_vehicles)} vehicles"
                    current_surface = self.font_small.render(current_text, True, (255, 150, 150))
                    self.screen.blit(current_surface, (25, y_offset))
                    y_offset += 18
                    
                    # Show individual emergency vehicles
                    for emergency in emergency_vehicles[:3]:  # Show up to 3
                        if y_offset > Config.HEIGHT - 60:
                            break
                        vehicle_id = emergency.get('vehicle_id', 'Unknown')
                        speed = emergency.get('speed', 0)
                        cause = emergency.get('cause', 'Unknown')
                        emergency_text = f"  [V] {vehicle_id}: {speed:.1f} m/s"
                        emergency_surf = self.font_small.render(emergency_text, True, (255, 200, 100))
                        self.screen.blit(emergency_surf, (25, y_offset))
                        y_offset += 14
                        
                        # Show cause on next line
                        cause_text = f"    Cause: {cause}"
                        cause_surf = self.font_small.render(cause_text, True, (200, 200, 200))
                        self.screen.blit(cause_surf, (25, y_offset))
                        y_offset += 16
                        
                # Recent emergency events
                if recent_emergencies:
                    y_offset += 5
                    recent_text = "[T] Recent Emergency Events:"
                    recent_surface = self.font_small.render(recent_text, True, (255, 180, 180))
                    self.screen.blit(recent_surface, (25, y_offset))
                    y_offset += 18
                    
                    for emergency in recent_emergencies[-2:]:  # Show last 2
                        if y_offset > Config.HEIGHT - 40:
                            break
                        vehicle_id = emergency.get('vehicle_id', 'Unknown')
                        severity = emergency.get('severity', 'Medium')
                        emergency_time = emergency.get('timestamp', 0)
                        
                        time_diff = current_time - emergency_time
                        if time_diff < 60:
                            time_str = f"{time_diff:.0f}s"
                        else:
                            time_str = f"{time_diff/60:.0f}m"
                            
                        severity_color = (255, 100, 100) if severity == 'High' else (255, 200, 100)
                        event_text = f"  {time_str}: {vehicle_id} - {severity}"
                        event_surf = self.font_small.render(event_text, True, severity_color)
                        self.screen.blit(event_surf, (25, y_offset))
                        y_offset += 16
            
    def _get_animated_status(self, current_time: float, phase_offset: float) -> str:
        """Generate animated status indicators for system components."""
        animation_cycle = current_time + phase_offset
        
        # Cycle through different status indicators
        cycle_position = (animation_cycle * 2) % 4
        
        if cycle_position < 1:
            return "●●● Active"
        elif cycle_position < 2:
            return "●●○ Processing"
        elif cycle_position < 3:
            return "●○○ Updating"
        else:
            return "○○○ Standby"
            
    def _draw_right_training_panel(self, simulation_step: int, performance_metrics: Dict[str, Any]):
        """Draw right panel showing training progress and system status."""
        panel_x = Config.WIDTH - self.right_panel_width - 10
        panel_rect = pygame.Rect(panel_x, 10, self.right_panel_width, Config.HEIGHT - 20)
        
        # Semi-transparent background
        panel_surface = pygame.Surface((self.right_panel_width, Config.HEIGHT - 20), pygame.SRCALPHA)
        pygame.draw.rect(panel_surface, self.colors['ui_bg'], panel_surface.get_rect(), border_radius=10)
        self.screen.blit(panel_surface, panel_rect.topleft)
        
        y_offset = 30
        
        # Title
        title = self.font_medium.render("[*] Training Status", True, self.colors['text'])
        self.screen.blit(title, (panel_x + 10, y_offset))
        y_offset += 40
        
        # Simulation step
        step_text = self.font_small.render(f"Step: {simulation_step}", True, self.colors['text'])
        self.screen.blit(step_text, (panel_x + 10, y_offset))
        y_offset += 25
        
        # Consensus progress explanation
        consensus_progress = (simulation_step % 50) / 50.0
        consensus_text = self.font_small.render("Consensus Progress:", True, self.colors['text'])
        self.screen.blit(consensus_text, (panel_x + 10, y_offset))
        y_offset += 18
        
        # Add explanation
        steps_to_consensus = 50 - (simulation_step % 50)
        explain_text = self.font_small.render(f"({steps_to_consensus} steps to sync)", True, (180, 180, 180))
        self.screen.blit(explain_text, (panel_x + 10, y_offset))
        y_offset += 20
        
        # Progress bar
        bar_width = 200
        bar_height = 15
        bar_rect = pygame.Rect(panel_x + 10, y_offset, bar_width, bar_height)
        pygame.draw.rect(self.screen, (100, 100, 100), bar_rect)
        
        filled_width = int(bar_width * consensus_progress)
        if filled_width > 0:
            filled_rect = pygame.Rect(panel_x + 10, y_offset, filled_width, bar_height)
            pygame.draw.rect(self.screen, self.colors['success'], filled_rect)
            
        y_offset += 35
        
        # Performance metrics
        if 'network_metrics' in performance_metrics:
            net_metrics = performance_metrics['network_metrics']
            
            perf_title = self.font_small.render("[+] Performance Metrics", True, self.colors['text'])
            self.screen.blit(perf_title, (panel_x + 10, y_offset))
            y_offset += 25
            
            if 'rewards_history' in net_metrics and net_metrics['rewards_history']:
                avg_reward = np.mean(net_metrics['rewards_history'][-10:])
                reward_text = self.font_small.render(f"Avg Reward: {avg_reward:.2f}", True, self.colors['text'])
                self.screen.blit(reward_text, (panel_x + 10, y_offset))
                y_offset += 20
                
            # Model training status
            if 'model_updates' in net_metrics:
                updates = net_metrics['model_updates']
                update_text = self.font_small.render(f"Model Updates: {updates}", True, self.colors['text'])
                self.screen.blit(update_text, (panel_x + 10, y_offset))
                y_offset += 20
                
        # Training status explanation
        y_offset += 20
        train_title = self.font_small.render("AI Training Status", True, self.colors['text'])
        self.screen.blit(train_title, (panel_x + 10, y_offset))
        y_offset += 25
        
        # Explain what's being trained and when
        sac_next = Config.LEARNING_UPDATE_FREQUENCY - (simulation_step % Config.LEARNING_UPDATE_FREQUENCY)
        stgnn_next = Config.STGNN_UPDATE_FREQUENCY - (simulation_step % Config.STGNN_UPDATE_FREQUENCY)
        consensus_next = Config.CONSENSUS_ROUNDS - (simulation_step % Config.CONSENSUS_ROUNDS)
        
        training_items = [
            (f"SAC Agent: {sac_next} steps to update", self.colors['success']),
            (f"FDL-GNN Network: {stgnn_next} steps to update", self.colors['success']),
            (f"Consensus Sync: {consensus_next} steps to execute", self.colors['success']),
            ("Safety Layer: Real-time monitoring", self.colors['success']),
        ]
        
        for item, color in training_items:
            item_text = self.font_small.render(item, True, color)
            self.screen.blit(item_text, (panel_x + 10, y_offset))
            y_offset += 18
            
    def _draw_main_title(self):
        """Draw the main title at the top center."""
        title_text = "CTLC Framework: 6G-Aware Vehicular Coordination"
        title_surface = self.font_large.render(title_text, True, self.colors['text'])
        
        # Add background for better readability
        title_bg = pygame.Surface((title_surface.get_width() + 20, title_surface.get_height() + 10), pygame.SRCALPHA)
        pygame.draw.rect(title_bg, (*self.colors['ui_bg'][:3], 200), title_bg.get_rect(), border_radius=5)
        
        title_x = (Config.WIDTH - title_surface.get_width()) // 2
        self.screen.blit(title_bg, (title_x - 10, 5))
        self.screen.blit(title_surface, (title_x, 10))
        
        # Add control instructions
        control_text = "Controls: SPACE = Add Vehicle | R = Reset | ESC = Exit"
        control_surface = self.font_small.render(control_text, True, (200, 200, 200))
        control_x = (Config.WIDTH - control_surface.get_width()) // 2
        
        control_bg = pygame.Surface((control_surface.get_width() + 10, control_surface.get_height() + 5), pygame.SRCALPHA)
        pygame.draw.rect(control_bg, (0, 0, 0, 150), control_bg.get_rect(), border_radius=3)
        
        self.screen.blit(control_bg, (control_x - 5, 45))
        self.screen.blit(control_surface, (control_x, 47))

