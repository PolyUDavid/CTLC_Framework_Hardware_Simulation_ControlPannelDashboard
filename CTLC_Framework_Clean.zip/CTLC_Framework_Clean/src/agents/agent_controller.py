import torch
import torch.optim as optim
import torch.nn.functional as F
import os

from src.models.sac_networks import Actor, Critic
from src.utils.replay_buffer import ReplayBuffer
from src.utils.config import Config

class AgentControllerAPI:
    """
    The main DRL agent controller, implementing the Soft Actor-Critic (SAC) algorithm.
    This class serves as the "brain" for each vehicle, responsible for decision-making
    and learning. It corresponds to the "AgentController" in the proposed architecture.
    """
    def __init__(self, agent_id, state_dim, action_dim, hidden_dim):
        self.agent_id = agent_id
        self.gamma = Config.GAMMA
        self.tau = Config.TAU
        self.alpha = Config.ALPHA
        self.device = Config.DEVICE

        # Create Actor and Critic networks
        self.critic = Critic(state_dim, action_dim, hidden_dim).to(self.device)
        self.critic_target = Critic(state_dim, action_dim, hidden_dim).to(self.device)
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=Config.LEARNING_RATE)

        self.actor = Actor(state_dim, action_dim, hidden_dim).to(self.device)
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=Config.LEARNING_RATE)

        # Replay buffer for this specific agent
        self.replay_buffer = ReplayBuffer(Config.REPLAY_BUFFER_SIZE, state_dim, action_dim)

    def select_action(self, state, evaluate=False):
        """
        API: Selects an action based on the current state (GNN embedding).
        """
        state = torch.FloatTensor(state).to(self.device).unsqueeze(0)
        if evaluate is False:
            action, _, _ = self.actor.sample(state)
        else:
            _, _, action = self.actor.sample(state) # In eval mode, use the deterministic mean
        return action.detach().cpu().numpy()[0]

    def update(self):
        """
        API: Performs a single step of the SAC update.
        This is the core learning logic.
        """
        if len(self.replay_buffer) < Config.BATCH_SIZE:
            return None, None # Not enough samples to train yet

        # Sample a batch from the replay buffer
        state_batch, action_batch, reward_batch, next_state_batch, done_batch = self.replay_buffer.sample(Config.BATCH_SIZE)

        # --- Update Critic ---
        with torch.no_grad():
            next_action, next_log_pi, _ = self.actor.sample(next_state_batch)
            qf1_next_target, qf2_next_target = self.critic_target(next_state_batch, next_action)
            min_qf_next_target = torch.min(qf1_next_target, qf2_next_target) - self.alpha * next_log_pi
            next_q_value = reward_batch + (1 - done_batch) * self.gamma * min_qf_next_target
        
        qf1, qf2 = self.critic(state_batch, action_batch)
        qf1_loss = F.mse_loss(qf1, next_q_value)
        qf2_loss = F.mse_loss(qf2, next_q_value)
        critic_loss = qf1_loss + qf2_loss
        
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # --- Update Actor ---
        pi, log_pi, _ = self.actor.sample(state_batch)
        qf1_pi, qf2_pi = self.critic(state_batch, pi)
        min_qf_pi = torch.min(qf1_pi, qf2_pi)
        
        actor_loss = ((self.alpha * log_pi) - min_qf_pi).mean()
        
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # --- Soft update target networks ---
        for target_param, param in zip(self.critic_target.parameters(), self.critic.parameters()):
            target_param.data.copy_(self.tau * param.data + (1.0 - self.tau) * target_param.data)
            
        return critic_loss.item(), actor_loss.item()
    
    # --- Methods for Consensus-Driven DDRL ---
    
    def get_weights(self):
        """Returns the weights of the actor network for consensus averaging."""
        return self.actor.state_dict()

    def set_weights(self, state_dict):
        """Sets the weights of the actor network from a state dictionary."""
        self.actor.load_state_dict(state_dict)
        
    def get_model_parameters(self):
        """API: Returns model parameters for consensus averaging (legacy compatibility)."""
        return self.actor.state_dict()
    
    def update_model_parameters(self, consensus_params):
        """API: Updates model parameters from consensus averaging (legacy compatibility)."""
        if consensus_params is not None:
            self.actor.load_state_dict(consensus_params)
        
    def save_model(self, path):
        if not os.path.exists(path):
            os.makedirs(path)
        torch.save(self.actor.state_dict(), os.path.join(path, f"actor_{self.agent_id}.pth"))
        torch.save(self.critic.state_dict(), os.path.join(path, f"critic_{self.agent_id}.pth"))

    def load_model(self, path):
        self.actor.load_state_dict(torch.load(os.path.join(path, f"actor_{self.agent_id}.pth")))
        self.critic.load_state_dict(torch.load(os.path.join(path, f"critic_{self.agent_id}.pth")))
        self.critic_target.load_state_dict(self.critic.state_dict())
