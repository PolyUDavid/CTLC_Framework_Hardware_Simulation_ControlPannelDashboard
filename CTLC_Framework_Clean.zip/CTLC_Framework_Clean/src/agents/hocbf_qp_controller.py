#!/usr/bin/env python3
"""
High-Order Control Barrier Function with QP Solver Integration
"""

import numpy as np
import cvxpy as cp
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
import time

@dataclass
class VehicleState:
    position: np.ndarray
    velocity: np.ndarray  
    acceleration: np.ndarray
    heading: float
    timestamp: float

class HOCBFController:
    """HOCBF Controller with QP Integration"""
    
    def __init__(self, vehicle_id: str, safe_distance: float = 10.0):
        self.vehicle_id = vehicle_id
        self.safe_distance = safe_distance
        self.max_acceleration = 3.0
        self.max_deceleration = -5.0
        
        # Performance tracking
        self.solver_performance = {
            'solve_times': [],
            'success_rate': 0.0,
            'total_solves': 0,
            'failed_solves': 0
        }
        
    def solve_safety_qp(self, ego_state: VehicleState, 
                       desired_control: np.ndarray,
                       neighbor_states: List[VehicleState]) -> Tuple[np.ndarray, Dict]:
        """Solve QP for safe control"""
        
        start_time = time.time()
        
        # QP Variables
        u = cp.Variable(1, name="acceleration")
        
        # Objective: minimize deviation from desired control
        objective = cp.Minimize(cp.sum_squares(u - desired_control[0]))
        
        # Constraints
        constraints = [
            u >= self.max_deceleration,
            u <= self.max_acceleration
        ]
        
        # HOCBF collision avoidance constraints
        for neighbor in neighbor_states:
            rel_pos = neighbor.position - ego_state.position
            distance = np.linalg.norm(rel_pos)
            
            if distance < self.safe_distance * 3:
                h = distance**2 - self.safe_distance**2
                if h < self.safe_distance**2:
                    constraints.append(u <= 0)  # Force deceleration when close
        
        # Solve QP
        try:
            problem = cp.Problem(objective, constraints)
            problem.solve(solver=cp.OSQP, verbose=False)
            
            if problem.status == cp.OPTIMAL and u.value is not None:
                safe_control = np.array([u.value]).flatten()  # Ensure 1D array
                success = True
            else:
                safe_control = np.array([self.max_deceleration])
                success = False
                
        except Exception as e:
            # print(f"QP solver error: {e}")  # Debug only
            safe_control = np.array([self.max_deceleration])
            success = False
        
        solve_time = time.time() - start_time
        self.solver_performance['solve_times'].append(solve_time)
        self.solver_performance['total_solves'] += 1
        if not success:
            self.solver_performance['failed_solves'] += 1
            
        if self.solver_performance['total_solves'] > 0:
            self.solver_performance['success_rate'] = (
                (self.solver_performance['total_solves'] - self.solver_performance['failed_solves'])
                / self.solver_performance['total_solves']
            )
        
        control_info = {
            'solve_time': solve_time,
            'solver_success': success,
            'control_modification': abs(safe_control[0] - desired_control[0])
        }
        
        return safe_control, control_info
    
    def get_safety_metrics(self) -> Dict[str, Any]:
        """Get safety performance metrics"""
        
        avg_solve_time = np.mean(self.solver_performance['solve_times'][-100:]) if self.solver_performance['solve_times'] else 0
        
        return {
            'solver_performance': {
                'average_solve_time_ms': avg_solve_time * 1000,
                'success_rate': self.solver_performance['success_rate'],
                'total_solves': self.solver_performance['total_solves']
            }
        }
 