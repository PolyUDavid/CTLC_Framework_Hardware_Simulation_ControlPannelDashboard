#!/usr/bin/env python3
"""
Distributed Model Predictive Control (DMPC) for CTLC Framework
Implements predictive safety layer with distributed optimization
"""

import numpy as np
import torch
import torch.nn as nn
import cvxpy as cp
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
import time

@dataclass
class VehicleState:
    """Enhanced vehicle state for DMPC"""
    position: np.ndarray      # [x, y]
    velocity: np.ndarray      # [vx, vy]
    acceleration: np.ndarray  # [ax, ay]
    heading: float           # rad
    yaw_rate: float         # rad/s
    timestamp: float
    uncertainty: Optional[np.ndarray] = None  # State uncertainty covariance

@dataclass
class PredictionHorizon:
    """Prediction and control horizons"""
    prediction_steps: int = 10    # N_p
    control_steps: int = 5        # N_c
    dt: float = 0.1              # Time step
    
class ConstraintType(Enum):
    """Types of constraints for DMPC"""
    COLLISION_AVOIDANCE = "collision_avoidance"
    SPEED_LIMIT = "speed_limit"
    ACCELERATION_LIMIT = "acceleration_limit"
    LANE_KEEPING = "lane_keeping"
    COMMUNICATION_RANGE = "communication_range"

@dataclass
class DMPCConstraint:
    """DMPC constraint definition"""
    constraint_type: ConstraintType
    parameters: Dict[str, float]
    priority: int = 1  # Higher number = higher priority
    active: bool = True

class VehicleDynamicsModel:
    """Vehicle dynamics model for prediction"""
    
    def __init__(self, dt: float = 0.1):
        self.dt = dt
        
        # Vehicle parameters
        self.wheelbase = 2.7  # meters
        self.max_velocity = 30.0  # m/s
        self.max_acceleration = 3.0  # m/s²
        self.max_deceleration = -5.0  # m/s²
        self.max_steering_angle = np.pi/4  # rad
        
    def predict_state(self, current_state: VehicleState, 
                     control_input: np.ndarray, 
                     steps: int = 1) -> List[VehicleState]:
        """Predict future states using bicycle model"""
        
        predicted_states = []
        state = current_state
        
        for step in range(steps):
            # Extract control inputs: [acceleration, steering_rate]
            a = np.clip(control_input[0], self.max_deceleration, self.max_acceleration)
            delta_rate = control_input[1] if len(control_input) > 1 else 0.0
            
            # Current state variables
            x, y = state.position
            vx, vy = state.velocity
            v = np.sqrt(vx**2 + vy**2)
            theta = state.heading
            
            # Bicycle model dynamics
            # x_dot = v * cos(theta)
            # y_dot = v * sin(theta)
            # v_dot = a
            # theta_dot = (v / wheelbase) * tan(delta)
            
            # Update velocity
            v_new = np.clip(v + a * self.dt, 0, self.max_velocity)
            
            # Update heading (simplified)
            theta_new = theta + state.yaw_rate * self.dt
            
            # Update position
            x_new = x + v_new * np.cos(theta_new) * self.dt
            y_new = y + v_new * np.sin(theta_new) * self.dt
            
            # Create new state
            new_state = VehicleState(
                position=np.array([x_new, y_new]),
                velocity=np.array([v_new * np.cos(theta_new), v_new * np.sin(theta_new)]),
                acceleration=np.array([a, 0.0]),
                heading=theta_new,
                yaw_rate=delta_rate,
                timestamp=state.timestamp + (step + 1) * self.dt
            )
            
            predicted_states.append(new_state)
            state = new_state
            
        return predicted_states
    
    def linearize_dynamics(self, state: VehicleState) -> Tuple[np.ndarray, np.ndarray]:
        """Linearize dynamics around current state for MPC"""
        
        # State: [x, y, v, theta]
        # Control: [a, delta_rate]
        
        x, y = state.position
        vx, vy = state.velocity
        v = np.sqrt(vx**2 + vy**2)
        theta = state.heading
        
        # A matrix (state transition)
        A = np.array([
            [1, 0, np.cos(theta) * self.dt, -v * np.sin(theta) * self.dt],
            [0, 1, np.sin(theta) * self.dt,  v * np.cos(theta) * self.dt],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])
        
        # B matrix (control input)
        B = np.array([
            [0, 0],
            [0, 0],
            [self.dt, 0],
            [0, self.dt]
        ])
        
        return A, B

class DistributedMPCController:
    """Distributed Model Predictive Control for multi-vehicle coordination"""
    
    def __init__(self, 
                 vehicle_id: str,
                 horizon: PredictionHorizon,
                 constraints: List[DMPCConstraint],
                 communication_range: float = 100.0):
        
        self.vehicle_id = vehicle_id
        self.horizon = horizon
        self.constraints = constraints
        self.communication_range = communication_range
        
        # Vehicle dynamics
        self.dynamics = VehicleDynamicsModel(horizon.dt)
        
        # Optimization weights
        self.weights = {
            'tracking': 10.0,      # Reference tracking weight
            'control_effort': 1.0,  # Control effort weight
            'smoothness': 5.0,     # Control smoothness weight
            'safety': 100.0       # Safety constraint weight
        }
        
        # Communication and coordination
        self.neighbor_predictions = {}  # Neighbor predicted trajectories
        self.coordination_variables = {}  # Shared optimization variables
        
        # Performance tracking
        self.solver_stats = {
            'solve_times': [],
            'solver_status': [],
            'cost_values': [],
            'constraint_violations': []
        }
        
    def solve_distributed_mpc(self, 
                            current_state: VehicleState,
                            reference_trajectory: List[VehicleState],
                            neighbor_states: List[VehicleState],
                            neighbor_predictions: Dict[str, List[VehicleState]]) -> Tuple[np.ndarray, Dict]:
        """Solve distributed MPC optimization problem"""
        
        start_time = time.time()
        
        # Store neighbor predictions for coordination
        self.neighbor_predictions = neighbor_predictions
        
        # Decision variables
        # Control inputs: [acceleration, steering_rate] for each control step
        u = cp.Variable((self.horizon.control_steps, 2), name="control_input")
        
        # State predictions: [x, y, v, theta] for each prediction step
        x_pred = cp.Variable((self.horizon.prediction_steps + 1, 4), name="state_prediction")
        
        # Slack variables for soft constraints
        # 为每个预测步骤和每个邻居分配松弛变量
        max_neighbors = max(len(neighbor_states), 1)  # 至少1个
        num_collision_constraints = self.horizon.prediction_steps * max_neighbors
        slack_collision = cp.Variable(num_collision_constraints, nonneg=True, name="slack_collision")
        slack_speed = cp.Variable(self.horizon.prediction_steps, nonneg=True, name="slack_speed")
        
        # Objective function
        cost = 0.0
        
        # 1. Reference tracking cost
        for k in range(self.horizon.prediction_steps):
            if k < len(reference_trajectory):
                ref_state = reference_trajectory[k]
                ref_pos = ref_state.position
                ref_vel = np.linalg.norm(ref_state.velocity)
                
                # Position tracking
                cost += self.weights['tracking'] * cp.sum_squares(x_pred[k+1, :2] - ref_pos)
                # Velocity tracking
                cost += self.weights['tracking'] * cp.sum_squares(x_pred[k+1, 2] - ref_vel)
                
        # 2. Control effort cost
        for k in range(self.horizon.control_steps):
            cost += self.weights['control_effort'] * cp.sum_squares(u[k, :])
            
        # 3. Control smoothness cost
        for k in range(self.horizon.control_steps - 1):
            cost += self.weights['smoothness'] * cp.sum_squares(u[k+1, :] - u[k, :])
            
        # 4. Soft constraint penalty
        cost += self.weights['safety'] * cp.sum(slack_collision)
        cost += self.weights['safety'] * cp.sum(slack_speed)
        
        # Constraints
        constraints = []
        
        # Initial state constraint
        current_state_vector = np.array([
            current_state.position[0],
            current_state.position[1],
            np.linalg.norm(current_state.velocity),
            current_state.heading
        ])
        constraints.append(x_pred[0, :] == current_state_vector)
        
        # Dynamic constraints (linearized)
        A, B = self.dynamics.linearize_dynamics(current_state)
        for k in range(self.horizon.control_steps):
            if k < self.horizon.prediction_steps:
                constraints.append(
                    x_pred[k+1, :] == A @ x_pred[k, :] + B @ u[k, :]
                )
                
        # For remaining prediction steps (beyond control horizon)
        for k in range(self.horizon.control_steps, self.horizon.prediction_steps):
            # Use last control input
            constraints.append(
                x_pred[k+1, :] == A @ x_pred[k, :] + B @ u[-1, :]
            )
            
        # Control input constraints
        for k in range(self.horizon.control_steps):
            # Acceleration limits
            constraints.append(u[k, 0] >= self.dynamics.max_deceleration)
            constraints.append(u[k, 0] <= self.dynamics.max_acceleration)
            # Steering rate limits (simplified)
            constraints.append(u[k, 1] >= -np.pi/4)
            constraints.append(u[k, 1] <= np.pi/4)
            
        # State constraints
        for k in range(1, self.horizon.prediction_steps + 1):
            # Speed limits
            constraints.append(x_pred[k, 2] >= 0)
            constraints.append(x_pred[k, 2] <= self.dynamics.max_velocity + slack_speed[k-1])
            
        # Collision avoidance constraints (distributed coordination)
        self._add_collision_avoidance_constraints(constraints, x_pred, slack_collision, neighbor_states, num_collision_constraints)
        
        # Communication range constraints
        self._add_communication_constraints(constraints, x_pred, neighbor_states)
        
        # Solve optimization problem
        objective = cp.Minimize(cost)
        problem = cp.Problem(objective, constraints)
        
        try:
            problem.solve(solver=cp.OSQP, verbose=False, max_iter=4000)
            
            if problem.status == cp.OPTIMAL and u.value is not None:
                optimal_control = u.value[0, :]  # First control action
                optimal_trajectory = x_pred.value
                solver_success = True
                cost_value = problem.value
            else:
                # Fallback: emergency braking
                optimal_control = np.array([self.dynamics.max_deceleration, 0.0])
                optimal_trajectory = None
                solver_success = False
                cost_value = float('inf')
                
        except Exception as e:
            print(f"DMPC solver error: {e}")
            optimal_control = np.array([self.dynamics.max_deceleration, 0.0])
            optimal_trajectory = None
            solver_success = False
            cost_value = float('inf')
            
        # Performance tracking
        solve_time = time.time() - start_time
        self.solver_stats['solve_times'].append(solve_time)
        self.solver_stats['solver_status'].append(problem.status if 'problem' in locals() else 'FAILED')
        self.solver_stats['cost_values'].append(cost_value)
        
        # Control info
        control_info = {
            'solve_time': solve_time,
            'solver_success': solver_success,
            'optimal_cost': cost_value,
            'predicted_trajectory': optimal_trajectory,
            'constraint_violations': self._check_constraint_violations(optimal_trajectory, neighbor_states)
        }
        
        return optimal_control, control_info
        
    def _add_collision_avoidance_constraints(self, constraints: List, x_pred, slack_collision, neighbor_states: List[VehicleState], num_collision_constraints):
        """Add distributed collision avoidance constraints (DCP compliant)"""
        
        safe_distance = 5.0  # meters
        
        for k in range(1, self.horizon.prediction_steps + 1):
            for i, neighbor in enumerate(neighbor_states):
                neighbor_id = getattr(neighbor, 'vehicle_id', 'unknown')
                
                # Use predicted trajectory if available
                if neighbor_id in self.neighbor_predictions and len(self.neighbor_predictions[neighbor_id]) > k-1:
                    neighbor_pos = self.neighbor_predictions[neighbor_id][k-1].position
                else:
                    # Use constant velocity model prediction
                    dt_pred = k * self.horizon.dt
                    neighbor_pos = neighbor.position + neighbor.velocity * dt_pred
                
                # 简化的线性碰撞避免约束 (DCP compliant)
                # 使用曼哈顿距离近似代替欧几里得距离
                constraint_idx = (k-1) * len(neighbor_states) + i
                if constraint_idx < num_collision_constraints:
                    # x方向安全距离约束
                    constraints.append(x_pred[k, 0] - neighbor_pos[0] >= safe_distance - slack_collision[constraint_idx])
                    constraints.append(neighbor_pos[0] - x_pred[k, 0] >= safe_distance - slack_collision[constraint_idx])
                    
                    # y方向安全距离约束
                    constraints.append(x_pred[k, 1] - neighbor_pos[1] >= safe_distance - slack_collision[constraint_idx])
                    constraints.append(neighbor_pos[1] - x_pred[k, 1] >= safe_distance - slack_collision[constraint_idx])
                    
    def _add_communication_constraints(self, constraints: List, x_pred, neighbor_states: List[VehicleState]):
        """Add communication range constraints for coordination (DCP compliant)"""
        
        # 使用线性化的通信约束而不是圆形约束
        if not neighbor_states:
            return
            
        for k in range(1, self.horizon.prediction_steps + 1):
            # 确保与至少一个邻居保持通信距离
            # 使用线性约束近似
            for neighbor in neighbor_states:
                neighbor_pos = neighbor.position
                
                # 线性化通信约束: |x - x_neighbor| + |y - y_neighbor| <= sqrt(2) * comm_range
                # 这是对圆形约束的线性近似
                constraints.append(x_pred[k, 0] - neighbor_pos[0] <= self.communication_range)
                constraints.append(neighbor_pos[0] - x_pred[k, 0] <= self.communication_range)
                constraints.append(x_pred[k, 1] - neighbor_pos[1] <= self.communication_range)
                constraints.append(neighbor_pos[1] - x_pred[k, 1] <= self.communication_range)
                
    def _check_constraint_violations(self, trajectory, neighbor_states: List[VehicleState]) -> Dict[str, int]:
        """Check for constraint violations in the solution"""
        
        violations = {
            'collision': 0,
            'speed': 0,
            'acceleration': 0,
            'communication': 0
        }
        
        if trajectory is None:
            return violations
            
        safe_distance = 5.0
        
        for k in range(1, min(len(trajectory), self.horizon.prediction_steps + 1)):
            state_k = trajectory[k]
            
            # Speed violations
            if state_k[2] > self.dynamics.max_velocity:
                violations['speed'] += 1
                
            # Collision violations
            for neighbor in neighbor_states:
                distance = np.linalg.norm(state_k[:2] - neighbor.position)
                if distance < safe_distance:
                    violations['collision'] += 1
                    
        return violations
        
    def get_predicted_trajectory(self, current_state: VehicleState, 
                               control_sequence: np.ndarray) -> List[VehicleState]:
        """Get predicted trajectory for sharing with neighbors"""
        
        if len(control_sequence.shape) == 1:
            # Single control input, repeat for horizon
            control_sequence = np.tile(control_sequence, (self.horizon.prediction_steps, 1))
            
        predicted_states = [current_state]
        state = current_state
        
        for k in range(self.horizon.prediction_steps):
            if k < len(control_sequence):
                control_input = control_sequence[k]
            else:
                control_input = control_sequence[-1]  # Use last control
                
            next_states = self.dynamics.predict_state(state, control_input, steps=1)
            if next_states:
                state = next_states[0]
                predicted_states.append(state)
                
        return predicted_states[1:]  # Exclude current state
        
    def get_dmpc_metrics(self) -> Dict[str, Any]:
        """Get DMPC performance metrics"""
        
        if not self.solver_stats['solve_times']:
            return {'status': 'no_data'}
            
        return {
            'average_solve_time_ms': np.mean(self.solver_stats['solve_times']) * 1000,
            'solver_success_rate': sum(1 for status in self.solver_stats['solver_status'] 
                                     if status == cp.OPTIMAL) / len(self.solver_stats['solver_status']),
            'average_cost': np.mean([c for c in self.solver_stats['cost_values'] if c != float('inf')]),
            'total_solves': len(self.solver_stats['solve_times']),
            'recent_constraint_violations': self.solver_stats['constraint_violations'][-10:] if self.solver_stats['constraint_violations'] else []
        }
        
    def reset_metrics(self):
        """Reset performance tracking"""
        for key in self.solver_stats:
            self.solver_stats[key].clear() 