import numpy as np
from src.utils.config import Config

class SafetyLayerAPI:
    """
    Implements the HOCBF-inspired safety layer.
    This class acts as a "safety guardian," filtering the actions proposed by the
    DDRL agent to ensure they do not violate critical safety constraints.
    It corresponds to the "SafetyLayer" in the proposed architecture.
    """
    def filter_action(self, action, sensor_data, entities):
        """
        API: Reviews the agent's desired action and overrides it if unsafe.

        Args:
            action (np.ndarray): The action proposed by the AgentController.
            sensor_data (dict): Sensor data from the vehicle.
            entities (list): The list of all entities in the world for state checking.

        Returns:
            np.ndarray: The final, safe action to be executed.
        """
        # Extract vehicle position from sensor data
        vehicle_dynamics = sensor_data.get('vehicle_dynamics', {})
        my_pos = np.array(vehicle_dynamics.get('position', [0, 0]))
        my_velocity = np.array(vehicle_dynamics.get('velocity', [0, 0]))
        
        # --- Enhanced Pothole Avoidance ---
        from src.simulation.entities import Vehicle, Pothole
        
        # Check for potholes first - higher priority than vehicle avoidance
        for entity in entities:
            if isinstance(entity, Pothole):
                distance = np.linalg.norm(my_pos - entity.position)
                # Increased avoidance distance for better visual effect
                avoidance_distance = entity.radius + 45  # Increased from default collision distance
                
                if distance < avoidance_distance:
                    # Calculate direction relative to vehicle movement
                    if np.linalg.norm(my_velocity) > 0.1:
                        vehicle_dir = my_velocity / np.linalg.norm(my_velocity)
                    else:
                        vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
                    
                    vec_to_pothole = entity.position - my_pos
                    
                    # Check if pothole is in front of vehicle's path
                    forward_component = np.dot(vec_to_pothole / (distance + 1e-6), vehicle_dir)
                    
                    if forward_component > 0:  # Pothole is ahead
                        # Determine which side to avoid (left or right)
                        # Use cross product to determine left/right relative to velocity
                        cross_product = vehicle_dir[0] * vec_to_pothole[1] - vehicle_dir[1] * vec_to_pothole[0]
                        
                        # Choose opposite side for avoidance
                        if cross_product > 0:  # Pothole is to the left, steer right
                            avoidance_steering = 0.4
                        else:  # Pothole is to the right, steer left
                            avoidance_steering = -0.4
                        
                        # Scale avoidance based on distance (closer = stronger avoidance)
                        avoidance_strength = max(0.1, (avoidance_distance - distance) / avoidance_distance)
                        avoidance_steering *= avoidance_strength
                        
                        # Apply moderate braking and strong steering
                        safety_action = np.array([
                            max(-3.0, action[0] - 2.0),  # Moderate braking
                            np.clip(action[1] + avoidance_steering, -0.5, 0.5)  # Strong steering avoidance
                        ])
                        
                        return safety_action
        
        # --- Proximity-based Safety (Collision Avoidance) ---
        # This is a simplified proxy for the HOCBF constraint.
        for entity in entities:
            if isinstance(entity, Vehicle):
                dist = np.linalg.norm(my_pos - entity.position)
                
                # Check if the other vehicle is in front of us and too close
                if dist < Config.MIN_SAFE_DIST:
                    # Check direction to see if the threat is in front
                    vec_to_other = entity.position - my_pos
                    
                    # Use velocity direction as vehicle direction
                    if np.linalg.norm(my_velocity) > 0.1:
                        vehicle_dir = my_velocity / np.linalg.norm(my_velocity)
                    else:
                        vehicle_dir = np.array([1.0, 0.0])  # Default forward direction
                    
                    # If the other vehicle is in the forward cone
                    if np.dot(vec_to_other / (dist + 1e-6), vehicle_dir) > 0.5:
                        # HOCBF intervention: Override the action with emergency braking.
                        # We also add a slight random steering to simulate an avoidance maneuver.
                        emergency_action = np.array([Config.EMERGENCY_BRAKE_ACCEL, np.random.uniform(-0.1, 0.1)])
                        return emergency_action
        
        # If no safety constraints are violated, allow the desired action.
        return action

class HOCBFSafetyLayer:
    """
    High-Order Control Barrier Functions (HOCBF) Safety Layer
    Implements consensus-informed predictive safety control
    """
    
    def __init__(self):
        # HOCBF parameters
        self.alpha1 = 1.0  # Class-K function parameter 1
        self.alpha2 = 1.0  # Class-K function parameter 2
        self.safe_distance = 10.0  # Minimum safe distance (meters)
        
        # Vehicle dynamics parameters
        self.max_acceleration = 5.0  # m/s²
        self.max_deceleration = -8.0  # m/s²
        
    def safety_function(self, ego_state, neighbor_states_trusted):
        """
        Safety function h(x) for vehicle coordination
        
        Mathematical formulation:
        h(x_i, x_j) = ||p_i - p_j||² - d_safe²
        
        Where:
        - p_i, p_j are positions of vehicles i and j
        - d_safe is the minimum safe distance
        - h(x) ≥ 0 defines the safe set C
        
        Args:
            ego_state: [x, y, vx, vy] of ego vehicle
            neighbor_states_trusted: List of consensus-validated neighbor states
            
        Returns:
            h_values: Safety function values for each neighbor
        """
        h_values = []
        ego_pos = ego_state[:2]  # [x, y]
        
        for neighbor_state in neighbor_states_trusted:
            neighbor_pos = neighbor_state[:2]  # [x, y]
            
            # Calculate squared distance
            distance_sq = np.sum((ego_pos - neighbor_pos)**2)
            
            # Safety function: h(x) = ||p_i - p_j||² - d_safe²
            h = distance_sq - self.safe_distance**2
            h_values.append(h)
            
        return np.array(h_values)
    
    def safety_function_derivatives(self, ego_state, neighbor_states_trusted):
        """
        Calculate Lie derivatives of safety function
        
        For relative degree 2 system (acceleration control):
        L_f h(x) = ∇h(x) · f(x)
        L_g L_f h(x) = ∇(L_f h(x)) · g(x)
        
        Where:
        - f(x) is the drift dynamics
        - g(x) is the control input matrix
        """
        derivatives = []
        ego_pos = ego_state[:2]
        ego_vel = ego_state[2:4]
        
        for neighbor_state in neighbor_states_trusted:
            neighbor_pos = neighbor_state[:2]
            neighbor_vel = neighbor_state[2:4]
            
            # Relative position and velocity
            rel_pos = ego_pos - neighbor_pos
            rel_vel = ego_vel - neighbor_vel
            
            # First derivative: L_f h(x) = 2 * (p_i - p_j) · (v_i - v_j)
            Lf_h = 2 * np.dot(rel_pos, rel_vel)
            
            # Second derivative: L_f² h(x) = 2 * ||v_i - v_j||² + 2 * (p_i - p_j) · (a_i - a_j)
            # For constant neighbor acceleration (a_j = 0), this simplifies to:
            Lf2_h = 2 * np.dot(rel_vel, rel_vel)
            
            # Control influence: L_g L_f h(x) = 2 * (p_i - p_j) · [1, 0; 0, 1] = 2 * (p_i - p_j)
            LgLf_h = 2 * rel_pos
            
            derivatives.append({
                'Lf_h': Lf_h,
                'Lf2_h': Lf2_h,
                'LgLf_h': LgLf_h
            })
            
        return derivatives
    
    def hocbf_constraint(self, ego_state, neighbor_states_trusted, control_input):
        """
        HOCBF constraint for relative degree 2 system
        
        Mathematical formulation:
        L_f² h(x) + L_g L_f h(x) · u + α₂(L_f h(x) + α₁ h(x)) ≥ 0
        
        This ensures forward invariance of the safe set C = {x | h(x) ≥ 0}
        
        Args:
            ego_state: Current ego vehicle state
            neighbor_states_trusted: Consensus-validated neighbor states
            control_input: Proposed control action [ax, ay]
            
        Returns:
            constraint_values: HOCBF constraint values (≥ 0 for safety)
        """
        h_values = self.safety_function(ego_state, neighbor_states_trusted)
        derivatives = self.safety_function_derivatives(ego_state, neighbor_states_trusted)
        
        constraint_values = []
        
        for i, (h, deriv) in enumerate(zip(h_values, derivatives)):
            # Extract derivatives
            Lf_h = deriv['Lf_h']
            Lf2_h = deriv['Lf2_h']
            LgLf_h = deriv['LgLf_h']
            
            # HOCBF constraint calculation
            constraint = (Lf2_h + 
                         np.dot(LgLf_h, control_input) + 
                         self.alpha2 * (Lf_h + self.alpha1 * h))
            
            constraint_values.append(constraint)
            
        return np.array(constraint_values)
    
    def safe_control_synthesis(self, ego_state, neighbor_states_trusted, desired_control):
        """
        Synthesize safe control input using HOCBF constraints
        
        Optimization problem:
        min ||u - u_desired||²
        s.t. L_f² h(x) + L_g L_f h(x) · u + α₂(L_f h(x) + α₁ h(x)) ≥ 0
             u_min ≤ u ≤ u_max
        
        Args:
            ego_state: Current ego vehicle state
            neighbor_states_trusted: Consensus-validated neighbor states
            desired_control: Desired control from DDRL agent
            
        Returns:
            safe_control: Safety-certified control input
            is_safe: Boolean indicating if desired control was safe
        """
        # Check if desired control satisfies HOCBF constraints
        constraint_values = self.hocbf_constraint(ego_state, neighbor_states_trusted, desired_control)
        
        # If all constraints are satisfied, use desired control
        if np.all(constraint_values >= 0):
            return desired_control, True
        
        # Otherwise, solve QP for safe control
        safe_control = self._solve_safety_qp(ego_state, neighbor_states_trusted, desired_control)
        
        return safe_control, False
    
    def _solve_safety_qp(self, ego_state, neighbor_states_trusted, desired_control):
        """
        Solve quadratic programming problem for safe control
        
        This is a simplified version - in practice, use cvxpy or similar
        """
        # For demonstration, apply simple projection to safe region
        # In real implementation, use proper QP solver
        
        # Calculate safety gradients
        derivatives = self.safety_function_derivatives(ego_state, neighbor_states_trusted)
        
        # Find the most critical constraint
        h_values = self.safety_function(ego_state, neighbor_states_trusted)
        most_critical_idx = np.argmin(h_values)
        
        if most_critical_idx < len(derivatives):
            critical_deriv = derivatives[most_critical_idx]
            LgLf_h = critical_deriv['LgLf_h']
            
            # Project desired control onto safe halfspace
            # This is a simplified approach - proper QP would handle multiple constraints
            if np.linalg.norm(LgLf_h) > 1e-6:
                # Project along gradient direction
                projection_factor = max(0, -critical_deriv['Lf2_h'] - 
                                      self.alpha2 * (critical_deriv['Lf_h'] + 
                                                    self.alpha1 * h_values[most_critical_idx]))
                projection_factor /= np.dot(LgLf_h, LgLf_h)
                
                safe_control = desired_control + projection_factor * LgLf_h
            else:
                safe_control = desired_control
        else:
            safe_control = desired_control
        
        # Clamp to actuator limits
        safe_control = np.clip(safe_control, 
                              [self.max_deceleration, self.max_deceleration],
                              [self.max_acceleration, self.max_acceleration])
        
        return safe_control
