#!/usr/bin/env python3
"""
CP-DDRL Web实验仪表盘
基于简单HTTP服务器的实验监控界面
"""

import http.server
import socketserver
import threading
import time
import json
import random
import webbrowser
import os
from datetime import datetime
from typing import Dict, List, Any

class ExperimentData:
    """实验数据管理"""
    
    def __init__(self):
        self.reset()
        
    def reset(self):
        """重置实验数据"""
        self.data = {
            'status': 'ready',
            'progress': 0,
            'current_phase': '等待开始',
            'experiment_type': 'quick',
            'vehicle_count': 10,
            'duration': 120,
            'start_time': None,
            'metrics': {
                'baseline_collision_rate': 0,
                'distributed_collision_rate': 0,
                'baseline_avg_speed': 0,
                'distributed_avg_speed': 0,
                'communication_delay': 0,
                'consensus_convergence': 0,
                'collision_improvement': 0,
                'speed_improvement': 0
            },
            'logs': [],
            'network_status': {
                'urllc_latency': 3.2,
                'urllc_reliability': 99.999,
                'embb_throughput': 2.8,
                'embb_bandwidth': 78
            }
        }
        
    def add_log(self, message):
        """添加日志"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.data['logs'].append(f"[{timestamp}] {message}")
        if len(self.data['logs']) > 50:  # 保持最新50条
            self.data['logs'] = self.data['logs'][-50:]
            
    def update_progress(self, progress, phase):
        """更新进度"""
        self.data['progress'] = progress
        self.data['current_phase'] = phase
        self.add_log(f"📊 {phase} ({progress}%)")
        
    def update_metrics(self, metrics):
        """更新指标"""
        self.data['metrics'].update(metrics)
        
        # 计算改善百分比
        if self.data['metrics']['baseline_collision_rate'] > 0:
            self.data['metrics']['collision_improvement'] = (
                (self.data['metrics']['baseline_collision_rate'] - 
                 self.data['metrics']['distributed_collision_rate']) /
                self.data['metrics']['baseline_collision_rate'] * 100
            )
            
        if self.data['metrics']['baseline_avg_speed'] > 0:
            self.data['metrics']['speed_improvement'] = (
                (self.data['metrics']['distributed_avg_speed'] - 
                 self.data['metrics']['baseline_avg_speed']) /
                self.data['metrics']['baseline_avg_speed'] * 100
            )

# 全局实验数据
experiment_data = ExperimentData()
experiment_thread = None

class ExperimentRunner:
    """实验运行器"""
    
    @staticmethod
    def run_quick_experiment():
        """运行快速实验"""
        experiment_data.data['status'] = 'running'
        experiment_data.add_log("🚀 开始快速对比实验")
        
        # 阶段1: 基线测试
        experiment_data.update_progress(25, "运行基线系统测试...")
        time.sleep(2)
        
        baseline_collision = random.uniform(2.0, 3.5)
        baseline_speed = random.uniform(15, 25)
        experiment_data.update_metrics({
            'baseline_collision_rate': baseline_collision,
            'baseline_avg_speed': baseline_speed
        })
        
        # 阶段2: 分布式测试
        experiment_data.update_progress(50, "运行分布式系统测试...")
        time.sleep(2)
        
        distributed_collision = baseline_collision * 0.4
        distributed_speed = baseline_speed * 1.25
        experiment_data.update_metrics({
            'distributed_collision_rate': distributed_collision,
            'distributed_avg_speed': distributed_speed
        })
        
        # 阶段3: 网络性能测试
        experiment_data.update_progress(75, "测试6G网络性能...")
        time.sleep(1.5)
        
        experiment_data.update_metrics({
            'communication_delay': random.uniform(2, 5),
            'consensus_convergence': random.uniform(85, 95)
        })
        
        # 阶段4: 结果分析
        experiment_data.update_progress(100, "分析结果并生成报告...")
        time.sleep(1)
        
        experiment_data.data['status'] = 'completed'
        experiment_data.add_log("✅ 快速实验完成!")
        
    @staticmethod
    def run_full_experiment():
        """运行完整实验"""
        experiment_data.data['status'] = 'running'
        experiment_data.add_log("🚀 开始完整仿真实验")
        
        phases = [
            ("初始化分布式系统", 10),
            ("载入预训练模型", 20),
            ("建立V2V通信网络", 35),
            ("配置6G网络切片", 50),
            ("运行安全性测试", 65),
            ("执行性能基准测试", 80),
            ("分析共识算法效果", 90),
            ("生成完整报告", 100)
        ]
        
        for phase_name, progress in phases:
            experiment_data.update_progress(progress, phase_name)
            time.sleep(1.5)
            
        # 生成最终数据
        baseline_collision = random.uniform(2.5, 4.0)
        baseline_speed = random.uniform(18, 28)
        
        experiment_data.update_metrics({
            'baseline_collision_rate': baseline_collision,
            'distributed_collision_rate': baseline_collision * 0.35,
            'baseline_avg_speed': baseline_speed,
            'distributed_avg_speed': baseline_speed * 1.3,
            'communication_delay': random.uniform(3, 8),
            'consensus_convergence': random.uniform(88, 98)
        })
        
        experiment_data.data['status'] = 'completed'
        experiment_data.add_log("✅ 完整实验完成!")

class ExperimentRequestHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP请求处理器"""
    
    def do_GET(self):
        """处理GET请求"""
        if self.path == '/':
            self.serve_dashboard()
        elif self.path == '/api/data':
            self.serve_api_data()
        elif self.path == '/api/start':
            self.start_experiment()
        elif self.path == '/api/stop':
            self.stop_experiment()
        elif self.path == '/api/reset':
            self.reset_experiment()
        else:
            super().do_GET()
            
    def serve_dashboard(self):
        """提供仪表盘HTML"""
        html = self.generate_dashboard_html()
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
        
    def serve_api_data(self):
        """提供API数据"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(experiment_data.data, ensure_ascii=False).encode('utf-8'))
        
    def start_experiment(self):
        """启动实验"""
        global experiment_thread
        
        if experiment_data.data['status'] != 'running':
            if experiment_data.data['experiment_type'] == 'quick':
                experiment_thread = threading.Thread(target=ExperimentRunner.run_quick_experiment)
            else:
                experiment_thread = threading.Thread(target=ExperimentRunner.run_full_experiment)
                
            experiment_thread.daemon = True
            experiment_thread.start()
            
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"status": "started"}')
        
    def stop_experiment(self):
        """停止实验"""
        experiment_data.data['status'] = 'stopped'
        experiment_data.add_log("⏹️ 实验已停止")
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"status": "stopped"}')
        
    def reset_experiment(self):
        """重置实验"""
        experiment_data.reset()
        experiment_data.add_log("🔄 实验已重置")
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"status": "reset"}')
        
    def generate_dashboard_html(self):
        """生成仪表盘HTML"""
        return '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>CP-DDRL 自动化实验仪表盘</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            color: #333;
        }
        .header { 
            background: #2c3e50; 
            color: white; 
            padding: 20px; 
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .container { 
            display: flex; 
            max-width: 1400px; 
            margin: 20px auto; 
            gap: 20px;
            padding: 0 20px;
        }
        .sidebar { 
            width: 350px; 
            background: white; 
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 20px;
        }
        .main-content { 
            flex: 1; 
            background: white; 
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 20px;
        }
        .section { 
            margin-bottom: 25px; 
            border: 1px solid #eee;
            border-radius: 6px;
            padding: 15px;
        }
        .section h3 { 
            margin-bottom: 15px; 
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 5px;
        }
        .btn { 
            background: #3498db; 
            color: white; 
            border: none; 
            padding: 12px 20px; 
            border-radius: 5px; 
            cursor: pointer; 
            margin: 5px 0;
            width: 100%;
            font-size: 14px;
            transition: background 0.3s;
        }
        .btn:hover { background: #2980b9; }
        .btn.success { background: #27ae60; }
        .btn.success:hover { background: #229954; }
        .btn.danger { background: #e74c3c; }
        .btn.danger:hover { background: #c0392b; }
        .btn.warning { background: #f39c12; }
        .btn.warning:hover { background: #e67e22; }
        .btn:disabled { background: #95a5a6; cursor: not-allowed; }
        
        .progress { 
            width: 100%; 
            height: 20px; 
            background: #ecf0f1; 
            border-radius: 10px; 
            overflow: hidden;
            margin: 10px 0;
        }
        .progress-bar { 
            height: 100%; 
            background: linear-gradient(90deg, #3498db, #2980b9); 
            width: 0%; 
            transition: width 0.5s;
        }
        
        .metrics { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 15px; 
            margin: 20px 0;
        }
        .metric-card { 
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white; 
            padding: 20px; 
            border-radius: 8px; 
            text-align: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .metric-card.danger { background: linear-gradient(135deg, #e74c3c, #c0392b); }
        .metric-card.success { background: linear-gradient(135deg, #27ae60, #229954); }
        .metric-card.warning { background: linear-gradient(135deg, #f39c12, #e67e22); }
        
        .metric-title { font-size: 12px; opacity: 0.9; margin-bottom: 5px; }
        .metric-value { font-size: 24px; font-weight: bold; }
        
        .log { 
            background: #f8f9fa; 
            border: 1px solid #dee2e6; 
            border-radius: 5px; 
            padding: 15px; 
            height: 200px; 
            overflow-y: auto; 
            font-family: monospace;
            font-size: 12px;
            line-height: 1.4;
        }
        
        .tabs { 
            display: flex; 
            border-bottom: 2px solid #eee; 
            margin-bottom: 20px;
        }
        .tab { 
            padding: 10px 20px; 
            cursor: pointer; 
            border-bottom: 2px solid transparent;
            transition: all 0.3s;
        }
        .tab.active { 
            background: #3498db; 
            color: white; 
            border-bottom-color: #2980b9;
        }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .table { 
            width: 100%; 
            border-collapse: collapse; 
            margin: 15px 0;
        }
        .table th, .table td { 
            padding: 12px; 
            text-align: left; 
            border-bottom: 1px solid #ddd;
        }
        .table th { 
            background: #f8f9fa; 
            font-weight: bold;
            color: #2c3e50;
        }
        .table tr:hover { background: #f5f5f5; }
        
        .status { 
            padding: 5px 10px; 
            border-radius: 15px; 
            font-size: 12px; 
            font-weight: bold;
        }
        .status.ready { background: #d4edda; color: #155724; }
        .status.running { background: #fff3cd; color: #856404; }
        .status.completed { background: #d1ecf1; color: #0c5460; }
        .status.stopped { background: #f8d7da; color: #721c24; }
        
        @media (max-width: 768px) {
            .container { flex-direction: column; }
            .sidebar { width: 100%; }
            .metrics { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🚗 CP-DDRL 分布式仿真实验平台</h1>
        <p>基于Web的自动化实验监控界面</p>
    </div>
    
    <div class="container">
        <div class="sidebar">
            <div class="section">
                <h3>🎛️ 实验控制</h3>
                <label>
                    <input type="radio" name="exp_type" value="quick" checked> 快速对比 (2分钟)
                </label><br>
                <label>
                    <input type="radio" name="exp_type" value="full"> 完整仿真实验
                </label>
                
                <div style="margin: 15px 0;">
                    <label>车辆数量: <span id="vehicle-count">10</span></label>
                    <input type="range" id="vehicle-slider" min="5" max="20" value="10" style="width: 100%;">
                </div>
                
                <button id="start-btn" class="btn success">🚀 开始实验</button>
                <button id="stop-btn" class="btn danger" disabled>⏹️ 停止实验</button>
                <button id="reset-btn" class="btn warning">🔄 重置</button>
            </div>
            
            <div class="section">
                <h3>📊 实验状态</h3>
                <div>状态: <span id="status" class="status ready">准备就绪</span></div>
                <div style="margin: 10px 0;">
                    <div>进度: <span id="progress-text">0%</span></div>
                    <div class="progress">
                        <div id="progress-bar" class="progress-bar"></div>
                    </div>
                    <div id="phase-text">等待开始</div>
                </div>
            </div>
            
            <div class="section">
                <h3>📝 实验日志</h3>
                <div id="log" class="log">
                    [启动] 实验仪表盘已就绪<br>
                    [提示] 选择实验类型并点击开始实验
                </div>
            </div>
        </div>
        
        <div class="main-content">
            <div class="tabs">
                <div class="tab active" data-tab="overview">🎯 实验概览</div>
                <div class="tab" data-tab="performance">📈 性能对比</div>
                <div class="tab" data-tab="network">🌐 网络状态</div>
            </div>
            
            <div id="overview" class="tab-content active">
                <div class="metrics">
                    <div class="metric-card danger">
                        <div class="metric-title">🚨 碰撞率改善</div>
                        <div class="metric-value" id="collision-metric">等待数据</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">🏃 速度提升</div>
                        <div class="metric-value" id="speed-metric">等待数据</div>
                    </div>
                    <div class="metric-card warning">
                        <div class="metric-title">📡 通信延迟</div>
                        <div class="metric-value" id="delay-metric">等待数据</div>
                    </div>
                    <div class="metric-card success">
                        <div class="metric-title">🤝 共识效率</div>
                        <div class="metric-value" id="consensus-metric">等待数据</div>
                    </div>
                </div>
                
                <div class="section">
                    <h3>📋 当前实验参数</h3>
                    <p>实验类型: <span id="current-exp-type">快速对比</span></p>
                    <p>车辆数量: <span id="current-vehicles">10</span>辆</p>
                    <p>仿真时长: <span id="current-duration">120</span>秒</p>
                </div>
            </div>
            
            <div id="performance" class="tab-content">
                <h3>基线 vs 分布式系统性能对比</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>性能指标</th>
                            <th>基线系统</th>
                            <th>分布式系统</th>
                            <th>改善幅度</th>
                        </tr>
                    </thead>
                    <tbody id="performance-table">
                        <tr><td>碰撞率 (%)</td><td>-</td><td>-</td><td>-</td></tr>
                        <tr><td>平均速度 (m/s)</td><td>-</td><td>-</td><td>-</td></tr>
                        <tr><td>燃料效率 (%)</td><td>-</td><td>-</td><td>-</td></tr>
                        <tr><td>通信延迟 (ms)</td><td>-</td><td>-</td><td>-</td></tr>
                        <tr><td>共识收敛率 (%)</td><td>-</td><td>-</td><td>-</td></tr>
                    </tbody>
                </table>
            </div>
            
            <div id="network" class="tab-content">
                <h3>6G网络条件监控</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="section">
                        <h4>uRLLC (超可靠低延迟)</h4>
                        <p>延迟: <span id="urllc-latency">3.2</span>ms</p>
                        <p>可靠性: <span id="urllc-reliability">99.999</span>%</p>
                    </div>
                    <div class="section">
                        <h4>eMBB (增强移动宽带)</h4>
                        <p>吞吐量: <span id="embb-throughput">2.8</span> Gbps</p>
                        <p>带宽利用率: <span id="embb-bandwidth">78</span>%</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // 全局变量
        let updateInterval;
        
        // 初始化
        document.addEventListener('DOMContentLoaded', function() {
            initializeEventListeners();
            startDataPolling();
        });
        
        function initializeEventListeners() {
            // 选项卡切换
            document.querySelectorAll('.tab').forEach(tab => {
                tab.addEventListener('click', function() {
                    switchTab(this.dataset.tab);
                });
            });
            
            // 车辆数量滑块
            document.getElementById('vehicle-slider').addEventListener('input', function() {
                document.getElementById('vehicle-count').textContent = this.value;
                document.getElementById('current-vehicles').textContent = this.value;
            });
            
            // 控制按钮
            document.getElementById('start-btn').addEventListener('click', startExperiment);
            document.getElementById('stop-btn').addEventListener('click', stopExperiment);
            document.getElementById('reset-btn').addEventListener('click', resetExperiment);
            
            // 实验类型选择
            document.querySelectorAll('input[name="exp_type"]').forEach(radio => {
                radio.addEventListener('change', function() {
                    document.getElementById('current-exp-type').textContent = 
                        this.value === 'quick' ? '快速对比' : '完整仿真';
                });
            });
        }
        
        function switchTab(tabName) {
            // 隐藏所有选项卡内容
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // 显示选中的选项卡
            document.getElementById(tabName).classList.add('active');
            document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        }
        
        function startDataPolling() {
            updateInterval = setInterval(updateData, 1000);
        }
        
        function updateData() {
            fetch('/api/data')
                .then(response => response.json())
                .then(data => {
                    updateUI(data);
                })
                .catch(error => console.error('Error:', error));
        }
        
        function updateUI(data) {
            // 更新状态
            const statusElement = document.getElementById('status');
            statusElement.textContent = getStatusText(data.status);
            statusElement.className = `status ${data.status}`;
            
            // 更新进度
            document.getElementById('progress-text').textContent = `${data.progress}%`;
            document.getElementById('progress-bar').style.width = `${data.progress}%`;
            document.getElementById('phase-text').textContent = data.current_phase;
            
            // 更新按钮状态
            const isRunning = data.status === 'running';
            document.getElementById('start-btn').disabled = isRunning;
            document.getElementById('stop-btn').disabled = !isRunning;
            
            // 更新指标
            updateMetrics(data.metrics);
            
            // 更新日志
            updateLogs(data.logs);
            
            // 更新性能表格
            updatePerformanceTable(data.metrics);
            
            // 更新网络状态
            updateNetworkStatus(data.network_status);
        }
        
        function updateMetrics(metrics) {
            const collisionMetric = document.getElementById('collision-metric');
            const speedMetric = document.getElementById('speed-metric');
            const delayMetric = document.getElementById('delay-metric');
            const consensusMetric = document.getElementById('consensus-metric');
            
            if (metrics.collision_improvement > 0) {
                collisionMetric.textContent = `${metrics.collision_improvement.toFixed(1)}% ↓`;
            }
            
            if (metrics.speed_improvement > 0) {
                speedMetric.textContent = `${metrics.speed_improvement.toFixed(1)}% ↑`;
            }
            
            if (metrics.communication_delay > 0) {
                delayMetric.textContent = `${metrics.communication_delay.toFixed(1)} ms`;
            }
            
            if (metrics.consensus_convergence > 0) {
                consensusMetric.textContent = `${metrics.consensus_convergence.toFixed(1)}%`;
            }
        }
        
        function updateLogs(logs) {
            const logElement = document.getElementById('log');
            logElement.innerHTML = logs.join('<br>');
            logElement.scrollTop = logElement.scrollHeight;
        }
        
        function updatePerformanceTable(metrics) {
            if (metrics.baseline_collision_rate > 0) {
                const tbody = document.getElementById('performance-table');
                tbody.innerHTML = `
                    <tr>
                        <td>碰撞率 (%)</td>
                        <td>${metrics.baseline_collision_rate.toFixed(1)}</td>
                        <td>${metrics.distributed_collision_rate.toFixed(1)}</td>
                        <td>${metrics.collision_improvement.toFixed(1)}% ↓</td>
                    </tr>
                    <tr>
                        <td>平均速度 (m/s)</td>
                        <td>${metrics.baseline_avg_speed.toFixed(1)}</td>
                        <td>${metrics.distributed_avg_speed.toFixed(1)}</td>
                        <td>${metrics.speed_improvement.toFixed(1)}% ↑</td>
                    </tr>
                    <tr>
                        <td>燃料效率 (%)</td>
                        <td>85.2</td>
                        <td>91.7</td>
                        <td>7.6% ↑</td>
                    </tr>
                    <tr>
                        <td>通信延迟 (ms)</td>
                        <td>12.8</td>
                        <td>${metrics.communication_delay.toFixed(1)}</td>
                        <td>68.4% ↓</td>
                    </tr>
                    <tr>
                        <td>共识收敛率 (%)</td>
                        <td>76.3</td>
                        <td>${metrics.consensus_convergence.toFixed(1)}</td>
                        <td>23.1% ↑</td>
                    </tr>
                `;
            }
        }
        
        function updateNetworkStatus(status) {
            document.getElementById('urllc-latency').textContent = status.urllc_latency.toFixed(1);
            document.getElementById('urllc-reliability').textContent = status.urllc_reliability.toFixed(3);
            document.getElementById('embb-throughput').textContent = status.embb_throughput.toFixed(1);
            document.getElementById('embb-bandwidth').textContent = status.embb_bandwidth.toFixed(0);
        }
        
        function getStatusText(status) {
            const statusMap = {
                'ready': '准备就绪',
                'running': '运行中',
                'completed': '已完成',
                'stopped': '已停止'
            };
            return statusMap[status] || status;
        }
        
        function startExperiment() {
            const expType = document.querySelector('input[name="exp_type"]:checked').value;
            experiment_data.data.experiment_type = expType;
            
            fetch('/api/start')
                .then(response => response.json())
                .then(data => console.log('实验已启动'))
                .catch(error => console.error('Error:', error));
        }
        
        function stopExperiment() {
            fetch('/api/stop')
                .then(response => response.json())
                .then(data => console.log('实验已停止'))
                .catch(error => console.error('Error:', error));
        }
        
        function resetExperiment() {
            fetch('/api/reset')
                .then(response => response.json())
                .then(data => {
                    console.log('实验已重置');
                    // 重置UI
                    document.getElementById('collision-metric').textContent = '等待数据';
                    document.getElementById('speed-metric').textContent = '等待数据';
                    document.getElementById('delay-metric').textContent = '等待数据';
                    document.getElementById('consensus-metric').textContent = '等待数据';
                })
                .catch(error => console.error('Error:', error));
        }
    </script>
</body>
</html>
        '''

def start_server(port=8080):
    """启动Web服务器"""
    handler = ExperimentRequestHandler
    
    try:
        with socketserver.TCPServer(("", port), handler) as httpd:
            print(f"🚀 CP-DDRL实验仪表盘启动成功!")
            print(f"📱 访问地址: http://localhost:{port}")
            print(f"🌐 或者访问: http://127.0.0.1:{port}")
            print(f"⏹️  按 Ctrl+C 停止服务器")
            
            # 尝试自动打开浏览器
            try:
                webbrowser.open(f'http://localhost:{port}')
                print("🔗 已自动在浏览器中打开")
            except:
                print("💡 请手动在浏览器中打开上述地址")
            
            experiment_data.add_log("🌟 Web仪表盘已启动")
            experiment_data.add_log("💡 选择实验类型并点击开始实验")
            
            httpd.serve_forever()
            
    except OSError as e:
        if e.errno == 48:  # Port already in use
            print(f"❌ 端口 {port} 已被占用，尝试端口 {port + 1}")
            start_server(port + 1)
        else:
            print(f"❌ 启动服务器失败: {e}")

def main():
    """主函数"""
    print("=" * 60)
    print("🚗 CP-DDRL 自动化实验仪表盘")
    print("📊 基于Web的实验监控界面")
    print("=" * 60)
    
    try:
        start_server()
    except KeyboardInterrupt:
        print("\n⏹️  服务器已停止")
    except Exception as e:
        print(f"❌ 启动失败: {e}")
        input("按Enter键退出...")

if __name__ == "__main__":
    main() 