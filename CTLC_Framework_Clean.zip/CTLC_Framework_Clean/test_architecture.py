#!/usr/bin/env python3
"""
Test Enhanced Architecture Diagrams
Save as PNG files for verification
"""

import matplotlib
matplotlib.use('Agg')  # 使用非交互式后端
from architecture_diagrams import generate_ddrl_architecture, generate_stgnn_architecture
import base64
import io
from PIL import Image

def save_architecture_diagrams():
    """生成并保存架构图为PNG文件"""
    
    print("🔧 Generating Enhanced DDRL Architecture...")
    ddrl_data = generate_ddrl_architecture()
    
    # 将base64数据转换为图片
    ddrl_image_data = base64.b64decode(ddrl_data)
    ddrl_image = Image.open(io.BytesIO(ddrl_image_data))
    ddrl_image.save('ddrl_architecture_enhanced.png')
    print(f"✅ DDRL Architecture saved: ddrl_architecture_enhanced.png ({len(ddrl_data)} bytes)")
    
    print("🔧 Generating Enhanced ST-GNN Architecture...")
    stgnn_data = generate_stgnn_architecture()
    
    # 将base64数据转换为图片
    stgnn_image_data = base64.b64decode(stgnn_data)
    stgnn_image = Image.open(io.BytesIO(stgnn_image_data))
    stgnn_image.save('stgnn_architecture_enhanced.png')
    print(f"✅ ST-GNN Architecture saved: stgnn_architecture_enhanced.png ({len(stgnn_data)} bytes)")
    
    print("\n🎉 Architecture diagrams generated successfully!")
    print("Features implemented:")
    print("✓ No overlapping components")
    print("✓ Enhanced color scheme")
    print("✓ Professional layout")
    print("✓ Mathematical formulations with standard ASCII")
    print("✓ Clear data flow arrows")
    print("✓ Comprehensive legends and descriptions")
    
    print("\nDDRL Features:")
    print("• Multi-agent distributed learning")
    print("• Byzantine fault tolerance > 95%")
    print("• Consensus-based model fusion")
    print("• Real-time policy updates")
    
    print("\nST-GNN Features:")
    print("• Multi-sensor data fusion")
    print("• Spatio-temporal pattern learning")
    print("• Graph neural network processing")
    print("• Real-time decision making")

if __name__ == "__main__":
    save_architecture_diagrams() 